#ifndef UARTTHREAD_H
#define UARTTHREAD_H

#include <QObject>

#include "DataDealThread/RS485ProtocolDefine/RS485ProtocolType.h"
#include "Uart/UartThread485.h"

class UartThread : public QObject
{
    Q_OBJECT
public:
    explicit UartThread(QObject *parent = nullptr);

signals:
    void SIGNALDataReadyRead(QByteArray data);  //数据准备好，可以上传到上层

public slots:
    void SLOTDataWrite(const DataAttributeType dataAttribute, const QByteArray data);   //接收上层数据

private:
    UartThread485   *mUart485;  //RS485串口类
};

#endif // UARTTHREAD_H
