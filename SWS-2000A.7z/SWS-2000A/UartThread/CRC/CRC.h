#ifndef CRC_H
#define CRC_H

#include <QtGlobal>

class CRC
{
public:
    CRC(quint8 *base, quint16 length);
    ~CRC();

public:
    quint16 Sum();  //校验

private:
    quint8                  *mFrame;
    quint16                 mLength;
    static const quint8     sAucCRCHigh[];
    static const quint8     sAucCRCLow[];
    bool                    mCanDoCRC;
};

#endif // CRC_H
