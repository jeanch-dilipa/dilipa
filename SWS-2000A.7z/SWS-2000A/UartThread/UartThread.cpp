#include "UartThread.h"

#include <QDebug>   ///xxl_debug: QDebug

/***************************************************************************************************
 函数名称：  UartThread()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
UartThread::UartThread(QObject *parent) : QObject(parent)
{
    mUart485 = new UartThread485("/dev/ttyS1", this);   ///xxl_debug: 是否需要手动delete
    connect(mUart485, &UartThread485::SIGNALDataReadyRead, this, &UartThread::SIGNALDataReadyRead, Qt::UniqueConnection);
}

/***************************************************************************************************
 函数名称：  SLOTDataWrite()
 功能描述：  接收上层数据
 输入参数：  dataAttribute：数据属性 | data：数据
 返回的值：  无
 ***************************************************************************************************/
void UartThread::SLOTDataWrite(const DataAttributeType dataAttribute, const QByteArray data)
{
    QByteArray attrData(2, 0);  //数据属性
    attrData[0] = dataAttribute.moduleAddrAndCmd.addr;
    attrData[1] = dataAttribute.moduleAddrAndCmd.cmd;

    switch(dataAttribute.uartMode)
    {
    case UMT_RS485:
        mUart485->SLOTDataWrite(dataAttribute.dataType, QByteArray(attrData + data));
        break;
    default:
        break;
    }
}
