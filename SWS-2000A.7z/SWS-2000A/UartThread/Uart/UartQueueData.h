#ifndef UARTQUEUEDATA_H
#define UARTQUEUEDATA_H

#include <QByteArray>

#include "DataDealThread/RS485ProtocolDefine/RS485ProtocolType.h"

class UartQueueData
{
public:
    explicit UartQueueData(QByteArray data = QByteArray(), DataTypeType dataType = DTT_ReadTypeData, qint32 errorTimes = 0, qint32 errorMaxTimes = 1000);
    virtual ~UartQueueData();

public:
    bool operator ==(const UartQueueData &other);               //重载比较运算符==
    inline QByteArray Data() const { return mData; }            //获取队列数据
    inline DataTypeType DataType() const { return mDataType; }  //获取队列数据类型
    inline qint32 ErrorTimes() const { return mErrorTimes; }    //获取数据发送错误次数
    inline bool IsErrorArriveMaxTimes() const { return (mErrorTimes > mErrorMaxTimes); }    //数据发送错误次数是否达到最大值
    inline void AddErrorTimes(){ mErrorTimes++; }                           //数据发送错误次数+1
    inline void SetErrorTimes(qint32 times){ mErrorTimes = times; }         //设置数据发送错误次数
    inline void SetErrorMaxTimes(qint32 times){ mErrorMaxTimes = times; }   //设置数据发送错误次数上限
    void Clear();   //初始化队列数据

private:
    QByteArray      mData;          //队列数据
    DataTypeType    mDataType;      //数据类型
    qint32          mErrorTimes;    //发送错误次数
    qint32          mErrorMaxTimes; //发送错误次数上限
};

#endif // UARTQUEUEDATA_H
