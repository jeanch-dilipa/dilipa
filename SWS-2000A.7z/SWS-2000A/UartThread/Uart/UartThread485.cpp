#include "UartThread485.h"

#include "../CRC/CRC.h"

#include <QDebug>   ///xxl_debug: QDebug

#define FRAME_BROKE_TIME                    5       //断帧时间，5ms
#define LOOP_RW_TIME                        20      //循环读写时间，20ms
#define LOOP_RW_TIME_OUT_TIME               3000    //没有读写动作时间，该时间一到，重启循环读写，3s
#define CRC_ERROR_CHECK_TIMES               3       //CRC校验错误次数
#define READ_TIME_OUT_ERROR_CHECK_TIMES     3       //通信超时错误次数
#define UPDATE_TYPE_TIME                    200     //升级程序时，下发命令间隔200ms
#define REJISTER_QUEUE_INDEX_MAX            4       //注册队列index数
#define NOR_REJISTER_QUEUE_INDEX            3       //常规注册队列所在index号

/***************************************************************************************************
 函数名称：  UartThread485()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
UartThread485::UartThread485(QString name, QObject *parent) : QObject(parent)
{
    mUartName = name;
    mUart = new QSerialPort(mUartName);
    //115200，8n1，无流控
    mUart->setBaudRate(QSerialPort::Baud115200, QSerialPort::AllDirections);
    mUart->setDataBits(QSerialPort::Data8);
    mUart->setStopBits(QSerialPort::OneStop);
    mUart->setParity(QSerialPort::NoParity);
    mUart->setFlowControl(QSerialPort::NoFlowControl);

    //打开串口
    if(!mUart->open(QIODevice::ReadWrite))
    {   //打开失败
        if(mUart)
        {
            delete mUart;
            mUart = nullptr;
        }
        return;
    }

    //链接信号槽
    connect(mUart, &QIODevice::readyRead, this, &UartThread485::slotReadDataFromUart, Qt::UniqueConnection);

    //断帧定时器
    mFrameBrokeTimer = new QTimer(this);
    mFrameBrokeTimer->setInterval(FRAME_BROKE_TIME);
    connect(mFrameBrokeTimer, &QTimer::timeout, this, &UartThread485::slotFrameBrokeTimerTimeOut, Qt::UniqueConnection);

    //写数据后，读取数据超时定时器
    mRDTimeOutTimer = new QTimer(this);

    //整个读写循环超时定时器
    mLoopRWTimeOutTimer = new QTimer(this);
    mLoopRWTimeOutTimer->setInterval(LOOP_RW_TIME_OUT_TIME);
    connect(mLoopRWTimeOutTimer, &QTimer::timeout, this, &UartThread485::slotLoopGetWrittenDataAndWriteToUart, Qt::UniqueConnection);

    //开始->整个读写循环超时定时器
    QTimer::singleShot(20*LOOP_RW_TIME, this, &UartThread485::slotLoopGetWrittenDataAndWriteToUart);    ///xxl_debug: 为什么要这要用，需要后面分析
}

/***************************************************************************************************
 函数名称：  SLOTDataWrite()
 功能描述：  发送数据
 输入参数：  dataType：数据类型 | data：数据
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::SLOTDataWrite(DataTypeType dataType, QByteArray data)
{
    switch(dataType)
    {
    case DTT_AlarmTypeData:
    case DTT_WriteTypeData:
    case DTT_ReadTypeData:
    case DTT_RejisterTypeDataEmc:
    case DTT_RejisterTypeDataNor:
    case DTT_UpdateBoardTypeData:
        insertQueueData(dataType, data);
        break;
    case DTT_UnrejisterTypeData:
    case DTT_UnrejisterAllData:
    case DTT_ClearAllRegisterData:
    case DTT_ClearAllQueueData:
        deleteQueueData(dataType, data);
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  slotReadDataFromUart()
 功能描述：  读取串口数据槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::slotReadDataFromUart()
{
    stopRDTimeOutTimer();   //停止读取超时定时器
    stopFrameBrokeTimer();  //停止断帧定时器

    if(mUart->bytesAvailable() >= 1)
    {
        mCurrentReadData += mUart->readAll();
    }

    startFrameBrokeTimer(); //开始断帧定时器
}

/***************************************************************************************************
 函数名称：  slotFrameBrokeTimerTimeOut()
 功能描述：  断帧槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::slotFrameBrokeTimerTimeOut()
{
    stopFrameBrokeTimer();  //停止断帧定时器

    //正确收到数据后，作CRC校验，并发送数据给上层
    if(checkCRCAndEmitUartRecvData(mCurrentReadData))
    {
        QTimer::singleShot(LOOP_RW_TIME, this, &UartThread485::slotLoopGetWrittenDataAndWriteToUart);
    }
    else
    {
        if(mCRCCheckErrorTimes-- > 0)
        {
            QTimer::singleShot(FRAME_BROKE_TIME, this, &UartThread485::slotWriteCurrentDataToUart);
        }
        else
        {
            handleUartRWErrorInfo((ModuleBoardAddrType)mCurrentReadData.at(0), (SysBusCmdType)mCurrentReadData.at(1), WRR_CrcCheckError);
            dealQueueDataRWUartFailedCase(mCurrentWriteData);

            QTimer::singleShot(LOOP_RW_TIME, this, &UartThread485::slotLoopGetWrittenDataAndWriteToUart);
        }
    }
}

/***************************************************************************************************
 函数名称：  slotLoopGetWrittenDataAndWriteToUart()
 功能描述：  循环读写串口数据槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::slotLoopGetWrittenDataAndWriteToUart()
{
    stopLoopRWTimeOutTimer();       //停止mLoopRWTimeOutTimer

    mCRCCheckErrorTimes = CRC_ERROR_CHECK_TIMES;
    mReadTimeOutErrorTimes = READ_TIME_OUT_ERROR_CHECK_TIMES;
    mCurrentWriteData.Clear();

    //取将要发送的数据
    mCurrentWriteData = getNextWriteData();
    if(mCurrentWriteData.Data().isEmpty())
    {   //数据为空
        QTimer::singleShot(LOOP_RW_TIME, this, &UartThread485::slotLoopGetWrittenDataAndWriteToUart);
        return;
    }

    slotWriteCurrentDataToUart();   //写数据到串口
    startLoopRWTimeOutTimer();      //开始断帧定时器
}

/***************************************************************************************************
 函数名称：  slotWriteCurrentDataToUart()
 功能描述：  写数据到串口槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::slotWriteCurrentDataToUart()
{
    mUart->write(mCurrentWriteData.Data());
    mUart->flush();

    if(mCurrentWriteData.DataType() == DTT_UpdateBoardTypeData)
    {   //升级板子
        startRDTimeOutTimer(UPDATE_TYPE_TIME);
    }
    else
    {
        startRDTimeOutTimer(LOOP_RW_TIME);
    }
}

/***************************************************************************************************
 函数名称：  slotRDTimeOutTimerTimeOut()
 功能描述：  写数据后，读数据超时槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::slotRDTimeOutTimerTimeOut()
{
    stopRDTimeOutTimer();   //停止读取超时定时器

    if(mReadTimeOutErrorTimes-- > 0)
    {
        QTimer::singleShot(FRAME_BROKE_TIME, this, &UartThread485::slotWriteCurrentDataToUart);
    }
    else
    {
        handleUartRWErrorInfo((ModuleBoardAddrType)mCurrentWriteData.Data().at(0), (SysBusCmdType)mCurrentWriteData.Data().at(1), WRR_ReadTimeOut);
        dealQueueDataRWUartFailedCase(mCurrentWriteData);

        QTimer::singleShot(LOOP_RW_TIME, this, &UartThread485::slotLoopGetWrittenDataAndWriteToUart);
    }
}

/***************************************************************************************************
 函数名称：  insertQueueData()
 功能描述：  将数据入队列
 输入参数：  dataType：数据类型 | data：数据
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::insertQueueData(DataTypeType dataType, QByteArray &data)
{
    QByteArray fullData = data;

    //添加CRC校验在发送数据的末尾
    CRC crc((quint8 *)data.data(), data.length());
    quint16 sum = crc.Sum();

    QByteArray sumData(2, 0);
    memcpy(sumData.data(), &sum, 2);

    fullData += sumData;

    ///xxl_debug: 打印串口数据
    QString str;
    str.prepend(fullData.toHex());
    qDebug() << "serial: " << str;
    ///end_debug_xxl

    mIsClearAllQueueData = false;

    UartQueueData queueData(fullData, dataType);
    insertQueueData(queueData);
}

/***************************************************************************************************
 函数名称：  insertQueueData()
 功能描述：  将数据入队列
 输入参数：  queueData：队列数据
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::insertQueueData(UartQueueData &queueData)
{
    switch(queueData.DataType())
    {
    case DTT_AlarmTypeData:
    case DTT_WriteTypeData:
    case DTT_ReadTypeData:
    case DTT_UpdateBoardTypeData:
        mWriteReadQueueList.append(queueData);
        break;
    case DTT_RejisterTypeDataEmc:
        mEmcRejisterQueueList.append(queueData);
        break;
    case DTT_RejisterTypeDataNor:
        mNorRejisterQueueList.append(queueData);
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  deleteQueueData()
 功能描述：  将数据出队列
 输入参数：  dataType：数据类型 | data：数据
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::deleteQueueData(DataTypeType dataType, QByteArray &data)
{
    UartQueueData queueData(data, dataType);
    deleteQueueData(queueData);
}

/***************************************************************************************************
 函数名称：  deleteQueueData()
 功能描述：  将数据出队列
 输入参数：  queueData：队列数据
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::deleteQueueData(UartQueueData &queueData)
{
    switch(queueData.DataType())
    {
    case DTT_RejisterTypeDataEmc:
        if(!mEmcRejisterQueueList.isEmpty())
        {
            mEmcRejisterQueueIndex = 0;
            mEmcRejisterQueueList.removeAll(queueData);
        }
        break;
    case DTT_RejisterTypeDataNor:
        if(!mNorRejisterQueueList.isEmpty())
        {
            mNorRejisterQueueIndex = 0;
            mNorRejisterQueueList.removeAll(queueData);
        }
        break;
    case DTT_UnrejisterTypeData:
        if(!mEmcRejisterQueueList.isEmpty())
        {
            mEmcRejisterQueueIndex = 0;
            mEmcRejisterQueueList.removeAll(queueData);
        }
        if(!mNorRejisterQueueList.isEmpty())
        {
            mNorRejisterQueueIndex = 0;
            mNorRejisterQueueList.removeAll(queueData);
        }
        break;
    case DTT_UnrejisterAllData:
    case DTT_ClearAllRegisterData:
        mEmcRejisterQueueIndex = 0;
        mEmcRejisterQueueList.clear();
        mNorRejisterQueueIndex = 0;
        mNorRejisterQueueList.clear();
        break;
    case DTT_ClearAllQueueData:
        mIsClearAllQueueData = true;
        mWriteReadQueueList.clear();
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  startRDTimeOutTimer()
 功能描述：  开始mRDTimeOutTimer
 输入参数：  ms：定时器周期毫秒
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::startRDTimeOutTimer(qint32 ms)
{
    ///xxl_debug: 为什么要在这里connect，后续分析
    connect(mRDTimeOutTimer, &QTimer::timeout, this, &UartThread485::slotRDTimeOutTimerTimeOut, Qt::UniqueConnection);
    mRDTimeOutTimer->start(ms);
}

/***************************************************************************************************
 函数名称：  stopRDTimeOutTimer()
 功能描述：  停止mRDTimeOutTimer
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
inline void UartThread485::stopRDTimeOutTimer()
{
    if(mRDTimeOutTimer->isActive())
    {
        mRDTimeOutTimer->stop();
    }
}

/***************************************************************************************************
 函数名称：  startFrameBrokeTimer()
 功能描述：  开始mFrameBrokeTimer
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
inline void UartThread485::startFrameBrokeTimer()
{
    mFrameBrokeTimer->start();
}

/***************************************************************************************************
 函数名称：  stopFrameBrokeTimer()
 功能描述：  停止mFrameBrokeTimer
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
inline void UartThread485::stopFrameBrokeTimer()
{
    if(mFrameBrokeTimer->isActive())
    {
        mFrameBrokeTimer->stop();
    }
}

/***************************************************************************************************
 函数名称：  startLoopRWTimeOutTimer()
 功能描述：  开始mLoopRWTimeOutTimer
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
inline void UartThread485::startLoopRWTimeOutTimer()
{
    mLoopRWTimeOutTimer->start();
}

/***************************************************************************************************
 函数名称：  stopLoopRWTimeOutTimer()
 功能描述：  停止mLoopRWTimeOutTimer
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::stopLoopRWTimeOutTimer()
{
    disconnect(mLoopRWTimeOutTimer, &QTimer::timeout, this, &UartThread485::slotLoopGetWrittenDataAndWriteToUart);  ///xxl_debug: 为什么要disconnect
    if(mLoopRWTimeOutTimer->isActive())
    {
        mLoopRWTimeOutTimer->stop();
    }
}

/***************************************************************************************************
 函数名称：  checkCRCAndEmitUartRecvData()
 功能描述：  校验串口接收到的数据并发送
 输入参数：  data：数据
 返回的值：  bool: 校验结果
 ***************************************************************************************************/
bool UartThread485::checkCRCAndEmitUartRecvData(QByteArray data)
{
    CRC crc((quint8 *)data.data(), data.length());
    quint16 sum = crc.Sum();

    if(sum == 0)
    {
        /*******************************************************************
         * CRC校验正确，且接收到的数据不是对WR命令的响应数据（数据长度为4）
         * 则去掉末尾的CRC数据后，将数据传出去
         * 若是WR命令的响应数据，则直接丢弃该数据
         *******************************************************************/
        if(data.size() >= 4)
        {
            data.resize(data.size() - 2);
            emit this->SIGNALDataReadyRead(data);
        }
        mCurrentReadData.clear();
        return true;
    }
    else
    {
        mCurrentReadData.clear();
        return false;
    }
}

/***************************************************************************************************
 函数名称：  handleUartRWErrorInfo()
 功能描述：  处理串口读写错误信息
 输入参数：  addr: 模块地址 | cmd: 协议读写命令 | error: 数据结果
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::handleUartRWErrorInfo(ModuleBoardAddrType addr, SysBusCmdType cmd, WrittenReadUartDataResult error)
{
    QByteArray data(4, 0);

    data[0] = addr;
    data[1] = 0x55;
    data[2] = error;
    data[3] = cmd;

    emit this->SIGNALDataReadyRead(data);
}

/***************************************************************************************************
 函数名称：  dealQueueDataRWUartFailedCase()
 功能描述：  处理串口读写数据失败的情形
 输入参数：  queueData：串口队列数据
 返回的值：  无
 ***************************************************************************************************/
void UartThread485::dealQueueDataRWUartFailedCase(UartQueueData &queueData)
{
    /********************************************************
     * 将串口队列数据错误次数递增，并重新放入对应队列
     * 若错误次数超过上限，则从队列中删除该数据，并向上报告
     ********************************************************/
    if((queueData.DataType() != DTT_RejisterTypeDataEmc) && (queueData.DataType() != DTT_RejisterTypeDataNor))
    {   //非此两个枚举，返回
        return;
    }

    deleteQueueData(queueData);

    if(!mIsClearAllQueueData)
    {
        queueData.AddErrorTimes();
        if(!queueData.IsErrorArriveMaxTimes())
        {
            insertQueueData(queueData);
            return;
        }
    }

    //向上报告，数据被删除
    QByteArray data = queueData.Data();
    handleUartRWErrorInfo((ModuleBoardAddrType)data.at(0), (SysBusCmdType)data.at(1), WRR_DataDeleteError);
}

/***************************************************************************************************
 函数名称：  getNextWriteData()
 功能描述：  获取下一个数据进行串口发送
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
UartQueueData UartThread485::getNextWriteData()
{
    UartQueueData data;

    //查找读写队列
    if(!mWriteReadQueueList.isEmpty())
    {
        data = mWriteReadQueueList.first();
        mWriteReadQueueList.removeFirst();

        return data;
    }

    //查找紧急、常规队列
    for(qint32 i = 0; i < REJISTER_QUEUE_INDEX_MAX; i++)
    {
        if(mRejisterQueueIndex != NOR_REJISTER_QUEUE_INDEX)
        {   //紧急队列
            if(!mEmcRejisterQueueList.isEmpty())
            {
                data = mEmcRejisterQueueList.at(mEmcRejisterQueueIndex);
                mEmcRejisterQueueIndex = (mEmcRejisterQueueIndex+1) % mEmcRejisterQueueList.size();
                mRejisterQueueIndex = (mRejisterQueueIndex+1) % REJISTER_QUEUE_INDEX_MAX;
                return data;
            }
        }
        else
        {   //常规队列
            if(!mNorRejisterQueueList.isEmpty())
            {
                data = mNorRejisterQueueList.at(mNorRejisterQueueIndex);
                mNorRejisterQueueIndex = (mNorRejisterQueueIndex+1) % mNorRejisterQueueList.size();
                mRejisterQueueIndex = (mRejisterQueueIndex+1) % REJISTER_QUEUE_INDEX_MAX;
                return data;
            }
        }
        mRejisterQueueIndex = (mRejisterQueueIndex+1) % REJISTER_QUEUE_INDEX_MAX;
    }

    return data;
}
