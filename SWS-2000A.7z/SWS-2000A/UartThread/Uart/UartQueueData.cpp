#include "UartQueueData.h"

/***************************************************************************************************
 函数名称：  UartQueueData()
 功能描述：  构造函数
 输入参数：  data：队列数据 | dataType：数据类型 | errorTimes：发送错误次数 | errorMaxTimes：发送错误次数上限
 返回的值：  无
 ***************************************************************************************************/
UartQueueData::UartQueueData(QByteArray data, DataTypeType dataType, qint32 errorTimes, qint32 errorMaxTimes)
{
    mData = data;
    mDataType = dataType;
    mErrorTimes = errorTimes;
    mErrorMaxTimes = errorMaxTimes;
}

/***************************************************************************************************
 函数名称：  ~UartQueueData()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
UartQueueData::~UartQueueData()
{
    mData.clear();
}

/***************************************************************************************************
 函数名称：  Clear()
 功能描述：  初始化队列数据
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void UartQueueData::Clear()
{
    mData.clear();
    mDataType = DTT_ReadTypeData;
    mErrorTimes = 0;
    mErrorMaxTimes = 1000;
}

/***************************************************************************************************
 函数名称：  operator ==()
 功能描述：  重载比较运算符==
 输入参数：  other：比较值
 返回的值：  bool：是否相等
 ***************************************************************************************************/
bool UartQueueData::operator ==(const UartQueueData &other)
{
    const QByteArray data = other.Data();

    if((mData.size() >= 2) && (data.size() >= 2))
    {
        if((mData.at(0) == data.at(0)) && (mData.at(1) == data.at(1)))
        {   //这里只需要板子地址对应得上就可以
            return true;
        }
    }

    return false;
}
