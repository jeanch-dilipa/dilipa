#ifndef UARTTHREAD485_H
#define UARTTHREAD485_H

#include <QObject>
#include <QSerialPort>
#include <QTimer>

#include "DataDealThread/RS485ProtocolDefine/RS485ProtocolType.h"
#include "UartQueueData.h"

class UartThread485 : public QObject
{
    Q_OBJECT
public:
    explicit UartThread485(QString name, QObject *parent = nullptr);

signals:
    void SIGNALDataReadyRead(QByteArray data);  //数据准备好可读

public slots:
    void SLOTDataWrite(DataTypeType dataType, QByteArray data);     //发送数据

private slots:
    void slotReadDataFromUart();        //读取串口数据槽函数
    void slotFrameBrokeTimerTimeOut();  //断帧槽函数
    void slotLoopGetWrittenDataAndWriteToUart();    //循环读写串口数据槽函数
    void slotWriteCurrentDataToUart();              //写数据到串口槽函数
    void slotRDTimeOutTimerTimeOut();               //写数据后，读数据超时槽函数

private:
    void insertQueueData(DataTypeType dataType, QByteArray &data);  //将数据入队列
    void insertQueueData(UartQueueData &queueData);                 //将数据入队列
    void deleteQueueData(DataTypeType dataType, QByteArray &data);  //将数据出队列
    void deleteQueueData(UartQueueData &queueData);                 //将数据出队列
    void startRDTimeOutTimer(qint32 ms);    //开始mRDTimeOutTimer
    inline void stopRDTimeOutTimer();       //停止mRDTimeOutTimer
    inline void startFrameBrokeTimer();     //开始mFrameBrokeTimer
    inline void stopFrameBrokeTimer();      //停止mFrameBrokeTimer
    inline void startLoopRWTimeOutTimer();  //开始mLoopRWTimeOutTimer
    void stopLoopRWTimeOutTimer();          //停止mLoopRWTimeOutTimer
    bool checkCRCAndEmitUartRecvData(QByteArray data);              //校验串口接收到的数据并发送
    void handleUartRWErrorInfo(ModuleBoardAddrType addr, SysBusCmdType cmd, WrittenReadUartDataResult error);   //处理串口读写错误信息
    void dealQueueDataRWUartFailedCase(UartQueueData &queueData);   //处理串口读写数据失败的情形
    UartQueueData getNextWriteData();       //获取下一个数据进行串口发送

private:
    QSerialPort             *mUart = nullptr;       //串口
    QString                 mUartName;              //串口名
    UartQueueData           mCurrentWriteData;      //当前写的串口数据
    QByteArray              mCurrentReadData;       //当前读取的串口数据
    QTimer                  *mFrameBrokeTimer;      //断帧定时器
    QTimer                  *mRDTimeOutTimer;       //写数据后，读取数据超时定时器
    QTimer                  *mLoopRWTimeOutTimer;   //整个读写循环超时定时器
    QList<UartQueueData>    mWriteReadQueueList;    //读写数据队列
    QList<UartQueueData>    mEmcRejisterQueueList;  //紧急注册数据队列
    QList<UartQueueData>    mNorRejisterQueueList;  //常规注册数据队列
    qint32                  mRejisterQueueIndex = 0;        //注册队列index
    qint32                  mEmcRejisterQueueIndex = 0;     //紧急注册数据队列index
    qint32                  mNorRejisterQueueIndex = 0;     //常规注册数据队列index
    bool                    mIsReadEmcQueue = true;         //true时优先读取紧急注册数据队列，false为常规
    bool                    mIsClearAllQueueData = false;   //程序升级时，清除队列所有数据
    qint32                  mCRCCheckErrorTimes;            //CRC检测错误剩余次数
    qint32                  mReadTimeOutErrorTimes;         //超时错误剩余次数
};

#endif // UARTTHREAD485_H
