#ifndef PUBLICENUMDEFINE_H
#define PUBLICENUMDEFINE_H

/*************************************************************************************
 * 注意：
 * 如果枚举后带数字，请不要随意更改，该做法是为了在以后数据库中记录的枚举值
 * 能够准确唯一对应相关定义，如果在后期需要增加新枚举，请在之后添加并定义好数字
 * 枚举在不使用时，需要对其注释并保留，而且请问重复利用原来不使用的枚举数字
 *************************************************************************************/

///工作模式
enum WorkModeType
{
    WMT_Default = 0,        //默认
    WMT_StartUp = 1,        //启动
    WMT_Maintenance = 2,    //维护
    WMT_SelfCheck = 3,      //自检
    WMT_Priming = 4,        //预充
    WMT_PatientConnect = 5, //引血
    WMT_CureRun = 6,        //治疗运行
    WMT_CureEnd = 7,        //治疗结束
    WMT_BloodBack = 8       //回血
};

///治疗模式
enum CureMethodType
{
    CMT_None = 0,       //无
    CMT_HP = 1          //血液灌流
};

///功能码
enum FunctionCodeType
{
    FCT_Default = 0,            //默认
    //主要定义
    FCT_WorkMode = 1,           //工作模式
    FCT_CureMethod = 2,         //治疗模式
    //参数
    FCT_DisplayTime = 20,       //治疗显示时间
    FCT_CureRunTime = 22,       //治疗时间
    FCT_PrimingVolume = 23,     //预充总量
    FCT_BloodPumpAccVolume = 24,    //血泵累积量
    //配置
    FCT_SystemLanguage = 50,    //系统语言
    FCT_MachineNumber,          //机器编号
    //界面控件
    FCT_Pre = 100,              //Pre按钮
    FCT_Run,                    //Run按钮
    FCT_Next,                   //Next按钮
    //自检状态
    FCT_SelfCheckStep,          //自检步骤
    //预充状态
    FCT_PrimingStep,        //预充步骤
    //引血状态
    FCT_PatientConnectStep,     //引血步骤
    //回血状态
    FCT_BloodBackStep,          //回血步骤
    //参数
    FCT_BloodPumpFlow = 107,    //血泵流量
    FCT_InputKeyboard = 108,    //小键盘
    FCT_HeatTemp = 109,         //保温器温度
    FCT_HeparinPumpFlow = 110,  //肝素流量
    //开关
    FCT_BloodPumpSwitch = 200,  //血泵开关
    FCT_HeatSwitch = 201,       //保温器开关
    FCT_HeparinSwitch = 202     //肝素泵开关
};

///数据类型
enum FunctionDataType
{
    //自定义类型使用
    FDT_Custom      = 0,    //自定义类型
    //bool类型使用
    FDT_Boolean     = 50,   //布尔值
    FDT_Switch      = 51,   //开关
    FDT_Display     = 52,   //是否显示
    FDT_Enable      = 53,   //是否启用
    //QString类型使用
    FDT_Text        = 100,  //显示文本
    //int类型使用
    FDT_Numeric     = 150,  //数值
    //double类型使用
    FDT_Decimal     = 200,  //小数值
};

///系统语言
enum SystemLanguageType
{
    SLT_Chinese = 0,    //简体中文
    SLT_English = 1     //英语
};

///自检步骤
enum SelfCheckStepType
{
    SCST_Uncheck = 0,   //未自检
    SCST_Checking,      //自检中
    SCST_CheckFailed,   //自检失败
    SCST_Checked        //自检完成
};

///预充步骤
enum PrimingStepType
{
    PST_NotFill = 0,    //未预充
    PST_Filling,        //正在预充
    PST_Pause,          //预充暂停
    PST_Filled,         //预充完成
    PST_Refilling       //重新预充
};

///回血步骤
enum BloodBackStepType
{
    BBST_NotBack = 0,   //未回血
    BBST_Backing,       //回血中
    BBST_Backed         //回血完成
};

#endif // PUBLICENUMDEFINE_H
