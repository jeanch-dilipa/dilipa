#include "DataDealThread.h"

/***************************************************************************************************
 函数名称：  DataDealThread()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
DataDealThread::DataDealThread(QObject *parent) : QObject(parent)
{
    //初始化报警处理类实例
    mAlarmApp = AlarmApparatus::instance();

    ///xxl_todo: DataDealThread 构造函数
}

/***************************************************************************************************
 函数名称：  ~DataDealThread()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
DataDealThread::~DataDealThread()
{
    AlarmApparatus::deleteInstance();
}

/***************************************************************************************************
 函数名称：  SLOTDataFromInterface()
 功能描述：  来自界面层的数据
 输入参数：  无
 返回的值：  code：功能码 | type：数据类型 | var：数据
 ***************************************************************************************************/
void DataDealThread::SLOTDataFromInterface(FunctionCodeType code, FunctionDataType type, QVariant var)
{
    switch(type)
    {
    case FDT_Numeric:
        analyseIntData(code, var.toInt());
        break;
    default:
        break;
    }

    emit this->SIGNALDataFromInterface(code, type, var);
    ///xxl_todo: SLOTDealFromInterface
}

/***************************************************************************************************
 函数名称：  SLOTDataFromUart()
 功能描述：  来自UART层的数据
 输入参数：  data---数据
 返回的值：  无
 ***************************************************************************************************/
void DataDealThread::SLOTDataFromUart(QByteArray data)
{
    char *pData = data.data();
    qint32 len = data.length();

    DataAttributeType attr;
    attr.moduleAddrAndCmd.addr = (ModuleBoardAddrType)*pData;   //模块地址
    attr.moduleAddrAndCmd.cmd = (SysBusCmdType)*(pData+1);      //命令

    switch(attr.moduleAddrAndCmd.cmd)
    {
    case BUS_CMD_CRC_ERR:
        ///xxl_todo: UART校验出错
        break;
    default:
        gDPD.mb.UpdateModuleBoardData(attr, pData+2, len-2);    //正常板子数据
        break;
    }
}

/***************************************************************************************************
 函数名称：  analyseIntData()
 功能描述：  解析int
 输入参数：  code：功能码 | num：数据
 返回的值：  无
 ***************************************************************************************************/
void DataDealThread::analyseIntData(FunctionCodeType code, qint32 num)
{
    switch(code)
    {
    case FCT_WorkMode:      //工作模式
        switch(num)
        {
        case WMT_StartUp:
            createNewProcess(AbstractMainProcess::MPT_StartUp);
            break;
        case WMT_Maintenance:
            createNewProcess(AbstractMainProcess::MPT_Maintenance);
            break;
        case WMT_SelfCheck:
        case WMT_Priming:
        case WMT_PatientConnect:
        case WMT_CureRun:
        case WMT_CureEnd:
        case WMT_BloodBack:
            createNewProcess(AbstractMainProcess::MPT_Cure);
            break;
        default:
            break;
        }
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  creatNewProcess()
 功能描述：  创建新处理类
 输入参数：  type---类型
 返回的值：  无
 ***************************************************************************************************/
void DataDealThread::createNewProcess(AbstractMainProcess::MainProcessType type)
{
    if(mMainProcess && mMainProcess->processType() == type)
    {   //已有该实例则不创建
        return;
    }

    deleteMainProcess();

    switch(type)
    {
    case AbstractMainProcess::MPT_StartUp:
        break;
    case AbstractMainProcess::MPT_Maintenance:
        break;
    case AbstractMainProcess::MPT_Cure:
        if(!mMainProcess)
        {
            mMainProcess = new CureMain(this);
        }
        break;
    default:
        break;
    }

    connectMainProcessSignalsAndSlots();
}

/***************************************************************************************************
 函数名称：  deleteMainProcess()
 功能描述：  删除处理类
 输入参数：  type---类型
 返回的值：  无
 ***************************************************************************************************/
void DataDealThread::deleteMainProcess()
{
    if(mMainProcess)
    {
        ///xxl_todo: deleteMainProcess
        delete mMainProcess;
    }
}

/***************************************************************************************************
 函数名称：  connectMainProcessSignalsAndSlots()
 功能描述：  链接信号槽
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void DataDealThread::connectMainProcessSignalsAndSlots()
{
    if(mMainProcess)
    {
        connect(this, &DataDealThread::SIGNALDataFromInterface, mMainProcess, &AbstractMainProcess::SLOTDataFromInterface, Qt::UniqueConnection);
        connect(mMainProcess, &AbstractMainProcess::SIGNALSendToInterface, this, &DataDealThread::SIGNALSendToInterface, Qt::UniqueConnection);
    }
}
