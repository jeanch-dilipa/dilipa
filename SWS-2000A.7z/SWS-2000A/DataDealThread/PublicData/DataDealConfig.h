#ifndef DATADEALCONFIG_H
#define DATADEALCONFIG_H

#include "DataDealPublicData.h"     //数据层公共类

extern DataDealPublicData gDPD;     //数据层公共类

#endif // DATADEALCONFIG_H
