#include "DataDealPublicData.h"

#include <QDebug>   ///xxl_debug: QDebug

Q_DECLARE_METATYPE(DataAttributeType);

/***************************************************************************************************
 函数名称：  DataDealPublicData()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
DataDealPublicData::DataDealPublicData(QObject *parent) : QObject(parent)
{
}

/***************************************************************************************************
 函数名称：  slotReceiveQueryData()
 功能描述：  接收sql结果槽函数
 输入参数：  无
 返回的值：  operate---数据库操作，var---数据
 ***************************************************************************************************/
void DataDealPublicData::SLOTReceiveQueryData(SqlOperateType operate, QVariant var)
{
    switch(operate)
    {
    case SOT_SELECT_BOARD_CONFIG:
    {
        QList<DataAttributeType> attrList = var.value<QList<DataAttributeType> >();
        foreach(DataAttributeType attr, attrList)
        {
            qDebug() << "read attr: " << attr.moduleAddrAndCmd.addr << attr.moduleAddrAndCmd.cmd << attr.uartMode << attr.dataType << attr.dataLength;  ///xxl_debug: read attr
            mb.SetModuleBoardDataAttribute(attr);
        }
    }
        break;
    default:
        break;
    }
}
