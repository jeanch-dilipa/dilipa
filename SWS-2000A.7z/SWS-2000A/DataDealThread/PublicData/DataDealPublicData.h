#ifndef DATADEALPUBLICDATA_H
#define DATADEALPUBLICDATA_H

#include <QObject>
#include <QVariant>

#include "DataDealThread/ModuleBoard/ModuleBoard.h"
#include "SqlThread/SqlDataDefine.h"

class DataDealPublicData : public QObject
{
    Q_OBJECT
public:
    explicit DataDealPublicData(QObject *parent = nullptr);

public slots:
    void SLOTReceiveQueryData(SqlOperateType operate, QVariant var);    //接收sql结果槽函数

public:
    MDB             mdb;    //模块板数据
    ModuleBoard     mb;     //模块板类，管理模块数据
};

#endif // DATADEALPUBLICDATA_H
