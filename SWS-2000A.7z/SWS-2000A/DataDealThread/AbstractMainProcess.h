#ifndef ABSTRACTMAINPROCESS_H
#define ABSTRACTMAINPROCESS_H

#include "Commom/PublicDefine/PublicEnumDefine.h"

#include <QObject>
#include <QVariant>

class AbstractMainProcess : public QObject
{
    Q_OBJECT

public:
    //主要界面类型
    enum MainProcessType
    {
        MPT_StartUp     = 0,    //启动
        MPT_Maintenance = 1,    //维护
        MPT_Cure        = 2     //治疗
    };

public:
    explicit AbstractMainProcess(QObject *parent = 0) : QObject(parent){}
    virtual ~AbstractMainProcess(){}
    MainProcessType processType(){ return mCurrentProcess; }

signals:
    void SIGNALSendToInterface(FunctionCodeType code, FunctionDataType type, QVariant var);     //发送数据到界面层

public slots:
    virtual void SLOTDataFromInterface(FunctionCodeType code, FunctionDataType type, QVariant var) = 0;     //来自界面层的数据

protected:
    MainProcessType     mCurrentProcess;    //当前实例
};

#endif // ABSTRACTMAINPROCESS_H
