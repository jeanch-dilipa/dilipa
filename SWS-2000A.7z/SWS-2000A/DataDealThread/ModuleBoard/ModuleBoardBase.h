#ifndef MODULEBOARDBASE_H
#define MODULEBOARDBASE_H

#include <QObject>
#include <QMultiMap>
#include <QMutex>

#include "DataDealThread/RS485ProtocolDefine/RS485ProtocolType.h"

class ModuleBoardBase : public QObject
{
    Q_OBJECT
public:
    explicit ModuleBoardBase(const QMultiMap<SysBusCmdType, void *> dataMap, QObject *parent = nullptr);
    ~ModuleBoardBase();

public:
    ///
    /// get
    ///
    //返回模块数据属性
    inline DataAttributeType DataAttribute(const SysBusCmdType cmd) const{ return mDataAttrMap.value(cmd, DataAttributeType()); }
    QList<DataAttributeType> DataAttribute() const;                                 //返回模块数据属性列表
    void *DataMapValue(const SysBusCmdType cmd);                                    //返回模块协议中使用的读/写命令数据
    //返回模块协议中使用的读/写命令数据的长度
    inline qint32 DataLength(const SysBusCmdType cmd) const{ return mDataAttrMap.value(cmd, DataAttributeType()).dataLength; }
    //判断模块返回数据是否为最新
    inline bool IsReturnInfoUpdateStatusLatest(const SysBusCmdType cmd){ return mDataUpdateFlagMap.value(cmd); }
    ///
    /// set
    ///
    //设置数据属性
    inline void SetDataAttribute(const SysBusCmdType cmd, const DataAttributeType attr){ mDataAttrMap.replace(cmd, attr); }
    void SetDataMapValue(const SysBusCmdType cmd, const void *data, const qint32 length);   //设置模块协议中使用的读/写命令的数据
    //设置模块的返回数据为最新
    inline void SetReturnInfoUpdateStatusToLatest(const SysBusCmdType cmd){ mDataUpdateFlagMap.replace(cmd, true); }
    //设置模块的返回数据为非最新
    inline void SetReturnInfoUpdateStatusToNotLatest(const SysBusCmdType cmd){ mDataUpdateFlagMap.replace(cmd, false); }
    void ResetReturnInfoUpdateStatus();                                             //重置模块返回数据标志为默认值
    inline void AddReceiveWrongDataCount(){ mRecvWrongDataCount++; }                //模块接收数据错误次数+1
    bool IsReturnInfoUpdateStatusLatestAndReset(const SysBusCmdType cmd);           //判断模块返回数据是否为最新，并重置
    ///
    /// func
    ///
    void LockModuleBoardDataForReadOrWrite(const SysBusCmdType cmd);                //加锁模块协议中使用的读/写命令数据
    void UnlockModuleBoardDataForReadOrWrite(const SysBusCmdType cmd);              //解锁模块协议中使用的读/写命令数据

private:
    QMultiMap<SysBusCmdType, void *>                mDataMap;           //协议中读/写命令
    QMultiMap<SysBusCmdType, QMutex *>              mLockMap;           //保护mDataMap中的数据
    QMultiMap<SysBusCmdType, DataAttributeType>     mDataAttrMap;       //数据属性列表
    QMultiMap<SysBusCmdType, bool>                  mDataUpdateFlagMap; //数据是否更新
    qint32      mRecvWrongDataCount = 0;        //模块接收数据错误次数
};

#endif // MODULEBOARDBASE_H
