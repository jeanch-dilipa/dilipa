#ifndef MODULEBOARD_H
#define MODULEBOARD_H

#include <QObject>

#include "ModuleBoardBase.h"

///控制板
#define ITEM_CB_VER     0x00000001
#define ITEM_CB_WR0     0x00000002
#define ITEM_CB_WR1     0x00000004
#define ITEM_CB_WR2     0x00000008
#define ITEM_CB_WR3     0x00000010
#define ITEM_CB_WR4     0x00000020
#define ITEM_CB_WR5     0x00000040
#define ITEM_CB_WR6     0x00000080
#define ITEM_CB_WR9     0x00000100
///监控板
#define ITEM_MB_VER     0x00000200
#define ITEM_MB_WR0     0x00000400

///泵类型
enum PumpType
{
    DefaultPump     = 0,    //默认值
    BloodPump       = 1,    //血泵
    StandbyPump     = 2,    //备用泵
    HeparinPump     = 3,    //肝素泵
    AllPump         = 100   //所有泵
};

///泵状态信息类型
enum PumpStatusType
{
    PumpCover,              //泵盖，0/1---血泵盖闭合/开启
    PumpSpeedAbnormal,      //转速是否异常，0/1---转速正常/异常
    PumpDirection,          //方向，0/1---顺时针，逆时针
    PumpPower,              //电源，0/1---关机/开机
    HeparinPumpBottom,      //肝素泵是否到底，0/1---未到底/到底
    HeparinPumpTop,         //肝素泵是否到顶，0/1---未到顶/到顶
    HeparinPumpStall        //肝素泵自检状态，00-未堵转/01-堵转（未检测到转速信号）/10-堵转（转速信号较正常值低）
};

///泵工作模式类型
enum PumpWorkModeType
{
    PumpWorkModeNormal              = 0,    //正常运转模式
    PumpWorkModePipeInstall         = 1,    //管路安装缓动模式（点动）
    PumpWorkModeFsrTest             = 2,    //泵管系数测试模式（转10转后自动停止）
    PumpWorkModeSyringeCorrection   = 3     //注射器校正
};

///泵方向类型
enum PumpDirectionType
{
    PumpDirectionForward    = 0,    //顺时针，或前进
    PumpDirectionBackward   = 1     //逆时针，或后退
};

///阻流夹控制类型
enum BlockingClampControlType
{
    BlockingClampControlIgnore  = 0,    //保持原来状态
    BlockingClampControlOpen    = 1,    //关
    BlockingClampControlClose   = 2     //开
};

///液面调节动作类型
enum LevelAdjustType
{
    LevelAdjustIgnore   = 0,    //保持原来状态
    LevelAdjustStop     = 1,    //模块不动作
    LevelAdjustVpUp     = 2,    //静脉壶液面上升
    LevelAdjustVpDown   = 3,    //静脉壶液面下降
    LevelAdjustApUp     = 4,    //动脉壶液面上升
    LevelAdjustApDown   = 5     //动脉壶液面下降
};

///注射器型号
enum SyringeType
{
    SyringeNull     = 0,    //未安装
    Syringe10       = 10,   //10ml
    Syringe20       = 20,   //20ml
    Syringe30       = 30,   //30ml
    Syringe50       = 50,   //50ml
    SyringeUnknown  = 1000  //未知型号
};

///电源开关类型
enum PowerType
{
    PowerOff    = 0,    //关机
    PowerOn     = 1     //开机
};

///灯闪烁类型
enum LightFlickerType
{
    LightFlickerDisable     = 0,    //常亮
    LightFlickerEnable      = 1     //闪烁
};

///动静脉壶运转模式类型
enum BloodChamberModeType
{
    BloodChamberModeAirIn   = 1,    //注入气体
    BloodChamberModeAirOut  = 2,    //抽出气体
    BloodChamberModeStop    = 3     //停止
};

///血泵备用泵类型
enum WitchBloodPumpType
{
    WitchBloodPump      = 0,    //血泵
    WitchStandbyPump    = 1     //备用泵
};

///血泵工作模式类型
enum BloodPumpWorkModeType
{
    BloodPumpWorkModeNormal         = 0,    //正常运转模式
    BloodPumpWorkModePipeInstall    = 1,    //管路安装缓动模式（点动）
    BloodPumpWorkModeFsrTest        = 2     //泵管系数测试模式（转10转后自动停止）
};

///肝素泵工作模式类型
enum HeparinPumpWorkModeType
{
    HeparinPumpWorkModeNormal               = 0,    //正常运转模式
    HeparinPumpWorkModeSyringeCorrection    = 1     //注射器校正
};

///泵累计转数清零类型
enum PumpAccRoundClearType
{
    PumpAccRoundClearNo     = 0,    //不清零
    PumpAccRoundClearYes    = 1     //清零
};

///压力类型
enum PressureType
{
    PressureAp                  = 0,    //灌流器前压
    PressureApOriginal          = 1,    //灌流器前压，原始值
    PressureVp                  = 2,    //静脉压
    PressureVpOriginal          = 3,    //静脉压，原始值
    PressureStandbyAp           = 4,    //备用动脉压
    PressureStandbyApOriginal   = 5,    //备用动脉压
    PressureStandbyVp           = 6,    //备用静脉压
    PressureStandbyVpOriginal   = 7     //备用静脉压
};

///压力传感器类型
enum PressureSensorType
{
    PressureSensorAp        = 1,    //灌流器前压传感器
    PressureSensorVp        = 2,    //静脉压传感器
    PressureSensorStandbyAp = 3,    //备用动脉压传感器
    PressureSensorStandbyVp = 4     //备用静脉压传感器
};

///校正点类型
enum CorrectPointType
{
    CorrectPointZero        = 0,    //零点
    CorrectPointNegative    = 1,    //负压
    CorrectPointPositive    = 2     //正压
};

///电池电压类型
enum PowerVoltageType
{
    PowerVoltageBatteryLevel,       //电池电量百分比
    PowerVoltage12V,                //电源12V输出实际电压
    PowerVoltage24V,                //电源24V输出实际电压
    PowerVoltageBatteryVoltage      //电池电压
};

///电池电源状态类型
enum PowerStatusType
{
    PowerStatusPowerSupply,         //供电方式，0/1---市电供电/电池供电
    PowerStatusElectricAbnormal,    //市电是否异常，0/1---市电正常/市电异常
    PowerStatusBatteryAbnormal,     //电池是否异常，0/1---电池正常/电池异常
    PowerStatusBatteryCharge,       //充电状态，0/1---充电完成/电池充电中
    PowerStatusAlarmLightAbnormal   //报警灯是否异常，0/1---报警灯正常/报警灯异常
};

///温度传感器类型
enum TemperatureType
{
    TemperatureWg1,     //WG1
    TemperatureWg2      //WG2
};

///自检项类型
enum TestItemType
{
    TestItemAlarmSound          = 0x00000001,   //报警音
    TestItemHeparinPump         = 0x00000002,   //肝素泵
    TestItemBloodDetect         = 0x00000004,   //血液识别
    TestItemAirMonitor          = 0x00000008,   //空气监测
    TestItemBloodChamberAdjust  = 0x00000010,   //液位调节组件
    TestItemBlockingClamp       = 0x00000020,   //阻断夹
    TestItemStandbyPump         = 0x00000040,   //备用泵
    TestItemBloodPump           = 0x00000080,   //血泵
    TestItemAp                  = 0x00000100,   //灌流器前压
    TestItemVp                  = 0x00000200    //静脉压
};

///自检启用类型
enum TestType
{
    TestDisable     = 0,    //自检
    TestEnable      = 1     //不自检
};

///自检状态类型
enum TestStatusType
{
    TestStatusNormal    = 0,    //正常状态
    TestStatusRunning   = 1,    //正在自检
    TestStatusFinished  = 2     //自检完成
};

///自检结果---血泵
enum TestResultBloodPumpType
{
    TestResultBloodPumpNormal           = 0,    //血泵自检正常
    TestResultBloodPumpCoverOpen        = 1,    //血泵泵盖开
    TestResultBloodPumpSpeedZero        = 2,    //血泵转速为零
    TestResultBloodPumpSpeedAbnormal    = 3     //血泵转速异常
};

///自检结果---备用泵
enum TestResultStandbyPumpType
{
    TestResultStandbyPumpNormal         = 0,    //备用泵自检正常
    TestResultStandbyPumpCoverOpen      = 1,    //备用泵泵盖开
    TestResultStandbyPumpSpeedZero      = 2,    //备用泵转速为零
    TestResultStandbyPumpSpeedAbnormal  = 3     //备用泵转速异常
};

///自检结果---阻断夹
enum TestResultBlockingClampType
{
    TestResultBlockingClampNormal       = 0,    //阻断夹自检正常
    TestResultBlockingClampNoSignal     = 1,    //未检测到打开或关闭信号
    TestResultBlockingClampAlwaysOpen   = 2,    //一直检测到打开信号
    TestResultBlockingClampAlwaysClose  = 3     //一直检测到关闭信号
};

///自检结果---液位调节组件
enum TestResultBloodChamberAdjustType
{
    TestResultBloodChamberAdjustNormal      = 0,    //液位调节组件自检正常
    TestResultBloodChamberAdjustAbnormal    = 1     //液位调节组件自检异常
};

///自检结果---肝素泵
enum TestResultHeparinPumpType
{
    TestResultHeparinPumpNormal         = 0,    //肝素泵自检正常
    TestResultHeparinPumpSpeedZero      = 1,    //肝素泵转速为零
    TestResultHeparinPumpTopAndBottom   = 2,    //同时检测到到顶和到底信号
    TestResultHeparinPumpNoTopSignal    = 3,    //未检测到到顶信号
    TestResultHeparinPumpNoBottomSignal = 4     //未检测到到底信号
};

///自检结果---血液识别
enum TestResultBloodDetectType
{
    TestResultBloodDetectNormal     = 0,    //血液识别自检正常
    TestResultBloodDetectNoSignal   = 1,    //未接收到信号
    TestResultBloodDetectWeakSignal = 2     //接收到信号值偏低
};

///自检结果---空气
enum TestResultAirMonitorType
{
    TestResultAirMonitorNormal          = 0,    //空气自检正常
    TestResultAirMonitorStrongSignal    = 1     //接收信号值偏高
};

///自检结果---报警音
enum TestResultAlarmSoundType
{
    TestResultAlarmSoundNormal      = 0,    //报警音自检正常
    TestResultAlarmSoundAbnormal    = 1     //报警音自检异常
};

///自检结果---压力传感器（灌流器前压、静脉压、备用动脉压、备用静脉压）
enum TestResultPressureType
{
    TestResultPressureNormal            = 0,    //自检正常
    TestResultPressureSensorDrift       = 1,    //压力传感器漂移
    TestResultPressureDamagedSensorChip = 2     //压力传感器或AD芯片损坏
};

///灯类型
enum LightType
{
    LightBloodPump,     //血泵灯
    LightRedAlarm,      //红色报警灯
    LightGreenAlarm,    //绿色报警灯
    LightBlueAlarm      //蓝色报警灯
};

///空气监测-气泡大小类型
enum BubbleSizeAlarmLevelType
{
    BubbleSizeAlarmLevel0   = 0,    //报警等级0（50uL大气泡）
    BubbleSizeAlarmLevel1   = 1,    //报警等级1（30uL大气泡）
    BubbleSizeAlarmLevel2   = 2     //报警等级2（20uL大气泡）
};

///空气监测-小气泡累计类型
enum SmallBubbleAccType
{
    SmallBubbleAccYes   = 0,    //小气泡累计
    SmallBubbleAccNo    = 1     //小气泡不累计
};

///空气监测-模式类型
enum AirModeType
{
    AirModeSelfCheck        = 0,    //自检
    AirModePriming          = 1,    //预充
    AirModePatientConnect   = 2,    //引血
    AirModeCure             = 3,    //治疗
    AirModeBloodBack        = 4     //回血
};

///杂项状态信息类型
enum MiscStatusType
{
    MiscStatusBlockingClampPower,               //阻断夹打开/关闭
    MiscStatusBlockingClampSignalWhenOpen,      //阻断夹信号为打开/关闭（阻断夹打开时）
    MiscStatusBlockingClampSignalWhenClose,     //阻断夹信号为关闭/打开（阻断夹关闭时）
    MiscStatusAirDetectedSingleBubble,          //无空气/有空气（单个气泡）
    MiscStatusAirDetectedAccBubble,             //无空气/有空气（累计气泡）
    MiscStatusBloodDetected,                    //血液回路中无血液/有血液
    MiscStatusVpSensorValAbnormal,              //静脉压传感器校正值正常/异常
    MiscStatusApSensorValAbnormal,              //灌流器前压传感器校正值正常/异常
    MiscStatusWg1Abnornal,                      //传感器WG1数据正常/异常
    MiscStatusWg2Abnormal,                      //传感器WG2数据正常/异常
};

///模块版本信息定义
struct BoardVersionData
{
    BoardVersionData &operator =(const BoardVersionData &other)
    {
        code        = other.code;
        hardwareVer = other.hardwareVer;
        softwareVer = other.softwareVer;
        batchNum    = other.batchNum;
        return *this;
    }
    qint16      code = 0;           //部件标识码
    qint16      hardwareVer = 0;    //硬件版本
    qint16      softwareVer = 0;    //软件版本
    qint32      batchNum = 0;       //批次号
};

class ModuleBoard : public QObject
{
    Q_OBJECT
public:
    explicit ModuleBoard(QObject *parent = nullptr);
    ~ModuleBoard();

signals:
    void SIGNALSendData(const DataAttributeType attr, const QByteArray data);   //发送数据信号

public:
    ///
    /// get
    ///
    BoardVersionData BoardVersion(const ModuleBoardAddrType addr);                                  //获取模块版本信息
    DataAttributeType ModuleBoardDataAttribute(const ModuleBoardAddrType addr, const SysBusCmdType cmd);    //获取数据属性
    bool IsReturnInfoUpdateStatusLatest(const ModuleBoardAddrType addr, const SysBusCmdType cmd);   //判断模块返回数据是否为最新
    // 泵操作函数 //
    quint8 PumpStatus(const PumpType pump, const PumpStatusType status, bool &valid);    //获取泵的具体状态信息
    quint16 PumpRpm(const PumpType pump, bool &valid);          //获取泵的目标转速
    quint16 PumpRmpRealtime(const PumpType pump);               //获取泵的实时转速
    quint32 PumpAccRound(const PumpType pump, bool &valid);     //获取泵的累计转数
    quint16 PumpFsr(const PumpType pump, bool &valid);          //获取泵管系数
    quint16 PumpFlow(const PumpType pump, bool &valid);         //获取泵的目标流量
    quint16 PumpFlowRealtime(const PumpType pump);              //获取泵的实时流量
    quint32 PumpAccFlow(const PumpType pump);                   //获取泵的累计流量
    PowerType PumpTargetPower(const PumpType pump);             //获取泵的目标开关
    SyringeType HeparinPumpSyringeType();       //获取注射器型号
    // 压力，请根据实际情况选择合适函数 //
    QHash<PressureType, qint16> Pressure();     //所有压力值
    qint16 Pressure(const PressureType type);   //获取压力
    // 电源 //
    QHash<PowerVoltageType, quint8> PowerVoltage();     //获取电池电压信息集
    quint8 PowerStatus(const PowerStatusType type);     //获取电源状态
    QHash<PowerStatusType, quint8> PowerStatus();       //获取电源状态集
    // 加热器 //
    quint16 Temperature(const TemperatureType type);        //获取温度
    qint8 TemperatureOffset(const TemperatureType type);    //获取温度补偿值
    // 自检 //
    TestStatusType TestStatus();                //自检状态
    quint8 TestResult(TestItemType item);       //自检结果
    QHash<TestItemType, quint8> TestResult();   //自检结果集
    // 杂项 //
    quint8 MiscStatus(const MiscStatusType item);   //获取杂项状态信息
    ///
    /// set
    ///
    inline void Changed(const quint32 item){ mItems |= item; }  //标记模块数据是否更改
    void UpdateModuleBoardData(const DataAttributeType attr, const void *data, const qint32 length);    //更新模块返回的数据
    void SetModuleBoardDataAttribute(const DataAttributeType attr);     //设置数据属性
    void SetReturnInfoUpdateStatusLatest(const ModuleBoardAddrType addr, const SysBusCmdType cmd);      //设置模块的返回数据为最新
    void SetReturnInfoUpdateStatusNotLatest(const ModuleBoardAddrType addr, const SysBusCmdType cmd);   //设置模块的返回数据为非最新
    void ResetReturnInfoUpdateStatus(const ModuleBoardAddrType addr);                           //重置模块返回数据标志为默认值
    bool IsReturnInfoUpdateStatusLatestAndReset(const ModuleBoardAddrType addr, const SysBusCmdType cmd);   //判断模块返回数据是否为最新，并重置
    void SetBoardVersion(const ModuleBoardAddrType addr, const quint16 code, const quint16 hardwareVer, const quint16 softwareVer, const quint32 batchNum);     //设置模块版本信息
    // 泵操作函数 //
    void OpenPump(const PumpType pump, const double flow = -1.0, const PumpWorkModeType mode = PumpWorkModeNormal, const PumpDirectionType direction = PumpDirectionForward);   //开泵
    void ClosePump(const PumpType pump);    //关泵
    void SetPumpAttr(const PumpType pump, const double flow = -1.0, const PumpWorkModeType mode = PumpWorkModeNormal, const PumpDirectionType direction = PumpDirectionForward, const bool emergency = false);  //设置泵属性
    void SetPumpFsr(const PumpType pump, const quint16 fsr);    //设置泵管系数
    void ClearPumpAccFlow(const PumpType pump);                 //清零泵累计流量
    void SetHeparinPumpSyringeType(const SyringeType type);     //设置注射器型号
    // 阻断夹 //
    void ControlBlockingClampAndChamber(const BlockingClampControlType control = BlockingClampControlIgnore, const LevelAdjustType adjust = LevelAdjustIgnore); //控制阻断夹和动静脉壶
    // 电源 //
    void ControlMainPower(PowerType power);     //整机电源控制
    // 加热器 //
    void OpenHeater(const quint16 temp = 0, const quint16 low = 0, const quint16 high = 0, const qint8 offset = -128);      //打开加热器
    void CloseHeater();     //关闭加热器
    void SetHeaterAttr(const quint16 temp = 0, const quint16 low = 0, const quint16 high = 0, const qint8 offset = -128, const bool emergency = false);     //设置加热器属性
    // 灯 //
    void OpenLight(const LightType type, const bool flicker = false);   //开灯
    void CloseLight(const LightType type);                              //关灯
    // 自检项 //
    void SetTestItem(quint32 item = 0xFFFFFFFF);    //设置自检项
    // 压力 //
    void CorrectPressure(const PressureSensorType sensor, const CorrectPointType point, const qint16 value);    //校正压力
    // 空气监测 //
    void SetAirAttr(const AirModeType mode, const SmallBubbleAccType acc, const BubbleSizeAlarmLevelType level);    //设置空气监测属性
    ///
    /// func
    ///
    void Sync(const bool emergency);    //同步更改后的模块数据
    void LockModuleBoardData(const ModuleBoardAddrType addr, const SysBusCmdType cmd);      //获取数据锁
    void UnlockModuleBoardData(const ModuleBoardAddrType addr, const SysBusCmdType cmd);    //释放数据锁
    void RegisterModuleBoardCommand(const ModuleBoardAddrType addr, const SysBusCmdType cmd, const bool emergency);     //注册常用的RD命令数据
    void UnregisterModuleBoardCommand(const ModuleBoardAddrType addr, const SysBusCmdType cmd);                         //注销常用的RD命令数据
    void WriteModuleBoardData(const ModuleBoardAddrType addr, const SysBusCmdType cmd, const bool emergency);   //发送协议VER或WR命令数据
    void ReadModuleBoardData(const ModuleBoardAddrType addr, const SysBusCmdType cmd);      //发送协议中RD命令数据

private:
    // 泵操作函数 //
    void controlBloodPump(const PumpType pump, const bool control, const double flow = -1.0, const PumpWorkModeType mode = PumpWorkModeNormal, const PumpDirectionType direction = PumpDirectionForward);   //控制血泵
    void controlHeparinPump(const bool control, const double flow = -1.0, const PumpWorkModeType mode = PumpWorkModeNormal, const PumpDirectionType direction = PumpDirectionForward);      //控制肝素泵
    void setBloodPumpAttr(const PumpType pump, const double flow = -1.0, const PumpWorkModeType mode = PumpWorkModeNormal, const PumpDirectionType direction = PumpDirectionForward, const bool emergency = false);     //设置血泵属性
    void setHeparinPumpAttr(const double flow = -1.0, const PumpWorkModeType mode = PumpWorkModeNormal, const PumpDirectionType direction = PumpDirectionForward, const bool emergency = false);    //设置肝素泵属性

private:
    QMultiMap<ModuleBoardAddrType, QPointer<ModuleBoardBase> >  mModuleBoardMap;        //所有模块
    quint32     mItems = 0;      //模块更改项，VER、WR类型数据有效
    //这里单独保存血泵、备用泵目标开关的原因是，它们共用了一个WR1，会导致WR1中的power:1倍覆盖
    PowerType   mBloodPumpTargetPower = PowerOff;   //血泵目标开关
    PowerType   mStandbyPumpTargetPower = PowerOff; //备用泵目标开关
};

#endif // MODULEBOARD_H
