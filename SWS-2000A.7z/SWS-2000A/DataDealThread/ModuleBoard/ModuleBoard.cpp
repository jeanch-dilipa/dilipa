#include "ModuleBoard.h"

#include <QPointer>
#include <QDebug>   ///xxl_debug: QDebug

#include "DataDealThread/PublicData/DataDealConfig.h"

/***************************************************************************************************
 函数名称：  ModuleBoard()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
ModuleBoard::ModuleBoard(QObject *parent) : QObject(parent)
{
    QMultiMap<SysBusCmdType, void *> dataMap;   //命令映射图
    QPointer<ModuleBoardBase> board = nullptr;

    //创建控制板信息
    dataMap.insert(BUS_CMD_VER, &gDPD.mdb.cb.ver);
    dataMap.insert(BUS_CMD_WR_0, &gDPD.mdb.cb.wr0);
    dataMap.insert(BUS_CMD_WR_1, &gDPD.mdb.cb.wr1);
    dataMap.insert(BUS_CMD_WR_2, &gDPD.mdb.cb.wr2);
    dataMap.insert(BUS_CMD_WR_3, &gDPD.mdb.cb.wr3);
    dataMap.insert(BUS_CMD_WR_4, &gDPD.mdb.cb.wr4);
    dataMap.insert(BUS_CMD_WR_5, &gDPD.mdb.cb.wr5);
    dataMap.insert(BUS_CMD_WR_6, &gDPD.mdb.cb.wr6);
    dataMap.insert(BUS_CMD_WR_9, &gDPD.mdb.cb.wr9);
    dataMap.insert(BUS_CMD_RD_0, &gDPD.mdb.cb.rd0);
    dataMap.insert(BUS_CMD_RD_1, &gDPD.mdb.cb.rd1);
    dataMap.insert(BUS_CMD_RD_2, &gDPD.mdb.cb.rd2);
    dataMap.insert(BUS_CMD_RD_3, &gDPD.mdb.cb.rd3);
    dataMap.insert(BUS_CMD_RD_4, &gDPD.mdb.cb.rd4);
    dataMap.insert(BUS_CMD_RD_5, &gDPD.mdb.cb.rd5);
    dataMap.insert(BUS_CMD_RD_6, &gDPD.mdb.cb.rd6);
    dataMap.insert(BUS_CMD_RD_7, &gDPD.mdb.cb.rd7);
    dataMap.insert(BUS_CMD_RD_8, &gDPD.mdb.cb.rd8);
    board = new ModuleBoardBase(dataMap);
    mModuleBoardMap.insert(CONTROL_BOARD_ADDR, board);

    //创建监控板信息
    dataMap.clear();
    board = nullptr;
    dataMap.insert(BUS_CMD_VER, &gDPD.mdb.mb.ver);
    dataMap.insert(BUS_CMD_WR_0, &gDPD.mdb.mb.wr0);
    dataMap.insert(BUS_CMD_RD_0, &gDPD.mdb.mb.rd0);
    dataMap.insert(BUS_CMD_RD_1, &gDPD.mdb.mb.rd1);
    dataMap.insert(BUS_CMD_RD_7, &gDPD.mdb.mb.rd7);
    dataMap.insert(BUS_CMD_RD_8, &gDPD.mdb.mb.rd8);
    board = new ModuleBoardBase(dataMap);
    mModuleBoardMap.insert(MONITOR_BOARD_ADDR, board);
}

/***************************************************************************************************
 函数名称：  ~ModuleBoard()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
ModuleBoard::~ModuleBoard()
{
}

/***************************************************************************************************
 函数名称：  BoardVersion()
 功能描述：  获取模块版本信息
 输入参数：  addr---模块地址
 返回的值：  BoardVersionType---模块版本信息
 ***************************************************************************************************/
BoardVersionData ModuleBoard::BoardVersion(const ModuleBoardAddrType addr)
{
    BoardVersionData ver;

    switch(addr)
    {
    case CONTROL_BOARD_ADDR:    //控制板
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_7);
        ver.code        = gDPD.mdb.cb.rd7.code;
        ver.hardwareVer = gDPD.mdb.cb.rd7.hardwareVer;
        ver.softwareVer = gDPD.mdb.cb.rd7.softwareVer;
        ver.batchNum    = gDPD.mdb.cb.rd7.batchNum;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_7);
        break;
    case MONITOR_BOARD_ADDR:    //监控板
        LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_7);
        ver.code        = gDPD.mdb.mb.rd7.code;
        ver.hardwareVer = gDPD.mdb.mb.rd7.hardwareVer;
        ver.softwareVer = gDPD.mdb.mb.rd7.softwareVer;
        ver.batchNum    = gDPD.mdb.mb.rd7.batchNum;
        break;
    default:
        break;
    }

    return ver;
}

/***************************************************************************************************
 函数名称：  ModuleBoardDataAttribute()
 功能描述：  获取数据属性
 输入参数：  addr---模块地址，cmd---命令
 返回的值：  DataAttributeType---数据属性
 ***************************************************************************************************/
DataAttributeType ModuleBoard::ModuleBoardDataAttribute(const ModuleBoardAddrType addr, const SysBusCmdType cmd)
{
    DataAttributeType attr;
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        attr = board->DataAttribute(cmd);
    }

    return attr;
}

/***************************************************************************************************
 函数名称：  IsReturnInfoUpdateStatusLatest()
 功能描述：  判断模块返回数据是否为最新
 输入参数：  addr---模块地址，cmd---命令
 返回的值：  bool---模块返回数据是否为最新
 ***************************************************************************************************/
bool ModuleBoard::IsReturnInfoUpdateStatusLatest(const ModuleBoardAddrType addr, const SysBusCmdType cmd)
{
    bool status = false;
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        status = board->IsReturnInfoUpdateStatusLatest(cmd);
    }

    return status;
}

/***************************************************************************************************
 函数名称：  PumpStatus()
 功能描述：  获取泵的具体状态信息
 输入参数：  pump---泵，status---状态信息，valid---是否有效
 返回的值：  无
 ***************************************************************************************************/
quint8 ModuleBoard::PumpStatus(const PumpType pump, const PumpStatusType status, bool &valid)
{
    quint8 value = 0xFF;
    valid = true;

    switch(pump)
    {
    case BloodPump:
        switch(status)
        {
        case PumpCover:         value = gDPD.mdb.cb.rd1.bpCover;            break;
        case PumpSpeedAbnormal: value = gDPD.mdb.cb.rd1.bpSpeedAbnormal;    break;
        case PumpDirection:     value = gDPD.mdb.cb.rd1.bpDirection;        break;
        case PumpPower:         value = gDPD.mdb.cb.rd1.bpPower;            break;
        default:                valid = false;                              break;
        }
        break;
    case StandbyPump:
        switch(status)
        {
        case PumpCover:         value = gDPD.mdb.cb.rd2.spCover;           break;
        case PumpSpeedAbnormal: value = gDPD.mdb.cb.rd2.spSpeedAbnormal;   break;
        case PumpDirection:     value = gDPD.mdb.cb.rd2.spDirection;       break;
        case PumpPower:         value = gDPD.mdb.cb.rd2.spPower;           break;
        default:                valid = false;                              break;
        }
        break;
    case HeparinPump:
        switch(status)
        {
        case PumpDirection:     value = gDPD.mdb.cb.rd4.hpMoveDirection;    break;
        case PumpPower:         value = gDPD.mdb.cb.rd4.hpPower;            break;
        case HeparinPumpBottom: value = gDPD.mdb.cb.rd4.hpBottom;           break;
        case HeparinPumpTop:    value = gDPD.mdb.cb.rd4.hpTop;              break;
        case HeparinPumpStall:  value = gDPD.mdb.cb.rd4.hpStall;            break;
        default:                valid = false;                              break;
        }
        break;
    default:
        valid = false;
        break;
    }

    return value;
}

/***************************************************************************************************
 函数名称：  PumpRpm()
 功能描述：  获取泵的目标转速
 输入参数：  pump---泵，valid---是否有效
 返回的值：  quint16---泵目标转速
 ***************************************************************************************************/
quint16 ModuleBoard::PumpRpm(const PumpType pump, bool &valid)
{
    quint16 rpm = 0;
    valid = true;

    switch(pump)
    {
    case BloodPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_1);
        rpm = gDPD.mdb.cb.rd1.bpRpm;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_1);
        break;
    case StandbyPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_2);
        rpm = gDPD.mdb.cb.rd2.spRpm;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_2);
        break;
    default:
        valid = false;
        break;
    }
    return rpm;
}

/***************************************************************************************************
 函数名称：  PumpRmpRealtime()
 功能描述：  获取泵的实时转速
 输入参数：  pump---泵
 返回的值：  quint16---泵实时转速
 ***************************************************************************************************/
quint16 ModuleBoard::PumpRmpRealtime(const PumpType pump)
{
    quint16 rpm = 0;

    switch(pump)
    {
    case BloodPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_1);
        rpm = gDPD.mdb.cb.rd1.bpRpmRealtime;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_1);
        break;
    case StandbyPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_2);
        rpm = gDPD.mdb.cb.rd2.spRpmRealtime;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_2);
        break;
    case HeparinPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_4);
        rpm = gDPD.mdb.cb.rd4.hpRpmRealtime;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_4);
        break;
    default:
        break;
    }

    return rpm;
}

/***************************************************************************************************
 函数名称：  PumpAccRound()
 功能描述：  获取泵的累计转数
 输入参数：  pump---泵，valid---是否有效
 返回的值：  quint32---泵的累计转数
 ***************************************************************************************************/
quint32 ModuleBoard::PumpAccRound(const PumpType pump, bool &valid)
{
    quint32 round = 0;
    valid = true;

    switch(pump)
    {
    case BloodPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_1);
        round = gDPD.mdb.cb.rd1.bpAccRound;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_1);
        break;
    case StandbyPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_2);
        round = gDPD.mdb.cb.rd2.spAccRound;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_2);
        break;
    default:
        valid = false;
        break;
    }

    return round;
}

/***************************************************************************************************
 函数名称：  PumpFsr()
 功能描述：  获取泵管系数
 输入参数：  pump---泵，valid---是否有效
 返回的值：  quint16---泵管系数
 ***************************************************************************************************/
quint16 ModuleBoard::PumpFsr(const PumpType pump, bool &valid)
{
    quint16 fsr = 1;
    valid = true;

    switch(pump)
    {
    case BloodPump:
        fsr = gDPD.mdb.fsr.bloodPump;
        break;
    case StandbyPump:
        fsr = gDPD.mdb.fsr.standbyPump;
        break;
    default:
        valid = false;
        break;
    }

    return fsr;
}

/***************************************************************************************************
 函数名称：  PumpFlow()
 功能描述：  获取泵的目标流量
 输入参数：  pump---泵，valid---是否有效
 返回的值：  quint16---泵目标流量
 ***************************************************************************************************/
quint16 ModuleBoard::PumpFlow(const PumpType pump, bool &valid)
{
    valid = true;
    quint16 flow = 0;
    quint16 rpm = 0;
    quint16 fsr = 1;
    bool tempValid;

    switch(pump)
    {
    case BloodPump:
    case StandbyPump:
        rpm = PumpRpm(pump, tempValid);
        fsr = PumpFsr(pump, tempValid);
        flow = (rpm * fsr) / 10;
        break;
    default:
        valid = false;
        break;
    }

    return flow;
}

/***************************************************************************************************
 函数名称：  PumpFlowRealtime()
 功能描述：  获取泵的实时流量
 输入参数：  pump---泵
 返回的值：  quint16---泵实时流量
 ***************************************************************************************************/
quint16 ModuleBoard::PumpFlowRealtime(const PumpType pump)
{
    quint16 flow = 0;
    quint16 fsr = 1;
    quint16 rpm = 0;
    bool tempValid;

    switch(pump)
    {
    case BloodPump:
    case StandbyPump:
        rpm = PumpRmpRealtime(pump);
        fsr = PumpFsr(pump, tempValid);
        flow = (rpm * fsr) / 10;
        break;
    case HeparinPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_4);
        flow = gDPD.mdb.cb.rd4.hpFlowRealtime;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_4);
        break;
    default:
        break;
    }

    return flow;
}

/***************************************************************************************************
 函数名称：  PumpAccFlow()
 功能描述：  获取泵的累计流量
 输入参数：  pump---泵
 返回的值：  quint32---泵的累计流量
 ***************************************************************************************************/
quint32 ModuleBoard::PumpAccFlow(const PumpType pump)
{
    quint32 accFlow = 0;
    bool tempValid;

    switch(pump)
    {
    case BloodPump:
    case StandbyPump:
        accFlow = PumpAccRound(pump, tempValid) * PumpFsr(pump, tempValid);
        break;
    case HeparinPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_4);
        accFlow = gDPD.mdb.cb.rd4.hpAccFlow;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_4);
        break;
    default:
        break;
    }

    return accFlow;
}

/***************************************************************************************************
 函数名称：  PumpTargetPower()
 功能描述：  获取泵的目标开关
 输入参数：  pump---泵
 返回的值：  PowerType---泵电源开关
 ***************************************************************************************************/
PowerType ModuleBoard::PumpTargetPower(const PumpType pump)
{
    PowerType power = PowerOff;
    switch(pump)
    {
    case BloodPump:
        power = mBloodPumpTargetPower;
        break;
    case StandbyPump:
        power = mStandbyPumpTargetPower;
        break;
    case HeparinPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);
        power = (PowerType)gDPD.mdb.cb.wr3.hpPower;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);
        break;
    default:
        break;
    }

    return power;
}

/***************************************************************************************************
 函数名称：  HeparinPumpSyringeType()
 功能描述：  获取注射器型号
 输入参数：  无
 返回的值：  SyringeType---注射器型号
 ***************************************************************************************************/
SyringeType ModuleBoard::HeparinPumpSyringeType()
{
    SyringeType type = SyringeUnknown;
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);
    switch(gDPD.mdb.cb.wr3.syringeType)
    {
    case 0:     type = SyringeNull;     break;
    case 10:    type = Syringe10;       break;
    case 20:    type = Syringe20;       break;
    case 30:    type = Syringe30;       break;
    case 50:    type = Syringe50;       break;
    default:    break;
    }
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);

    return type;
}

/***************************************************************************************************
 函数名称：  Pressure()
 功能描述：  所有压力值
 输入参数：  无
 返回的值：  QHash<PressureType, qint16>---压力值结果集
 ***************************************************************************************************/
QHash<PressureType, qint16> ModuleBoard::Pressure()
{
    QHash<PressureType, qint16> hash;
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_6);
    hash.insert(PressureAp, gDPD.mdb.cb.rd6.ap);
    hash.insert(PressureApOriginal, gDPD.mdb.cb.rd6.apOriginal);
    hash.insert(PressureVp, gDPD.mdb.cb.rd6.vp);
    hash.insert(PressureVpOriginal, gDPD.mdb.cb.rd6.vpOriginal);
    hash.insert(PressureStandbyAp, gDPD.mdb.cb.rd6.standbyAp);
    hash.insert(PressureStandbyApOriginal, gDPD.mdb.cb.rd6.standbyApOriginal);
    hash.insert(PressureStandbyVp, gDPD.mdb.cb.rd6.standbyVp);
    hash.insert(PressureStandbyVpOriginal, gDPD.mdb.cb.rd6.standbyVpOriginal);
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_6);

    return hash;
}

/***************************************************************************************************
 函数名称：  Pressure()
 功能描述：  获取压力
 输入参数：  type---压力类型
 返回的值：  qint16---压力值
 ***************************************************************************************************/
qint16 ModuleBoard::Pressure(const PressureType type)
{
    qint16 pressure = 0;
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_6);
    switch(type)
    {
    case PressureAp:
        pressure = gDPD.mdb.cb.rd6.ap;
        break;
    case PressureApOriginal:
        pressure = gDPD.mdb.cb.rd6.apOriginal;
        break;
    case PressureVp:
        pressure = gDPD.mdb.cb.rd6.vp;
        break;
    case PressureVpOriginal:
        pressure = gDPD.mdb.cb.rd6.vpOriginal;
        break;
    case PressureStandbyAp:
        pressure = gDPD.mdb.cb.rd6.standbyAp;
        break;
    case PressureStandbyApOriginal:
        pressure = gDPD.mdb.cb.rd6.standbyApOriginal;
        break;
    case PressureStandbyVp:
        pressure = gDPD.mdb.cb.rd6.standbyVp;
        break;
    case PressureStandbyVpOriginal:
        pressure = gDPD.mdb.cb.rd6.standbyVpOriginal;
        break;
    default:
        break;
    }
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_6);

    return pressure;
}

/***************************************************************************************************
 函数名称：  PowerVoltage()
 功能描述：  获取电池电压信息集
 输入参数：  无
 返回的值：  QHash<PowerVoltageType, quint8>---电池电压信息集
 ***************************************************************************************************/
QHash<PowerVoltageType, quint8> ModuleBoard::PowerVoltage()
{
    QHash<PowerVoltageType, quint8> hash;
    LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_1);
    hash.insert(PowerVoltageBatteryLevel, gDPD.mdb.mb.rd1.batteryLevel);
    hash.insert(PowerVoltage12V, gDPD.mdb.mb.rd1.power12V);
    hash.insert(PowerVoltage24V, gDPD.mdb.mb.rd1.power24V);
    hash.insert(PowerVoltageBatteryVoltage, gDPD.mdb.mb.rd1.batteryVoltage);
    UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_1);

    return hash;
}

/***************************************************************************************************
 函数名称：  PowerStatus()
 功能描述：  获取电源状态
 输入参数：  type---电源状态类型
 返回的值：  quint8---电源状态
 ***************************************************************************************************/
quint8 ModuleBoard::PowerStatus(const PowerStatusType type)
{
    quint8 status = 0xFF;       //默认一个最大值，表不用
    LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_1);
    switch(type)
    {
    case PowerStatusPowerSupply:
        status = gDPD.mdb.mb.rd1.powerSupply;
        break;
    case PowerStatusElectricAbnormal:
        status = gDPD.mdb.mb.rd1.electricAbnormal;
        break;
    case PowerStatusBatteryAbnormal:
        status = gDPD.mdb.mb.rd1.batteryAbnormal;
        break;
    case PowerStatusBatteryCharge:
        status = gDPD.mdb.mb.rd1.batteryCharge;
        break;
    case PowerStatusAlarmLightAbnormal:
        status = gDPD.mdb.mb.rd1.alarmLightAbnormal;
        break;
    default:
        break;
    }
    UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_1);

    return status;
}

/***************************************************************************************************
 函数名称：  PowerStatus()
 功能描述：  获取电源状态集
 输入参数：  无
 返回的值：  QHash<PowerStatusType, quint8>---电源状态集
 ***************************************************************************************************/
QHash<PowerStatusType, quint8> ModuleBoard::PowerStatus()
{
    QHash<PowerStatusType, quint8> hash;
    LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_1);
    hash.insert(PowerStatusPowerSupply, gDPD.mdb.mb.rd1.powerSupply);
    hash.insert(PowerStatusElectricAbnormal, gDPD.mdb.mb.rd1.electricAbnormal);
    hash.insert(PowerStatusBatteryAbnormal, gDPD.mdb.mb.rd1.batteryAbnormal);
    hash.insert(PowerStatusBatteryCharge, gDPD.mdb.mb.rd1.batteryCharge);
    hash.insert(PowerStatusAlarmLightAbnormal, gDPD.mdb.mb.rd1.alarmLightAbnormal);
    UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_1);

    return hash;
}

/***************************************************************************************************
 函数名称：  Temperature()
 功能描述：  获取温度
 输入参数：  type---温度传感器
 返回的值：  quint16---温度
 ***************************************************************************************************/
quint16 ModuleBoard::Temperature(const TemperatureType type)
{
    quint16 temp = 0;
    switch(type)
    {
    case TemperatureWg1:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_5);
        temp = gDPD.mdb.cb.rd5.wg1Val;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_5);
        break;
    case TemperatureWg2:
        LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_0);
        temp = gDPD.mdb.mb.rd0.wg2Val;
        UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_0);
        break;
    default:
        break;
    }

    return temp;
}

/***************************************************************************************************
 函数名称：  TemperatureOffset()
 功能描述：  获取温度补偿值
 输入参数：  type---温度传感器
 返回的值：  qint8---温度补偿值
 ***************************************************************************************************/
qint8 ModuleBoard::TemperatureOffset(const TemperatureType type)
{
    qint8 offset = 0;
    switch(type)
    {
    case TemperatureWg1:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_5);
        offset = gDPD.mdb.cb.rd5.wg1Offset;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_5);
        break;
    case TemperatureWg2:
        LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_0);
        offset = gDPD.mdb.mb.rd0.wg2Offset;
        UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_0);
        break;
    default:
        break;
    }

    return offset;
}

/***************************************************************************************************
 函数名称：  TestStatus()
 功能描述：  自检状态
 输入参数：  无
 返回的值：  TestStatusType---自检状态
 ***************************************************************************************************/
TestStatusType ModuleBoard::TestStatus()
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_0);
    TestStatusType status = (TestStatusType)gDPD.mdb.cb.rd0.testStatus;
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_0);

    return status;
}

/***************************************************************************************************
 函数名称：  TestResult()
 功能描述：  自检结果
 输入参数：  item---自检项
 返回的值：  quint8---自检结果
 ***************************************************************************************************/
quint8 ModuleBoard::TestResult(TestItemType item)
{
    quint8 result = 0;
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_0);
    switch(item)
    {
    case TestItemBloodPump:
        result = gDPD.mdb.cb.rd0.testBloodPump;
        break;
    case TestItemStandbyPump:
        result = gDPD.mdb.cb.rd0.testStandbyPump;
        break;
    case TestItemBlockingClamp:
        result = gDPD.mdb.cb.rd0.testBlockingClamp;
        break;
    case TestItemBloodChamberAdjust:
        result = gDPD.mdb.cb.rd0.testBloodChamberAdjust;
        break;
    case TestItemHeparinPump:
        result = gDPD.mdb.cb.rd0.testHeparinPump;
        break;
    case TestItemBloodDetect:
        result = gDPD.mdb.cb.rd0.testBloodDetect;
        break;
    case TestItemAirMonitor:
        result = gDPD.mdb.cb.rd0.testAirMonitor;
        break;
    case TestItemAlarmSound:
        result = gDPD.mdb.cb.rd0.testAlarmSound;
        break;
    case TestItemVp:
        result = gDPD.mdb.cb.rd0.testVP;
        break;
    case TestItemAp:
        result = gDPD.mdb.cb.rd0.testAP;
        break;
    default:
        break;
    }
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_0);

    return result;
}

/***************************************************************************************************
 函数名称：  TestResult()
 功能描述：  自检结果集
 输入参数：  无
 返回的值：  QHash<TestItemType, quint8>---自检结果集
 ***************************************************************************************************/
QHash<TestItemType, quint8> ModuleBoard::TestResult()
{
    QHash<TestItemType, quint8> hash;
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_0);
    hash.insert(TestItemBloodPump, gDPD.mdb.cb.rd0.testBloodPump);
    hash.insert(TestItemStandbyPump, gDPD.mdb.cb.rd0.testStandbyPump);
    hash.insert(TestItemBlockingClamp, gDPD.mdb.cb.rd0.testBlockingClamp);
    hash.insert(TestItemBloodChamberAdjust, gDPD.mdb.cb.rd0.testBloodChamberAdjust);
    hash.insert(TestItemHeparinPump, gDPD.mdb.cb.rd0.testHeparinPump);
    hash.insert(TestItemBloodDetect, gDPD.mdb.cb.rd0.testBloodDetect);
    hash.insert(TestItemAirMonitor, gDPD.mdb.cb.rd0.testAirMonitor);
    hash.insert(TestItemAlarmSound, gDPD.mdb.cb.rd0.testAlarmSound);
    hash.insert(TestItemVp, gDPD.mdb.cb.rd0.testVP);
    hash.insert(TestItemAp, gDPD.mdb.cb.rd0.testAP);
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_0);

    return hash;
}

/***************************************************************************************************
 函数名称：  MiscStatus()
 功能描述：  获取杂项状态信息
 输入参数：  item---具体项
 返回的值：  quint8---状态（0一般表正常，0表异常）
 ***************************************************************************************************/
quint8 ModuleBoard::MiscStatus(const MiscStatusType item)
{
    quint8 status = 0;

    switch(item)
    {
    case MiscStatusBlockingClampPower:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        status = gDPD.mdb.cb.rd3.blockingClampPower;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        break;
    case MiscStatusBlockingClampSignalWhenOpen:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        status = gDPD.mdb.cb.rd3.blockingClampSignalWhenOpen;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        break;
    case MiscStatusBlockingClampSignalWhenClose:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        status = gDPD.mdb.cb.rd3.blockingClampSignalWhenClose;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        break;
    case MiscStatusAirDetectedSingleBubble:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        status = gDPD.mdb.cb.rd3.airDetectedSingleBubble;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        break;
    case MiscStatusBloodDetected:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        status = gDPD.mdb.cb.rd3.bloodDetected;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_3);
        break;
    case MiscStatusVpSensorValAbnormal:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_6);
        status = gDPD.mdb.cb.rd6.vpSensorValAbnormal;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_6);
        break;
    case MiscStatusApSensorValAbnormal:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_6);
        status = gDPD.mdb.cb.rd6.apSensorValAbnormal;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_6);
        break;
    case MiscStatusWg1Abnornal:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_5);
        status = gDPD.mdb.cb.rd5.wg1Abnormal;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_RD_5);
        break;
    case MiscStatusWg2Abnormal:
        LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_0);
        status = gDPD.mdb.mb.rd0.wg2Abnormal;
        UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_RD_0);
        break;
    default:
        break;
    }

    return status;
}

/***************************************************************************************************
 函数名称：  UpdateModuleBoardData()
 功能描述：  更新模块返回的数据
 输入参数：  addr---模块地址，data---数据，length---数据长度
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::UpdateModuleBoardData(const DataAttributeType attr, const void *data, const qint32 length)
{
    ModuleBoardAddrType addr = attr.moduleAddrAndCmd.addr;
    SysBusCmdType cmd = attr.moduleAddrAndCmd.cmd;

    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board && data)
    {
        board->SetDataMapValue(cmd, data, length);
    }
}

/***************************************************************************************************
 函数名称：  SetModuleBoardDataAttribute()
 功能描述：  设置数据属性
 输入参数：  attr---数据属性
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetModuleBoardDataAttribute(const DataAttributeType attr)
{
    ModuleBoardAddrType addr = attr.moduleAddrAndCmd.addr;
    SysBusCmdType cmd = attr.moduleAddrAndCmd.cmd;

    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        board->SetDataAttribute(cmd, attr);
    }
}

/***************************************************************************************************
 函数名称：  SetReturnInfoUpdateStatusLatest()
 功能描述：  设置模块的返回数据为最新
 输入参数：  addr---模块地址，cmd---命令
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetReturnInfoUpdateStatusLatest(const ModuleBoardAddrType addr, const SysBusCmdType cmd)
{
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        board->SetReturnInfoUpdateStatusToLatest(cmd);
    }
}

/***************************************************************************************************
 函数名称：  SetReturnInfoUpdateStatusNotLatest()
 功能描述：  设置模块的返回数据为非最新
 输入参数：  addr---模块地址，cmd---命令
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetReturnInfoUpdateStatusNotLatest(const ModuleBoardAddrType addr, const SysBusCmdType cmd)
{
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        board->SetReturnInfoUpdateStatusToNotLatest(cmd);
    }
}

/***************************************************************************************************
 函数名称：  ResetReturnInfoUpdateStatus()
 功能描述：  重置模块返回数据标志为默认值
 输入参数：  addr---模块地址
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::ResetReturnInfoUpdateStatus(const ModuleBoardAddrType addr)
{
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        board->ResetReturnInfoUpdateStatus();
    }
}

/***************************************************************************************************
 函数名称：  IsReturnInfoUpdateStatusLatestAndReset()
 功能描述：  判断模块返回数据是否为最新，并重置
 输入参数：  addr---模块地址，cmd---命令
 返回的值：  bool---模块返回数据是否为最新
 ***************************************************************************************************/
bool ModuleBoard::IsReturnInfoUpdateStatusLatestAndReset(const ModuleBoardAddrType addr, const SysBusCmdType cmd)
{
    bool status = false;
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        status = board->IsReturnInfoUpdateStatusLatestAndReset(cmd);
    }
    return status;
}

/***************************************************************************************************
 函数名称：  SetBoardVersion()
 功能描述：  设置模块版本信息
 输入参数：  addr---模块地址，code---部件标识码，hardwareVer---硬件版本，softwareVer---软件版本，
             batchNum---批次号
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetBoardVersion(const ModuleBoardAddrType addr, const quint16 code, const quint16 hardwareVer, const quint16 softwareVer, const quint32 batchNum)
{
    switch(addr)
    {
    case CONTROL_BOARD_ADDR:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_VER);
        gDPD.mdb.cb.ver.code = code;
        gDPD.mdb.cb.ver.hardwareVer = hardwareVer;
        gDPD.mdb.cb.ver.softwareVer = softwareVer;
        gDPD.mdb.cb.ver.batchNum = batchNum;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_VER);
        //发送数据
        Changed(ITEM_CB_VER);
        Sync(true);
        break;
    case MONITOR_BOARD_ADDR:
        LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_VER);
        gDPD.mdb.mb.ver.code = code;
        gDPD.mdb.mb.ver.hardwareVer = hardwareVer;
        gDPD.mdb.mb.ver.softwareVer = softwareVer;
        gDPD.mdb.mb.ver.batchNum = batchNum;
        UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_VER);
        //发送数据
        Changed(ITEM_MB_VER);
        Sync(true);
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  OpenPump()
 功能描述：  开泵
 输入参数：  pump---泵，flow---流量，mode---模式，direction---方向
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::OpenPump(const PumpType pump, const double flow, const PumpWorkModeType mode, const PumpDirectionType direction)
{
    switch(pump)
    {
    case BloodPump:
    case StandbyPump:
        controlBloodPump(pump, true, flow, mode, direction);
        break;
    case HeparinPump:
        controlHeparinPump(true, flow, mode, direction);
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  ClosePump()
 功能描述：  关泵
 输入参数：  pump---泵
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::ClosePump(const PumpType pump)
{
    switch(pump)
    {
    case BloodPump:
    case StandbyPump:
        controlBloodPump(pump, false);
        break;
    case HeparinPump:
        controlHeparinPump(false);
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  SetPumpAttr()
 功能描述：  设置泵属性
 输入参数：  pump---泵，flow---流量，mode---模式，direction---方向，emergency---是否立即下发
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetPumpAttr(const PumpType pump, const double flow, const PumpWorkModeType mode, const PumpDirectionType direction, const bool emergency)
{
    switch(pump)
    {
    case BloodPump:
    case StandbyPump:
        setBloodPumpAttr(pump, flow, mode, direction, emergency);
        break;
    case HeparinPump:
        setHeparinPumpAttr(flow, mode, direction, emergency);
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  SetPumpFsr()
 功能描述：  设置泵管系数
 输入参数：  pump---泵，fsr---泵管系数
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetPumpFsr(const PumpType pump, const quint16 fsr)
{
    switch(pump)
    {
    case BloodPump:
        gDPD.mdb.fsr.bloodPump = fsr;
        break;
    case StandbyPump:
        gDPD.mdb.fsr.standbyPump = fsr;
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  ClearPumpAccFlow()
 功能描述：  清零泵累计流量
 输入参数：  pump---泵
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::ClearPumpAccFlow(const PumpType pump)
{
    switch(pump)
    {
    case BloodPump:
    case StandbyPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_1);
        gDPD.mdb.cb.wr1.clearAccRound = PumpAccRoundClearYes;
        if(pump == BloodPump)
        {
            gDPD.mdb.cb.wr1.witchPump = WitchBloodPump;
        }
        else if(pump == StandbyPump)
        {
            gDPD.mdb.cb.wr1.witchPump = WitchStandbyPump;
        }
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_1);
        //发送数据
        Changed(ITEM_CB_WR1);
        Sync(false);
        //恢复为不清零
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_1);
        gDPD.mdb.cb.wr1.clearAccRound = PumpAccRoundClearNo;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_1);
        //清零读取的累计转数
        gDPD.mdb.cb.rd1.bpAccRound = 0;
        break;
    case HeparinPump:
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);
        gDPD.mdb.cb.wr3.hpClearAccFlow = PumpAccRoundClearYes;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);
        //发送数据
        Changed(ITEM_CB_WR3);
        Sync(false);
        //恢复为不清零
        LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);
        gDPD.mdb.cb.wr3.hpClearAccFlow = PumpAccRoundClearNo;
        UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);
        //清零读取的累计转数
        gDPD.mdb.cb.rd4.hpAccFlow = 0;
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  SetHeparinPumpSyringeType()
 功能描述：  设置注射器型号
 输入参数：  type---注射器型号
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetHeparinPumpSyringeType(const SyringeType type)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);
    gDPD.mdb.cb.wr3.syringeType = (quint16)type;
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);
    //发送数据
    Changed(ITEM_CB_WR3);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  ControlBlockingClampAndChamber()
 功能描述：  控制阻断夹和动静脉壶
 输入参数：  control---开关，adjust---液面调节动作
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::ControlBlockingClampAndChamber(const BlockingClampControlType control, const LevelAdjustType adjust)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_2);

    //阻断夹
    switch(control)
    {
    case BlockingClampControlOpen:      //阻断夹打开
        gDPD.mdb.cb.wr2.blockingClampPower = PowerOn;
        break;
    case BlockingClampControlClose:     //阻断夹关闭
        gDPD.mdb.cb.wr2.blockingClampPower = PowerOff;
        break;
    case BlockingClampControlIgnore:    //保持原来状态
    default:
        break;
    }
    //动静脉壶液面调节
    switch(adjust)
    {
    case LevelAdjustApUp:   //动脉壶上升
        gDPD.mdb.cb.wr2.arterialBloodChamber = PowerOn;
        gDPD.mdb.cb.wr2.venousBloodChamber = PowerOff;
        gDPD.mdb.cb.wr2.pumpMode = BloodChamberModeAirOut;
        break;
    case LevelAdjustApDown: //动脉壶下降
        gDPD.mdb.cb.wr2.arterialBloodChamber = PowerOn;
        gDPD.mdb.cb.wr2.venousBloodChamber = PowerOff;
        gDPD.mdb.cb.wr2.pumpMode = BloodChamberModeAirIn;
        break;
    case LevelAdjustVpUp:   //静脉壶上升
        gDPD.mdb.cb.wr2.arterialBloodChamber = PowerOff;
        gDPD.mdb.cb.wr2.venousBloodChamber = PowerOn;
        gDPD.mdb.cb.wr2.pumpMode = BloodChamberModeAirOut;
        break;
    case LevelAdjustVpDown: //静脉壶下降
        gDPD.mdb.cb.wr2.arterialBloodChamber = PowerOff;
        gDPD.mdb.cb.wr2.venousBloodChamber = PowerOn;
        gDPD.mdb.cb.wr2.pumpMode = BloodChamberModeAirIn;
        break;
    case LevelAdjustStop:   //停止上升或下降
        gDPD.mdb.cb.wr2.arterialBloodChamber = PowerOff;
        gDPD.mdb.cb.wr2.venousBloodChamber = PowerOff;
        gDPD.mdb.cb.wr2.pumpMode = BloodChamberModeStop;
        break;
    case LevelAdjustIgnore: //保持原来状态
    default:
        break;
    }

    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_2);

    //发送数据
    Changed(ITEM_CB_WR2);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  ControlMainPower()
 功能描述：  整机电源控制
 输入参数：  power---电源开关
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::ControlMainPower(PowerType power)
{
    LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_WR_0);
    gDPD.mdb.mb.wr0.mainPower = power;
    UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_WR_0);
    //发送数据
    Changed(ITEM_MB_WR0);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  OpenHeater()
 功能描述：  打开加热器
 输入参数：  temp---保温器设置温度，low---保温器温度下限，high---保温器温度下限，offset---保温器温度补偿值
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::OpenHeater(const quint16 temp, const quint16 low, const quint16 high, const qint8 offset)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_5);
    LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_WR_0);
    //开关
    gDPD.mdb.cb.wr5.heaterPower = PowerOn;
    gDPD.mdb.mb.wr0.heaterPower = PowerOn;
    //温度
    if(temp > 0)
    {
        gDPD.mdb.cb.wr5.temp = temp;
        gDPD.mdb.mb.wr0.temp = temp;
    }
    if(low > 0)
    {
        gDPD.mdb.cb.wr5.tempLow = low;
        gDPD.mdb.mb.wr0.tempLow = low;
    }
    if(high > 0)
    {
        gDPD.mdb.cb.wr5.tempHigh = high;
        gDPD.mdb.mb.wr0.tempHigh = high;
    }
    if(offset > -128)
    {
        gDPD.mdb.cb.wr5.tempOffset = offset;
        gDPD.mdb.mb.wr0.tempOffset = offset;
    }
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_5);
    UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_WR_0);
    //发送数据
    Changed(ITEM_CB_WR5);
    Changed(ITEM_MB_WR0);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  CloseHeater()
 功能描述：  关闭加热器
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::CloseHeater()
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_5);
    LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_WR_0);
    gDPD.mdb.cb.wr5.heaterPower = PowerOff;
    gDPD.mdb.mb.wr0.heaterPower = PowerOff;
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_5);
    UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_WR_0);
    //发送数据
    Changed(ITEM_CB_WR5);
    Changed(ITEM_MB_WR0);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  SetHeaterAttr()
 功能描述：  设置加热器属性
 输入参数：  temp---保温器设置温度，low---保温器温度下限，high---保温器温度下限，
             offset---保温器温度补偿值，emergency---紧急程度
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetHeaterAttr(const quint16 temp, const quint16 low, const quint16 high, const qint8 offset, const bool emergency)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_5);
    LockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_WR_0);
    //温度
    if(temp > 0)
    {
        gDPD.mdb.cb.wr5.temp = temp;
        gDPD.mdb.mb.wr0.temp = temp;
    }
    if(low > 0)
    {
        gDPD.mdb.cb.wr5.tempLow = low;
        gDPD.mdb.mb.wr0.tempLow = low;
    }
    if(high > 0)
    {
        gDPD.mdb.cb.wr5.tempHigh = high;
        gDPD.mdb.mb.wr0.tempHigh = high;
    }
    if(offset > -128)
    {
        gDPD.mdb.cb.wr5.tempOffset = offset;
        gDPD.mdb.mb.wr0.tempOffset = offset;
    }
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_5);
    UnlockModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_WR_0);
    if(emergency)
    {
        //发送数据
        Changed(ITEM_CB_WR5);
        Changed(ITEM_MB_WR0);
        Sync(false);
    }
}

/***************************************************************************************************
 函数名称：  OpenLight()
 功能描述：  开灯
 输入参数：  type---灯，flicker---闪烁
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::OpenLight(const LightType type, const bool flicker)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_4);
    switch(type)
    {
    case LightBloodPump:
        gDPD.mdb.cb.wr4.bloodLight = PowerOn;
        break;
    case LightRedAlarm:
        gDPD.mdb.cb.wr4.alarmLightRed = PowerOn;
        gDPD.mdb.cb.wr4.alarmLightFlicker = flicker ? LightFlickerEnable : LightFlickerDisable;
        break;
    case LightGreenAlarm:
        gDPD.mdb.cb.wr4.alarmLightGreen = PowerOn;
        gDPD.mdb.cb.wr4.alarmLightFlicker = flicker ? LightFlickerEnable : LightFlickerDisable;
        break;
    case LightBlueAlarm:
        gDPD.mdb.cb.wr4.alarmLightBlue = PowerOn;
        gDPD.mdb.cb.wr4.alarmLightFlicker = flicker ? LightFlickerEnable : LightFlickerDisable;
        break;
    default:
        break;
    }
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_4);
    //发送数据
    Changed(ITEM_CB_WR4);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  OpenLight()
 功能描述：  开灯
 输入参数：  type---灯
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::CloseLight(const LightType type)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_4);
    switch(type)
    {
    case LightBloodPump:
        gDPD.mdb.cb.wr4.bloodLight = PowerOff;
        break;
    case LightRedAlarm:
        gDPD.mdb.cb.wr4.alarmLightRed = PowerOff;
        break;
    case LightGreenAlarm:
        gDPD.mdb.cb.wr4.alarmLightGreen = PowerOff;
        break;
    case LightBlueAlarm:
        gDPD.mdb.cb.wr4.alarmLightBlue = PowerOff;
        break;
    default:
        break;
    }
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_4);
    //发送数据
    Changed(ITEM_CB_WR4);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  SetTestItem()
 功能描述：  设置自检项
 输入参数：  item---自检项
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetTestItem(quint32 item)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_0);
    gDPD.mdb.cb.wr0.testAlarmSound = (item & TestItemAlarmSound) ? TestEnable : TestDisable;
    gDPD.mdb.cb.wr0.testHeparinPump = (item & TestItemHeparinPump) ? TestEnable : TestDisable;
    gDPD.mdb.cb.wr0.testBloodDetect = (item & TestItemBloodDetect) ? TestEnable : TestDisable;
    gDPD.mdb.cb.wr0.testAirMonitor= (item & TestItemAirMonitor) ? TestEnable : TestDisable;
    gDPD.mdb.cb.wr0.testBloodChamberAdjust= (item & TestItemBloodChamberAdjust) ? TestEnable : TestDisable;
    gDPD.mdb.cb.wr0.testBlockingClamp= (item & TestItemBlockingClamp) ? TestEnable : TestDisable;
    gDPD.mdb.cb.wr0.testBloodPumpStandby= (item & TestItemStandbyPump) ? TestEnable : TestDisable;
    gDPD.mdb.cb.wr0.testBloodPump= (item & TestItemBloodPump) ? TestEnable : TestDisable;
    gDPD.mdb.cb.wr0.testAP= (item & TestItemAp) ? TestEnable : TestDisable;
    gDPD.mdb.cb.wr0.testVP= (item & TestItemVp) ? TestEnable : TestDisable;
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_0);
    //发送数据
    Changed(ITEM_CB_WR0);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  CorrectPressure()
 功能描述：  校正压力
 输入参数：  sensor---压力传感器，point---校正点，value---压力值
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::CorrectPressure(const PressureSensorType sensor, const CorrectPointType point, const qint16 value)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_6);
    gDPD.mdb.cb.wr6.sensor = sensor;
    gDPD.mdb.cb.wr6.pressurePoint = point;
    gDPD.mdb.cb.wr6.pressure = value;
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_6);
    //发送数据
    Changed(ITEM_CB_WR6);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  SetAirAttr()
 功能描述：  设置空气监测属性
 输入参数：  mode---模式，acc---小气泡是否累计，level---报警等级
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::SetAirAttr(const AirModeType mode, const SmallBubbleAccType acc, const BubbleSizeAlarmLevelType level)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_2);
    gDPD.mdb.cb.wr2.airMode = mode;
    gDPD.mdb.cb.wr2.smallBubbleAcc = acc;
    gDPD.mdb.cb.wr2.bubbleSize = level;
    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_2);
    //发送数据
    Changed(ITEM_CB_WR2);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  Sync()
 功能描述：  同步更改后的模块数据
 输入参数：  emergency---紧急程度
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::Sync(const bool emergency)
{
    //控制板
    if(mItems & ITEM_CB_VER)
    {
        qDebug() << "Sync: ITEM_CB_VER";    ///xxl_debug: Sync: ITEM_CB_VER
        WriteModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_VER, emergency);
    }
    if(mItems & ITEM_CB_WR0)
    {
        qDebug() << "Sync: ITEM_CB_WR0";    ///xxl_debug: Sync: ITEM_CB_WR0
        WriteModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_0, emergency);
    }
    if(mItems & ITEM_CB_WR1)
    {
        qDebug() << "Sync: ITEM_CB_WR1";    ///xxl_debug: Sync: ITEM_CB_WR1
        WriteModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_1, emergency);
    }
    if(mItems & ITEM_CB_WR2)
    {
        qDebug() << "Sync: ITEM_CB_WR2";    ///xxl_debug: Sync: ITEM_CB_WR2
        WriteModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_2, emergency);
    }
    if(mItems & ITEM_CB_WR3)
    {
        qDebug() << "Sync: ITEM_CB_WR3";    ///xxl_debug: Sync: ITEM_CB_WR3
        WriteModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3, emergency);
    }
    if(mItems & ITEM_CB_WR4)
    {
        qDebug() << "Sync: ITEM_CB_WR4";    ///xxl_debug: Sync: ITEM_CB_WR4
        WriteModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_4, emergency);
    }
    if(mItems & ITEM_CB_WR5)
    {
        qDebug() << "Sync: ITEM_CB_WR5";    ///xxl_debug: Sync: ITEM_CB_WR5
        WriteModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_5, emergency);
    }
    if(mItems & ITEM_CB_WR6)
    {
        qDebug() << "Sync: ITEM_CB_WR6";    ///xxl_debug: Sync: ITEM_CB_WR6
        WriteModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_6, emergency);
    }
    if(mItems & ITEM_CB_WR9)
    {
        qDebug() << "Sync: ITEM_CB_WR9";    ///xxl_debug: Sync: ITEM_CB_WR9
        WriteModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_9, emergency);
    }
    //监控板
    if(mItems & ITEM_MB_VER)
    {
        qDebug() << "Sync: ITEM_MB_VER";    ///xxl_debug: Sync: ITEM_MB_VER
        WriteModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_VER, emergency);
    }
    if(mItems & ITEM_MB_WR0)
    {
        qDebug() << "Sync: ITEM_MB_WR0";    ///xxl_debug: Sync: ITEM_MB_WR0
        WriteModuleBoardData(MONITOR_BOARD_ADDR, BUS_CMD_WR_0, emergency);
    }

    //重置标识
    mItems = 0;
}

/***************************************************************************************************
 函数名称：  LockModuleBoardData()
 功能描述：  获取数据锁
 输入参数：  addr---模块地址，cmd---命令
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::LockModuleBoardData(const ModuleBoardAddrType addr, const SysBusCmdType cmd)
{
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        board->LockModuleBoardDataForReadOrWrite(cmd);
    }
}

/***************************************************************************************************
 函数名称：  UnlockModuleBoardData()
 功能描述：  释放数据锁
 输入参数：  addr---模块地址，cmd---命令
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::UnlockModuleBoardData(const ModuleBoardAddrType addr, const SysBusCmdType cmd)
{
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        board->UnlockModuleBoardDataForReadOrWrite(cmd);
    }
}

/***************************************************************************************************
 函数名称：  RegisterModuleBoardCommand()
 功能描述：  注册常用的RD命令数据
 输入参数：  addr---模块地址，cmd---命令，emergency---紧急程度
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::RegisterModuleBoardCommand(const ModuleBoardAddrType addr, const SysBusCmdType cmd, const bool emergency)
{
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        DataAttributeType attr = board->DataAttribute(cmd);
        attr.dataType = emergency ? DTT_RejisterTypeDataEmc : DTT_RejisterTypeDataNor;
        emit this->SIGNALSendData(attr, QByteArray());
    }
}

/***************************************************************************************************
 函数名称：  UnregisterModuleBoardCommand()
 功能描述：  注销常用的RD命令数据
 输入参数：  addr---模块地址，cmd---命令
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::UnregisterModuleBoardCommand(const ModuleBoardAddrType addr, const SysBusCmdType cmd)
{
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        DataAttributeType attr = board->DataAttribute(cmd);
        attr.dataType = DTT_UnrejisterTypeData;
        emit this->SIGNALSendData(attr, QByteArray());
    }
}

/***************************************************************************************************
 函数名称：  WriteModuleBoardData()
 功能描述：  发送协议VER或WR命令数据
 输入参数：  addr---模块地址，cmd---命令，emergency---紧急程度
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::WriteModuleBoardData(const ModuleBoardAddrType addr, const SysBusCmdType cmd, const bool emergency)
{
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        DataAttributeType attr = board->DataAttribute(cmd);
        qDebug() << "send attr: " << QString().sprintf("0x%02x", attr.moduleAddrAndCmd.addr) << QString().sprintf("0x%02x", attr.moduleAddrAndCmd.cmd);   //send attr
        QByteArray data((char *)board->DataMapValue(cmd), board->DataLength(cmd));
        if(emergency)
        {
            attr.dataType = DTT_AlarmTypeData;
        }
        emit this->SIGNALSendData(attr, data);
    }
}

/***************************************************************************************************
 函数名称：  ReadModuleBoardData()
 功能描述：  发送协议中RD命令数据
 输入参数：  addr---模块地址，cmd---命令
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::ReadModuleBoardData(const ModuleBoardAddrType addr, const SysBusCmdType cmd)
{
    QPointer<ModuleBoardBase> board = mModuleBoardMap.value(addr, nullptr);
    if(board)
    {
        emit this->SIGNALSendData(board->DataAttribute(cmd), QByteArray());
    }
}

/***************************************************************************************************
 函数名称：  controlBloodPump()
 功能描述：  控制血泵
 输入参数：  pump---泵，control---开关，flow---流量，mode---模式，direction---方向
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::controlBloodPump(const PumpType pump, const bool control, const double flow, const PumpWorkModeType mode, const PumpDirectionType direction)
{
    //阻断夹
    if(control)
    {
        ControlBlockingClampAndChamber(BlockingClampControlOpen);   //开阻断夹
    }
    else
    {
        ControlBlockingClampAndChamber(BlockingClampControlClose);  //关阻断夹
    }

    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_1);

    quint16 fsr = 1;    //泵管系数
    //泵
    if(pump == BloodPump)
    {
        gDPD.mdb.cb.wr1.witchPump = WitchBloodPump;
        fsr = gDPD.mdb.fsr.bloodPump;
    }
    else if(pump == StandbyPump)
    {
        gDPD.mdb.cb.wr1.witchPump = WitchStandbyPump;
        fsr = gDPD.mdb.fsr.standbyPump;
    }
    //开关
    gDPD.mdb.cb.wr1.power = control ? PowerOn : PowerOff;
    if(pump == BloodPump)
    {
        mBloodPumpTargetPower = (PowerType)gDPD.mdb.cb.wr1.power;
    }
    else if(pump == StandbyPump)
    {
        mStandbyPumpTargetPower = (PowerType)gDPD.mdb.cb.wr1.power;
    }
    //目标转速
    if(flow > 0.0)
    {
        if(fsr != 0)
        {
            gDPD.mdb.cb.wr1.rpm = flow * 10 / fsr;
        }
    }
    //运转模式
    switch(mode)
    {
    case PumpWorkModeNormal:
        gDPD.mdb.cb.wr1.mode = BloodPumpWorkModeNormal;
        break;
    case PumpWorkModePipeInstall:
        gDPD.mdb.cb.wr1.mode = BloodPumpWorkModePipeInstall;
        break;
    case PumpWorkModeFsrTest:
        gDPD.mdb.cb.wr1.mode = BloodPumpWorkModeFsrTest;
        break;
    default:
        break;
    }
    //转动方向
    gDPD.mdb.cb.wr1.direction = direction;

    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_1);

    //发送数据
    Changed(ITEM_CB_WR1);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  controlHeparinPump()
 功能描述：  控制肝素泵
 输入参数：  control---开关，flow---流量，mode---模式，direction---方向
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::controlHeparinPump(const bool control, const double flow, const PumpWorkModeType mode, const PumpDirectionType direction)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);

    //开关
    gDPD.mdb.cb.wr3.hpPower = control ? PowerOn : PowerOff;
    //流量
    if(flow > 0.0)
    {
        gDPD.mdb.cb.wr3.hpFlow = flow * 10;
    }
    //模式
    switch(mode)
    {
    case PumpWorkModeNormal:
        gDPD.mdb.cb.wr3.hpMode = HeparinPumpWorkModeNormal;
        break;
    case PumpWorkModeSyringeCorrection:
        gDPD.mdb.cb.wr3.hpMode = HeparinPumpWorkModeSyringeCorrection;
        break;
    default:
        break;
    }
    //方向
    gDPD.mdb.cb.wr3.hpMoveDirection = direction;

    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);

    //发送数据
    Changed(ITEM_CB_WR3);
    Sync(false);
}

/***************************************************************************************************
 函数名称：  setBloodPumpAttr()
 功能描述：  设置血泵属性
 输入参数：  pump---泵，flow---流量，mode---模式，direction---方向，emergency---是否立即下发
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::setBloodPumpAttr(const PumpType pump, const double flow, const PumpWorkModeType mode, const PumpDirectionType direction, const bool emergency)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_1);

    quint16 fsr = 1;    //泵管系数
    //泵
    if(pump == BloodPump)
    {
        gDPD.mdb.cb.wr1.witchPump = WitchBloodPump;
        fsr = gDPD.mdb.fsr.bloodPump;
    }
    else if(pump == StandbyPump)
    {
        gDPD.mdb.cb.wr1.witchPump = WitchStandbyPump;
        fsr = gDPD.mdb.fsr.standbyPump;
    }
    //目标转速
    if(flow > 0.0)
    {
        if(fsr != 0)
        {
            gDPD.mdb.cb.wr1.rpm = flow * 10 / fsr;
        }
    }
    //运转模式
    switch(mode)
    {
    case PumpWorkModeNormal:
        gDPD.mdb.cb.wr1.mode = BloodPumpWorkModeNormal;
        break;
    case PumpWorkModePipeInstall:
        gDPD.mdb.cb.wr1.mode = BloodPumpWorkModePipeInstall;
        break;
    case PumpWorkModeFsrTest:
        gDPD.mdb.cb.wr1.mode = BloodPumpWorkModeFsrTest;
        break;
    default:
        break;
    }
    //转动方向
    gDPD.mdb.cb.wr1.direction = direction;

    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_1);

    if(emergency)
    {
        ///xxl_info 这里需不需要开关阻断夹待定，6000是做了的
        Changed(ITEM_CB_WR1);
        Sync(false);
    }
}

/***************************************************************************************************
 函数名称：  setHeparinPumpAttr()
 功能描述：  设置肝素泵属性
 输入参数：  flow---流量，mode---模式，direction---方向，emergency---是否立即下发
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoard::setHeparinPumpAttr(const double flow, const PumpWorkModeType mode, const PumpDirectionType direction, const bool emergency)
{
    LockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);

    //流量
    if(flow > 0.0)
    {
        gDPD.mdb.cb.wr3.hpFlow = flow * 10;
    }
    //模式
    switch(mode)
    {
    case PumpWorkModeNormal:
        gDPD.mdb.cb.wr3.hpMode = HeparinPumpWorkModeNormal;
        break;
    case PumpWorkModeSyringeCorrection:
        gDPD.mdb.cb.wr3.hpMode = HeparinPumpWorkModeSyringeCorrection;
        break;
    default:
        break;
    }
    //方向
    gDPD.mdb.cb.wr3.hpMoveDirection = direction;

    UnlockModuleBoardData(CONTROL_BOARD_ADDR, BUS_CMD_WR_3);

    if(emergency)
    {
        Changed(ITEM_CB_WR3);
        Sync(false);
    }
}
