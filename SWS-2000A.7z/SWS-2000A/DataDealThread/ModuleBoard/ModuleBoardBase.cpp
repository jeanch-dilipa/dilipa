#include "ModuleBoardBase.h"

/***************************************************************************************************
 函数名称：  ModuleBoardBase()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
ModuleBoardBase::ModuleBoardBase(const QMultiMap<SysBusCmdType, void *> dataMap, QObject *parent) : QObject(parent)
{
    mDataMap = dataMap;

    //创建锁和数据更新标志
    QMapIterator<SysBusCmdType, void *> it(mDataMap);
    while(it.hasNext())
    {
        it.next();
        SysBusCmdType cmd = it.key();

        //创建数据保护锁
        QMutex *lock = new QMutex();
        mLockMap.insert(cmd, lock);

        //创建并初始化数据更新标志
        mDataUpdateFlagMap.insert(cmd, false);
    }
}

/***************************************************************************************************
 函数名称：  ~ModuleBoardBase()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
ModuleBoardBase::~ModuleBoardBase()
{
}

/***************************************************************************************************
 函数名称：  DataAttribute()
 功能描述：  返回模块数据属性列表
 输入参数：  无
 返回的值：  QList<DataAttributeType>---模块数据属性列表
 ***************************************************************************************************/
QList<DataAttributeType> ModuleBoardBase::DataAttribute() const
{
    QList<DataAttributeType> attrList;
    QMapIterator<SysBusCmdType, DataAttributeType> it(mDataAttrMap);
    while(it.hasNext())
    {
        it.next();
        attrList.append(it.value());
    }
    return attrList;
}

/***************************************************************************************************
 函数名称：  DataMapValue()
 功能描述：  返回模块协议中使用的读/写命令数据
 输入参数：  cmd---读/写命令
 返回的值：  void *---模块协议中使用的读/写命令数据
 ***************************************************************************************************/
void *ModuleBoardBase::DataMapValue(const SysBusCmdType cmd)
{
    void *srcData = nullptr;

    LockModuleBoardDataForReadOrWrite(cmd);

    srcData = mDataMap.value(cmd, nullptr);

    UnlockModuleBoardDataForReadOrWrite(cmd);

    return srcData;
}

/***************************************************************************************************
 函数名称：  SetDataMapValue()
 功能描述：  设置模块协议中使用的读/写命令的数据
 输入参数：  cmd---读/写命令，data---读写地址和数据，length---数据长度
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoardBase::SetDataMapValue(const SysBusCmdType cmd, const void *data, const qint32 length)
{
    LockModuleBoardDataForReadOrWrite(cmd);

    void *dest = mDataMap.value(cmd, nullptr);
    DataAttributeType attr = mDataAttrMap.value(cmd, DataAttributeType());
    if(dest && (attr.dataLength == length))
    {
        if(dest != data)
        {
            memcpy(dest, data, length);
            SetReturnInfoUpdateStatusToLatest(cmd);     //更新数据更新标志
        }
    }
    else if(attr.dataLength != length)
    {   //接收到的数据有误
        AddReceiveWrongDataCount();
    }

    UnlockModuleBoardDataForReadOrWrite(cmd);
}

/***************************************************************************************************
 函数名称：  ResetReturnInfoUpdateStatus()
 功能描述：  重置模块返回数据标志为默认值
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoardBase::ResetReturnInfoUpdateStatus()
{
    QMapIterator<SysBusCmdType, bool> it(mDataUpdateFlagMap);
    while(it.hasNext())
    {
        it.next();
        mDataUpdateFlagMap.replace(it.key(), false);
    }
}

/***************************************************************************************************
 函数名称：  IsReturnInfoUpdateStatusLatestAndReset()
 功能描述：  判断模块返回数据是否为最新，并重置
 输入参数：  cmd---读/写命令
 返回的值：  bool---模块返回数据是否为最新
 ***************************************************************************************************/
bool ModuleBoardBase::IsReturnInfoUpdateStatusLatestAndReset(const SysBusCmdType cmd)
{
    bool value = mDataUpdateFlagMap.value(cmd);
    SetReturnInfoUpdateStatusToNotLatest(cmd);

    return value;
}

/***************************************************************************************************
 函数名称：  LockModuleBoardDataForReadOrWrite()
 功能描述：  加锁模块协议中使用的读/写命令数据
 输入参数：  cmd---读/写命令
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoardBase::LockModuleBoardDataForReadOrWrite(const SysBusCmdType cmd)
{
    QMutex *lock = mLockMap.value(cmd, nullptr);
    if(lock)
    {
        lock->lock();
    }
}

/***************************************************************************************************
 函数名称：  UnlockModuleBoardDataForReadOrWrite()
 功能描述：  解锁模块协议中使用的读/写命令数据
 输入参数：  cmd---读/写命令
 返回的值：  无
 ***************************************************************************************************/
void ModuleBoardBase::UnlockModuleBoardDataForReadOrWrite(const SysBusCmdType cmd)
{
    QMutex *lock = mLockMap.value(cmd, nullptr);
    if(lock)
    {
        lock->unlock();
    }
}
