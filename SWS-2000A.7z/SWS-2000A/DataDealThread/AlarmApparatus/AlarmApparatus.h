#ifndef ALARMAPPARATUS_H
#define ALARMAPPARATUS_H

#include <QMutex>
#include <QObject>

#include "AlarmCodeEnumDefine.h"

#define SingletonAlarmApp   (AlarmApparatus::instance())        //单例模式

class AlarmApparatus : public QObject
{
    Q_OBJECT
public:
    static AlarmApparatus *instance();      //获取唯一实例
    static void deleteInstance();           //删除本类实例

private:
    explicit AlarmApparatus(QObject *parent = nullptr);
    ~AlarmApparatus();

signals:
    void SIGNALSendAlarm(const AlarmCodeType code, const bool isAlarm);     //发送报警

public:
    bool TriggerAlarm(const AlarmCodeType code);            //触发报警
    bool IsAlarmCanBeTrigger(const AlarmCodeType code);     //该报警是否可触发
    bool IsAlarmTriggered(const AlarmCodeType code = AlarmCodeDefault);     //是否已触发该报警
    bool ResetAlarm(const AlarmCodeType code = AlarmCodeDefault, const QList<AlarmCodeType> &except = QList<AlarmCodeType>());  //重置报警
    inline quint32 AlarmCount(){ return mAlarmList.size(); };   //当前报警数

private:
    bool isBloodPumpStopedAlarmOk();    //【血泵停止】报警是否可以报

private:
    static AlarmApparatus   *smAlarmAppInstance;
    static QMutex           smMutex;
    QList<AlarmCodeType>    mAlarmList;     //报警列表
};

#endif // ALARMAPPARATUS_H
