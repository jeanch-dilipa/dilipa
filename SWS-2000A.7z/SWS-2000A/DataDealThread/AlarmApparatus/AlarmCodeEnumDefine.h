#ifndef ALARMCODEENUMDEFINE_H
#define ALARMCODEENUMDEFINE_H

///报警码类型
enum AlarmCodeType
{
    AlarmCodeDefault    = 0,

    /*********************************************************************************************
     * A类报警
     *********************************************************************************************/
    A_AlarmStart    = 1,    ///A类报警
    A_VpIsAboveTheUpperLimit    = 2,    //静脉压高于上限
    A_VpIsBelowTheLowerLimit    = 3,    //静脉压低于下限
    A_ApIsAboveTheUpperLimit    = 4,    //灌流器前压高于上限
    A_ApIsBelowTheLowerLimit    = 5,    //灌流器前压低于下限
    A_BloodPumpSpeedAbnormal    = 6,    //血泵转速异常
    A_BloodPumpStoped           = 7,    //血泵停止
    A_HeatTempIsAboveTheUpperLimit  = 8,    //保温器温度高于上限
    A_HeatTempIsBelowTheLowerLimit  = 9,    //保温器温度低于下限
    A_AirDetectedInVenousCircuit    = 10,   //静脉回路识别到空气
    A_BlockingClampNotOpen          = 11,   //静脉回流阻断夹未打开

    /*********************************************************************************************
     * B类报警
     *********************************************************************************************/
    B_AlarmStart    = 100,  ///B类报警
    B_LowBattery                        = 101,  //电池电量低
    B_SyringeReachesTheBottom           = 102,  //注射器已到底端
    B_BloodDetectedWhenPatientConnect   = 103,  //识别到血液，请连接患者

    /*********************************************************************************************
     * C类报警
     *********************************************************************************************/
    C_AlarmStart    = 200,  ///C类报警
    C_BatteryPowered        = 201,  //电池供电，保温功能将关闭
    C_HeparinBolusCompleted = 202,  //肝素推注完成
    C_EndOfTreatment        = 203   //治疗结束
};

///报警级别类型
enum AlarmLevelType
{
    AlarmLevelDefault   = 0,
    AlarmLevelA         = 1,    //A类报警
    AlarmLevelB         = 2,    //B类报警
    AlarmLevelC         = 3     //C类报警
};

#endif // ALARMCODEENUMDEFINE_H
