#include "AlarmApparatus.h"

AlarmApparatus *AlarmApparatus::smAlarmAppInstance = nullptr;
QMutex AlarmApparatus::smMutex;

/***************************************************************************************************
 函数名称：  instance()
 功能描述：  获取唯一实例
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
AlarmApparatus *AlarmApparatus::instance()
{
    if(!smAlarmAppInstance)
    {
        QMutexLocker locker(&smMutex);
        if(!smAlarmAppInstance)
        {
            smAlarmAppInstance = new AlarmApparatus();
        }
    }

    return smAlarmAppInstance;
}

/***************************************************************************************************
 函数名称：  deleteInstance()
 功能描述：  删除本类实例
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void AlarmApparatus::deleteInstance()
{
    QMutexLocker locker(&smMutex);
    if(smAlarmAppInstance)
    {
        delete smAlarmAppInstance;
        smAlarmAppInstance = nullptr;
    }
}

/***************************************************************************************************
 函数名称：  AlarmApparatus()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
AlarmApparatus::AlarmApparatus(QObject *parent) : QObject(parent)
{
}

/***************************************************************************************************
 函数名称：  ~AlarmApparatus()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
AlarmApparatus::~AlarmApparatus()
{
}

/***************************************************************************************************
 函数名称：  TriggerAlarm()
 功能描述：  触发报警
 输入参数：  code---报警码
 返回的值：  bool---触发是否成功
 ***************************************************************************************************/
bool AlarmApparatus::TriggerAlarm(const AlarmCodeType code)
{
    if(IsAlarmCanBeTrigger(code))
    {
        mAlarmList.append(code);
        emit this->SIGNALSendAlarm(code, true);

        return true;
    }

    return false;
}

/***************************************************************************************************
 函数名称：  IsAlarmCanBeTrigger()
 功能描述：  该报警是否可触发
 输入参数：  code---报警码
 返回的值：  bool---是否可触发报警
 ***************************************************************************************************/
bool AlarmApparatus::IsAlarmCanBeTrigger(const AlarmCodeType code)
{
    bool hasAlarm = mAlarmList.contains(code);
    bool result = true;

    if(!hasAlarm)
    {   //无该报警
        switch(code)
        {
        case A_BloodPumpStoped:     //【血泵停止】
            result = isBloodPumpStopedAlarmOk();
            break;
        case A_VpIsAboveTheUpperLimit:  //【静脉压高于上限】
        case A_VpIsBelowTheLowerLimit:  //【静脉压低于下限】
        case A_ApIsAboveTheUpperLimit:  //【灌流器前压高于上限】
        case A_ApIsBelowTheLowerLimit:  //【灌流器前压低于下限】
        case A_BloodPumpSpeedAbnormal:  //【血泵转速异常】
        case A_HeatTempIsAboveTheUpperLimit:    //【保温器温度高于上限】
        case A_HeatTempIsBelowTheLowerLimit:    //【保温器温度低于下限】
        case A_AirDetectedInVenousCircuit:      //【静脉回路识别到空气】
        case A_BlockingClampNotOpen:            //【静脉回路阻断夹未打开】
        case B_LowBattery:                          //【电池电量低】
        case B_SyringeReachesTheBottom:             //【注射器已到底端】
        case B_BloodDetectedWhenPatientConnect:     //【识别到血液，请连接患者】
        case C_BatteryPowered:          //【电池供电，保温功能将关闭】
        case C_HeparinBolusCompleted:   //【肝素推注完成】
        case C_EndOfTreatment:          //【治疗结束】
            ///......
            ///以上报警暂未作处理
            break;
        default:
            break;
        }
    }
    else
    {   //有该报警
        result = false;
    }

    return result;
}

/***************************************************************************************************
 函数名称：  IsAlarmTriggered()
 功能描述：  是否已触发该报警
 输入参数：  code---报警码
 返回的值：  bool---是否已触发
 ***************************************************************************************************/
bool AlarmApparatus::IsAlarmTriggered(const AlarmCodeType code)
{
    if(code == AlarmCodeDefault)
    {   //所有报警
        return (!mAlarmList.isEmpty());
    }
    else
    {   //指定报警
        return mAlarmList.contains(code);
    }
}

/***************************************************************************************************
 函数名称：  IsAlarmTriggered()
 功能描述：  ResetAlarm
 输入参数：  code---报警码，except---例外报警，当重置所有报警时有效
 返回的值：  bool---true：有该报警并正常重置，false：其他状态
 ***************************************************************************************************/
bool AlarmApparatus::ResetAlarm(const AlarmCodeType code, const QList<AlarmCodeType> &except)
{
    if(!mAlarmList.isEmpty())
    {   //有报警
        if(code == AlarmCodeDefault)
        {   //全部报警
            if(except.isEmpty())
            {   //无例外
                mAlarmList.clear();
                emit this->SIGNALSendAlarm(code, false);
            }
            else
            {   //指定例外报警
                foreach(AlarmCodeType alarm, mAlarmList)
                {
                    if(!except.contains(alarm))
                    {   //重置非例外报警
                        mAlarmList.removeAll(alarm);
                        emit this->SIGNALSendAlarm(code, false);
                    }
                }
            }
            return true;
        }
        else
        {   //指定报警
            if(mAlarmList.contains(code))
            {   //包含报警则重置
                mAlarmList.removeAll(code);
                emit this->SIGNALSendAlarm(code, false);
                return true;
            }
            else
            {   //不包含报警
                return false;
            }
        }
    }
    else
    {   //无任何报警
        return false;
    }
}

/***************************************************************************************************
 函数名称：  isBloodPumpStopedAlarmOk()
 功能描述：  【血泵停止】报警是否可以报
 输入参数：  无
 返回的值：  bool---是否可以报
 ***************************************************************************************************/
bool AlarmApparatus::isBloodPumpStopedAlarmOk()
{
    //【静脉压高于上限】
    if(mAlarmList.contains(A_VpIsAboveTheUpperLimit)){ return false; }
    //【静脉压低于下限】
    if(mAlarmList.contains(A_VpIsBelowTheLowerLimit)){ return false; }
    //【灌流器前压高于上限】
    if(mAlarmList.contains(A_ApIsAboveTheUpperLimit)){ return false; }
    //【灌流器前压低于下限】
    if(mAlarmList.contains(A_ApIsBelowTheLowerLimit)){ return false; }
    //【静脉回路识别到空气】
    if(mAlarmList.contains(A_AirDetectedInVenousCircuit)){ return false; }

    return true;
}
