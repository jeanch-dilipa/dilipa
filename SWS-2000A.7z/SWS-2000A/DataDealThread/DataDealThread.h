#ifndef DATADEALTHREAD_H
#define DATADEALTHREAD_H

#include "Commom/PublicDefine/PublicEnumDefine.h"
#include "AbstractMainProcess.h"
#include "Cure/CureMain.h"
#include "DataDealThread/PublicData/DataDealConfig.h"
#include "AlarmApparatus/AlarmApparatus.h"

#include <QHash>
#include <QObject>
#include <QPointer>

class DataDealThread : public QObject
{
    Q_OBJECT
public:
    explicit DataDealThread(QObject *parent = nullptr);
    ~DataDealThread();

signals:
    void SIGNALDataFromInterface(FunctionCodeType code, FunctionDataType type, QVariant var);   //来自界面层的数据
    void SIGNALSendToInterface(FunctionCodeType code, FunctionDataType type, QVariant var);     //发送数据到界面层
    void SIGNALSendQuery(SqlOperateType operate, QVariant var);     //执行sql

public slots:
    void SLOTDataFromInterface(FunctionCodeType code, FunctionDataType type, QVariant var);     //来自界面层的数据
    void SLOTDataFromUart(QByteArray data);     //来自UART层的数据

private:
    void analyseIntData(FunctionCodeType code, qint32 num);             //解析int
    void createNewProcess(AbstractMainProcess::MainProcessType type);   //创建新处理类
    void deleteMainProcess();                                           //删除处理类
    void connectMainProcessSignalsAndSlots();                           //链接信号槽

private:
    QPointer<AbstractMainProcess>   mMainProcess;   //当前处理类
    QPointer<AlarmApparatus>        mAlarmApp;      //报警处理类
};

#endif // DATADEALTHREAD_H
