#ifndef RS485PROTOCOLTYPE_H
#define RS485PROTOCOLTYPE_H

#include "ControlBoardType.h"   //控制板类型定义
#include "MonitorBoardType.h"   //监控板类型定义

///模块地址定义
enum ModuleBoardAddrType
{
    MODULE_BOARD_ADDR_DEFAULT   = 0x00,
    CONTROL_BOARD_ADDR          = 0x10,     //控制板地址
    MONITOR_BOARD_ADDR          = 0x11,     //监控板地址
    AIR_MONITOR_BOARD_ADDR      = 0x12      //空气监测板地址（预留）
};

///协议读写命令定义
enum SysBusCmdType
{
    BUS_CMD_INI     = 0x20,     //32，通信初始化
    BUS_CMD_ASK     = 0x21,     //33，握手
    BUS_CMD_CRC_ERR = 0x22,     //34，错误响应
    BUS_CMD_VER     = 0x23,     //35，版本信息
    //写命令，WR
    BUS_CMD_WR_0    = 0x30,     //48，WR0
    BUS_CMD_WR_1    = 0x31,     //49，WR1
    BUS_CMD_WR_2    = 0x32,     //50，WR2
    BUS_CMD_WR_3    = 0x33,     //51，WR3
    BUS_CMD_WR_4    = 0x34,     //52，WR4
    BUS_CMD_WR_5    = 0x35,     //53，WR5
    BUS_CMD_WR_6    = 0x36,     //54，WR6
    BUS_CMD_WR_7    = 0x37,     //55，WR7
    BUS_CMD_WR_8    = 0x38,     //56，WR8
    BUS_CMD_WR_9    = 0x39,     //57，WR9
    //读命令，RD
    BUS_CMD_RD_0    = 0x40,     //64，RD0
    BUS_CMD_RD_1    = 0x41,     //65，RD1
    BUS_CMD_RD_2    = 0x42,     //66，RD2
    BUS_CMD_RD_3    = 0x43,     //67，RD3
    BUS_CMD_RD_4    = 0x44,     //68，RD4
    BUS_CMD_RD_5    = 0x45,     //69，RD5
    BUS_CMD_RD_6    = 0x46,     //70，RD6
    BUS_CMD_RD_7    = 0x47,     //71，RD7
    BUS_CMD_RD_8    = 0x48      //72，RD8
};

///串口工作模式定义
enum UartModeType
{
    UMT_Normal = 0,
    UMT_RS485,      //RS485
    UMT_RS232       //RS232
};

///定义模块数据属性
struct ModuleBoardAddrAndCmd
{
    explicit ModuleBoardAddrAndCmd(const ModuleBoardAddrType _addr = MODULE_BOARD_ADDR_DEFAULT, const SysBusCmdType _cmd = BUS_CMD_WR_0) : addr(_addr), cmd(_cmd){}
    ModuleBoardAddrAndCmd(const ModuleBoardAddrAndCmd &other){ *this = other; }
    ModuleBoardAddrAndCmd & operator =(const ModuleBoardAddrAndCmd &other)
    {
        addr    = other.addr;
        cmd     = other.cmd;
        return *this;
    }
    bool operator ==(const ModuleBoardAddrAndCmd &other)
    {
        if((addr == other.addr) && (cmd == other.cmd))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    ModuleBoardAddrType addr;   //模块地址
    SysBusCmdType       cmd;    //读命令或写命令
}__attribute__((packed));

///定义数据下发类型
enum DataTypeType
{
    DTT_AlarmTypeData = 0,      //报警控制下发数据
    DTT_WriteTypeData,          //写命令下发数据
    DTT_ReadTypeData,           //读命令下发数据
    DTT_RejisterTypeDataEmc,    //注册信息下发数据，紧急
    DTT_RejisterTypeDataNor,    //注册信息下发数据，常规
    DTT_UnrejisterTypeData,     //注销信息下发数据
    DTT_UnrejisterAllData,      //注销所有数据
    DTT_UpdateTypeData,         //模块返回数据
    DTT_ClearAllRegisterData,   //清理所有注册队列的数据
    DTT_UpdateBoardTypeData,    //升级板子命令数据
    DTT_ClearAllQueueData       //清理所有队列中的数据
};

///定义下发数据属性
struct DataAttributeType
{
    explicit DataAttributeType(const ModuleBoardAddrAndCmd _moduleAddr, const UartModeType _uartMode = UMT_RS485,
                               const DataTypeType _dataType = DTT_AlarmTypeData, const qint32 _dataLength = 0):
        moduleAddrAndCmd(_moduleAddr), uartMode(_uartMode), dataType(_dataType), dataLength(_dataLength){}
    DataAttributeType()
    {
        moduleAddrAndCmd    = ModuleBoardAddrAndCmd();
        uartMode            = UMT_RS485;
        dataType            = DTT_AlarmTypeData;
        dataLength          = 0;
    }
    DataAttributeType & operator =(const DataAttributeType &other)
    {
        moduleAddrAndCmd    = other.moduleAddrAndCmd;
        uartMode            = other.uartMode;
        dataType            = other.dataType;
        dataLength          = other.dataLength;
        return *this;
    }

    ModuleBoardAddrAndCmd   moduleAddrAndCmd;   //模块地址已经读写命令
    UartModeType            uartMode;           //串口模式
    DataTypeType            dataType;           //数据下发类型
    qint32                  dataLength;         //数据长度
}__attribute__((packed));

///定义读写uart数据结果类型
enum WrittenReadUartDataResult
{
    WRR_Success         = 1,    //读写UART成功
    WRR_ReadTimeOut     = 'T',  //读UART超时
    WRR_CrcCheckError   = 'C',  //CRC校验错,通信错误
    WRR_DataDeleteError = 'D'   //数据被删除
};

///泵管系数结构信息
struct FSR
{
    quint16     bloodPump;      //血泵，放大10倍，ml/r
    quint16     standbyPump;    //备用泵，放大10倍，ml/r
};

///模块板结构信息，Module Board
struct MDB
{
    CB  cb;     //控制板
    MB  mb;     //监控板
    FSR fsr;    //泵管系数
};
#endif // RS485PROTOCOLTYPE_H
