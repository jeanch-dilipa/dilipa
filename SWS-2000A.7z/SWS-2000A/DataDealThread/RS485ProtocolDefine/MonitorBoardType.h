#ifndef MONITORBOARDTYPE_H
#define MONITORBOARDTYPE_H

#include <QtGlobal>

/*****************************************************************************/
// 备注：结构体成员前加了"/**/"表示暂未使用或未在ModuleBoard类中封装函数接口 //
/*****************************************************************************/

///版本信息命令
struct MB_VER
{
    ///[0]，2 Byte
    quint16         code;           //部件标识码
    ///[2]，2 Byte
    quint16         hardwareVer;    //硬件版本
    ///[4]，2 Byte
    quint16         softwareVer;    //软件版本
    ///[6]，4 Byte
    quint32         batchNum;       //批次号
    ///[10]，4 Byte
    quint32         :32;            //（预留）
}__attribute__((packed));

///温度补偿
struct MB_WR0
{
    ///[0]，1 Byte
    quint8      heaterPower:1;  //D0，0/1---停止加热/加热
    quint8      mainPower:1;    //D1，0/1---整机电源关机/开机
    quint8      :6;             //D7~D2，（预留）
    ///[1]，2 Byte
    quint16     temp;           //保温器设置温度
    ///[3]，2 Byte
    quint16     tempLow;        //保温器温度下限
    ///[5]，2 Byte
    quint16     tempHigh;       //保温器温度上限
    ///[7]，2 Byte
    qint16      tempOffset;     //WG2温度补偿值 ///xxl_info: 只需要1字节
}__attribute__((packed));

///温度信息
struct MB_RD0
{
    ///[0]，1 Byte
    quint8      :7;             //D6-D0，（预留）
    quint8      wg2Abnormal:1;  //D7，0/1---传感器WG2数据正常/异常
    ///[1]，2 Byte
    quint16     wg2Val;         //传感器WG2实时温度值
    ///[3]，1 Byte
    qint8       wg2Offset;      //WG2温度补偿值
}__attribute__((packed));

///各种监控状态
struct MB_RD1
{
    ///[0]，1 Byte
    quint8      powerSupply:1;          //D0，供电方式，0/1---市电供电/电池供电
    quint8      electricAbnormal:1;     //D1，0/1---市电正常/市电异常
    quint8      batteryAbnormal:1;      //D2，0/1---电池正常/电池异常
    quint8      batteryCharge:1;        //D3，0/1---充电完成/电池充电中
    quint8      alarmLightAbnormal:1;   //D4，0/1---报警灯正常/报警灯异常
    quint8      :3;                     //D7-D5，（预留）
    ///[1]，1 Byte
    quint8      batteryLevel;           //电池电量百分比
    ///[2]，1 Byte
    quint8      power12V;               //电源12V输出实际电压
    ///[3]，2 Byte
    quint16     power24V;               //电源24V输出实际电压
    ///[5]，2 Byte
    quint16     batteryVoltage;         //电池电压
}__attribute__((packed));

///软硬件版本信息
struct MB_RD7
{
    ///[0]，2 Byte
    quint16     code;           //部件标识码
    ///[2]，2 Byte
    quint16     hardwareVer;    //硬件版本
    ///[4]，2 Byte
    quint16     softwareVer;    //控制板软件版本
    ///[6]，4 Byte
    quint32     batchNum;       //批次号
    ///[10]，4 Byte
    quint32     :32;            //预留
}__attribute__((packed));

///升级状态信息
struct MB_RD8
{
    ///[0]，1 Byte
/**/quint8      nextNum;    //发送对应数据帧
    ///[1]，1 Byte
/**/quint8      writedSum;  //已写入数据量
}__attribute__((packed));

///监控板定义，Monitor Board
struct MB
{
    MB_VER  ver;    //版本信息命令
    MB_WR0  wr0;    //温度补偿
    MB_RD0  rd0;    //温度信息
    MB_RD1  rd1;    //各种监控状态
    MB_RD7  rd7;    //软硬件版本信息
    MB_RD8  rd8;    //升级状态信息
}__attribute__((packed));

#endif // MONITORBOARDTYPE_H
