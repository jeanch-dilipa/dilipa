#ifndef CONTROLBOARDTYPE_H
#define CONTROLBOARDTYPE_H

#include <QtGlobal>

/*****************************************************************************/
// 备注：结构体成员前加了"/**/"表示暂未使用或未在ModuleBoard类中封装函数接口 //
/*****************************************************************************/

///版本信息命令
struct CB_VER
{
    ///[0]，2 Byte
    quint16     code;           //部件标识码
    ///[2]，2 Byte
    quint16     hardwareVer;    //硬件版本
    ///[4]，2 Byte
    quint16     softwareVer;    //软件版本
    ///[6]，4 Byte
    quint32     batchNum;       //批次号
    ///[10]，4 Byte
    quint32     :32;            //（预留）
}__attribute__((packed));

///自检命令
struct CB_WR0
{
    ///[0]，1 Byte
    quint8      testAlarmSound:1;           //D0，0/1---报警音不自检/自检
    quint8      testHeparinPump:1;          //D1，0/1---肝素泵不自检/自检
    quint8      testBloodDetect:1;          //D2，0/1---血液识别不自检/自检
    quint8      testAirMonitor:1;           //D3，0/1---空气监测不自检/自检
    quint8      testBloodChamberAdjust:1;   //D4，0/1---液位调节组件不自检/自检
    quint8      testBlockingClamp:1;        //D5，0/1---阻断夹不自检/自检
    quint8      testBloodPumpStandby:1;     //D6，0/1---备用泵不自检/自检
    quint8      testBloodPump:1;            //D7，0/1---血泵不自检/自检
    ///[1]，1 Byte
    quint8      :6;                         //D5~D0，(预留)
    quint8      testAP:1;                   //D6，灌流器前压不自检/自检
    quint8      testVP:1;                   //D7，静脉压不自检/自检
    ///[2]，1 Byte
    quint8      :8;                         //（预留）
}__attribute__((packed));

///血泵、备用泵控制命令
struct CB_WR1
{
    ///[0]，1 Byte
    quint8      mode:2;             //D1~D0，运转模式，00/01/10/11---正常运转模式/管路安装缓动模式（点动）/泵管系数测试模式（转10转后自动停止）/（预留）
    quint8      direction:1;        //D2，0/1---顺时针/逆时针旋转
    quint8      power:1;            //D3，0/1---关机/开机
    quint8      clearAccRound:1;    //D4，0/1---累计转数不清零/清零
    quint8      :2;                 //D6~D5，（预留）
    quint8      witchPump:1;        //D7，0/1---血泵/备用泵
    ///[1]，1 Byte
    quint8      :8;                 //（预留）
    ///[2]，2 Byte
    quint16     rpm;                //目标转速
    ///[4]，4 Byte
    quint32     :32;                //（预留）
}__attribute__((packed));

///阻断夹、空气、液面调节控制命令
struct CB_WR2
{
    ///[0]，1 Byte
    quint8      blockingClampPower;     //0/1---阻断夹关/开
    ///[1]，1 Byte
    quint8      venousBloodChamber:1;   //D0，0/1---静脉壶电磁阀关/开
    quint8      arterialBloodChamber:1; //D1，0/1---动脉壶电磁阀关/开
    quint8      pumpMode:2;             //D3~D2，00/01/10/11---（预留）/泵注入气体/泵抽出气体/泵停止工作
    quint8      :4;                     //D7~D4，（预留）
    ///[2]，1 Byte
    quint8      bubbleSize:2;           //D1~D0，00/01/10/11---报警等级0（50uL大气泡）/报警等级1（30uL大气泡）/报警等级2（20uL大气泡）/（预留）
    quint8      :1;                     //D2，（预留）
    quint8      smallBubbleAcc:1;       //D3，0/1---小气泡累计/不累计
    quint8      airMode:3;              //D6~D4，000/001/010/011/100---自检/预充/引血/治疗/回血
    quint8      :1;                     //D7，（预留）
    ///[3]，2 Byte
    quint16     :16;                    //（预留）
}__attribute__((packed));

///肝素泵控制命令，HeparinPump/hp
struct CB_WR3
{
    ///[0]，1 Byte
    quint8      hpMode:2;           //D1~D0，00/01---正常运转/注射器校正
    quint8      hpMoveDirection:1;  //D2，0/1---前进/后退
    quint8      hpPower:1;          //D3，0/1---关机/开机
    quint8      hpClearAccFlow:1;   //D4，0/1---流量累计/流量清零
    quint8      :3;                 //D7~D5，预留
    ///[1]，1 Byte
    quint8      syringeType;        //注射器型号，0-未安装/10-10ml/20-20ml/30-30ml/50-50ml
    ///[2]，2 Byte
    quint16     hpFlow;             //推注流量
}__attribute__((packed));

///按键灯、报警灯控制命令
struct CB_WR4
{
    ///[0]，1 Byte
    quint8      bloodLight:1;           //D0，0/1---血泵灯灭/亮
    quint8      :7;                     //D7~D1，（预留）
    ///[1]，1 Byte
    quint8      alarmLightRed:1;        //D0，0/1---红灯灭/亮
    quint8      alarmLightGreen:1;      //D1，0/1---绿灯灭/亮
    quint8      alarmLightBlue:1;       //D2，0/1---蓝灯灭/亮
    quint8      alarmLightFlicker:1;    //D3，0/1---闪烁/常亮
    quint8      :4;                     //D7~D4，（预留）
    ///[2]，2 Byte
    quint16     :16;                    //（预留）
}__attribute__((packed));

///加热控制命令，heat，temp
struct CB_WR5
{
    ///[0]，1 Byte
    quint8      heaterPower:1;      //D0，0/1---停止加热/加热
    quint8      :7;                 //D7~D1，（预留）
    ///[1]，2 Byte
    quint16     temp;               //保温器设置温度
    ///[3]，2 Byte
    quint16     tempLow;            //保温器温度下限
    ///[5]，2 Byte
    quint16     tempHigh;           //保温器温度上限
    ///[7]，1 Byte
    qint8       tempOffset;         //保温器温度补偿值
}__attribute__((packed));

///静脉压、灌流器前压压力校正
struct CB_WR6
{
    ///[0]，1 Byte
    quint8      sensor;         //1/2/3/4---灌流器前压传感器/静脉压传感器/备用动脉压传感器/备用静脉压传感器
    ///[1]，1 Byte
    quint8      pressurePoint;  //0/1/2---零点/负压/正压
    ///[2]，2 Byte
    qint16      pressure;       //校正时的压力值
}__attribute__((packed));

///CB_WR8，复位重启命令，0字节

///升级命令
struct CB_WR9
{
    ///[0]，1 Byte
/**/quint8      sum;            //APP数据帧总量
    ///[1]，1 Byte
/**/quint8      num;            //当前帧数据编号
    ///[2]，1024 Byte
/**/quint8      data[1024];     //APP程序代码
}__attribute__((packed));

///自检信息，test，HeparinPump/hp
struct CB_RD0
{
    ///[0]，1 Byte
    quint8      testStatus;                 //0-正常状态/1-正在自检/2-自检完成
    ///[1]，1 Byte
    quint8      testBloodPump:2;            //D1~D0，00-血泵自检正常/01-血泵泵盖开/10-血泵转速为零/11-血泵转速异常
    quint8      testStandbyPump:2;          //D3~D2，00-备用泵自检正常/01-备用泵泵盖开/10-备用泵转速为零/11-备用泵转速异常
    quint8      testBlockingClamp:2;        //D5~D4，00-阻断夹自检正常/01-未检测到打开和关闭信号/10-一直检测到打开信号/11-一直检测到关闭信号
    quint8      testBloodChamberAdjust:2;   //D7~D6，00-液位调节组件自检正常/01-液位调节组件自检异常
    ///[2]，1 Byte
    quint8      testHeparinPump:3;          //D2~D0，000-肝素泵自检正常/001-肝素泵转速为零/010---同时检测到到顶和到底信号/011-未检测到到顶信号/100-未检测到到底信号
    quint8      testBloodDetect:2;          //D4~D3，00-血液识别自检正常/01-未接收到信号/10-接收到信号值偏低
    quint8      testAirMonitor:2;           //D6~D5，00-空气自检正常/01-接收信号值偏高
    quint8      testAlarmSound:1;           //D7，0/1---报警音自检正常/异常
    ///[3]，1 Byte
    quint8      testVP:2;                   //D1~D0，00-静脉压自检正常/01-压力传感器漂移/10-压力传感器或AD芯片损坏
    quint8      testAP:2;                   //D3~D2，00-灌流器前压自检正常/01-压力传感器漂移/10-压力传感器或AD芯片损坏
/**/quint8      testStandbyVP:2;            //D5~D4，00-备用静脉压自检正常/01-压力传感器漂移/10-压力传感器或AD芯片损坏
/**/quint8      testStandbyAP:2;            //D7~D6，00-备用动脉压自检正常/01-压力传感器漂移/10-压力传感器或AD芯片损坏
}__attribute__((packed));

///血泵运行参数，BloodPump/bp
struct CB_RD1
{
    ///[0]，1 Byte
    quint8      bpCover:1;          //D0，0/1---血泵盖闭合/开启
    quint8      bpSpeedAbnormal:1;  //D1，0/1---血泵转速正常/异常
    quint8      bpDirection:1;      //D2，0/1---顺时针，逆时针
    quint8      bpPower:1;          //D3，0/1---关机/开机
    quint8      :4;                 //D7~D4，（预留）
    ///[1]，1 Byte
    quint8      :8;                 //（预留）
    ///[2]，2 Byte
    quint16     bpRpm;              //血泵目标转速
    ///[4]，2 Byte
    quint16     bpRpmRealtime;      //血泵实时转速
    ///[6]，4 Byte
    quint32     bpAccRound;         //血泵累计转数
    ///[10]，4 Byte
    quint32     :32;                //（预留）
}__attribute__((packed));

///备用泵运行参数，StandbyPump/sp
struct CB_RD2
{
    ///[0]，1 Byte
    quint8      spCover:1;          //D0，0/1---备用泵盖闭合/开启
    quint8      spSpeedAbnormal:1;  //D1，0/1---备用泵转速正常/异常
    quint8      spDirection:1;      //D2，0/1---顺时针，逆时针
    quint8      spPower:1;          //D3，0/1---关机/开机
    quint8      :4;                 //D7~D4，（预留）
    ///[1]，1 Byte
    quint8      :8;                 //（预留）
    ///[2]，2 Byte
    quint16     spRpm;              //备用泵目标转速
    ///[4]，2 Byte
    quint16     spRpmRealtime;      //备用泵实时转速
    ///[6]，4 Byte
    quint32     spAccRound;         //备用泵累计转数
    ///[10]，4 Byte
    quint32     :32;                //（预留）
}__attribute__((packed));

///空气、阻断夹、按键状态
struct CB_RD3
{
    ///[0]，1 Byte
    quint8      blockingClampPower:1;           //D0，0/1---阻断夹打开/关闭
    quint8      blockingClampSignalWhenOpen:1;  //D1，0/1---阻断夹信号为打开/关闭（阻断夹打开时）
    quint8      blockingClampSignalWhenClose:1; //D2，0/1---阻断夹信号为关闭/打开（阻断夹关闭时）
    quint8      airDetectedSingleBubble:1;      //D3，0/1---无空气/有空气（单个气泡）
    quint8      airDetectedAccBubble:1;         //D4，0/1---无空气/有空气（累计气泡）
    quint8      bloodDetected:1;                //D5，0/1---血液回路中无血液/有血液
    quint8      :2;                             //D7~D6，（预留）
    ///[1]，1 Byte
/**/quint8      keyVal;                         //0-无按键/1-血泵键/2-静音键
    ///[2]，4 Byte
    quint32     :32;                            //（预留）
}__attribute__((packed));

///肝素泵运行参数，HeparinPump/hp
struct CB_RD4
{
    ///[0]，1 Byte
    quint8      hpMoveDirection:1;  //D0，0/1---前进/后退
    quint8      hpPower:1;          //D1，0/1---关机/开机
    quint8      hpBottom:1;         //D2，0/1---未到底/到底
    quint8      hpTop:1;            //D3，0/1---未到顶/到顶
    quint8      hpStall:2;          //D5~D4，肝素泵自检状态，00-未堵转/01-堵转（未检测到转速信号）/10-堵转（转速信号较正常值低）
    quint8      :2;                 //D7~D6，（预留）
    ///[1]，4 Byte
    quint32     hpAccFlow;          //累计流量
    ///[5]，2 Byte
    quint16     hpFlowRealtime;     //实时流量
    ///[7]，2 Byte
    quint16     hpRpmRealtime;      //实时转速
}__attribute__((packed));

///温度传感器信息
struct CB_RD5
{
    ///[0]，1 Byte
    quint8      :7;             //D6~D0，（预留）
    quint8      wg1Abnormal:1;  //D7，0/1---传感器WG1数据正常/异常
    ///[1]，2 Byte
    quint16     wg1Val;         //传感器WG1实时温度值
    ///[3]，2 Byte
    qint16      wg1Offset;      //WG1温度补偿值      ///xxl_info: 这里只需要1字节
}__attribute__((packed));

///灌流器前压、静脉压传感器信息
struct CB_RD6
{
    ///[0]，1 Byte
    quint8      :6;                     //D5~D0，预留
    quint8      vpSensorValAbnormal:1;  //D6，0/1---静脉压传感器校正值正常/异常
    quint8      apSensorValAbnormal:1;  //D7，0/1---灌流器前压传感器校正值正常/异常
    ///[1]，2 Byte
    qint16      apOriginal;             //灌流器前压传感器实时值（未滤波）
    ///[3]，2 Byte
    qint16      ap;                     //灌流器前压传感器实时值
    ///[5]，2 Byte
    qint16      vpOriginal;             //静脉压传感器实时值（未滤波）
    ///[7]，2 Byte
    qint16      vp;                     //静脉压传感器实时值
    ///[9]，2 Byte
    qint16      standbyApOriginal;      //备用动脉压传感器实时值（未滤波）
    ///[11]，2 Byte
    qint16      standbyAp;              //备用动脉压传感器实时值
    ///[13]，2 Byte
    qint16      standbyVpOriginal;      //备用静脉压传感器实时值（未滤波）
    ///[15]，2 Byte
    qint16      standbyVp;              //备用静脉压传感器实时值
}__attribute__((packed));

///软硬件版本信息
struct CB_RD7
{
    ///[0]，2 Byte
    quint16     code;           //部件标识码
    ///[2]，2 Byte
    quint16     hardwareVer;    //硬件版本
    ///[4]，2 Byte
    quint16     softwareVer;    //控制板软件版本
    ///[6]，4 Byte
    quint32     batchNum;       //批次号
    ///[10]，4 Byte
    quint32     :32;            //预留
}__attribute__((packed));

///升级状态信息
struct CB_RD8
{
    ///[0]，1 Byte
/**/quint8      nextNum;    //发送对应数据帧
    ///[1]，1 Byte
/**/quint8      writedSum;  //已写入数据量
}__attribute__((packed));

///控制板定义，Control Board
struct CB
{
    CB_VER  ver;    //版本信息命令
    CB_WR0  wr0;    //自检命令
    CB_WR1  wr1;    //血泵、备用泵控制命令
    CB_WR2  wr2;    //阻断夹、空气、液面调节控制命令
    CB_WR3  wr3;    //肝素泵控制命令
    CB_WR4  wr4;    //按键灯、报警灯控制命令
    CB_WR5  wr5;    //加热控制命令
    CB_WR6  wr6;    //静脉压、灌流器前压压力校正
    CB_WR9  wr9;    //升级命令
    CB_RD0  rd0;    //自检信息
    CB_RD1  rd1;    //血泵运行参数
    CB_RD2  rd2;    //备用泵运行参数
    CB_RD3  rd3;    //空气、阻断夹、按键状态
    CB_RD4  rd4;    //肝素泵运行参数
    CB_RD5  rd5;    //温度传感器信息
    CB_RD6  rd6;    //灌流器前压、静脉压传感器信息
    CB_RD7  rd7;    //软硬件版本信息
    CB_RD8  rd8;    //升级状态信息
}__attribute__((packed));

#endif // CONTROLBOARDTYPE_H
