#include "CureMain.h"

#include <QTimer>
#include <QVariant>

/***************************************************************************************************
 函数名称：  CureMain()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
CureMain::CureMain(QObject *parent) : AbstractMainProcess(parent)
{
    mCurrentProcess = AbstractMainProcess::MPT_Cure;    //初始化子类实例类型

    //发送到界面的，也需要数据层重新解析一次
    connect(this, &CureMain::SIGNALSendToInterface, this, &CureMain::SLOTDataFromInterface, Qt::UniqueConnection);

    //治疗时间定时器
    mClockTimer = new QTimer(this);
    connect(mClockTimer, &QTimer::timeout, this, &CureMain::slotClockTimer, Qt::UniqueConnection);
    mClockTimer->start(1000);

    //1s更新定时器
    mOneSecUpdateTimer = new QTimer(this);
    connect(mOneSecUpdateTimer, &QTimer::timeout, this, &CureMain::slotOneSecUpdateTimer, Qt::UniqueConnection);
    mOneSecUpdateTimer->start(1000);

    //500ms更新定时器
    mHalfSecUpdateTime = new QTimer(this);
    connect(mHalfSecUpdateTime, &QTimer::timeout, this, &CureMain::slotHalfSecUpdateTimer, Qt::UniqueConnection);
    mHalfSecUpdateTime->start(500);
}

/***************************************************************************************************
 函数名称：  SLOTDataFromInterface()
 功能描述：  来自界面层的数据
 输入参数：  无
 返回的值：  code：功能码 | type：数据类型 | var：数据
 ***************************************************************************************************/
void CureMain::SLOTDataFromInterface(FunctionCodeType code, FunctionDataType type, QVariant var)
{
    switch(type)
    {
    case FDT_Numeric:
        analyseIntData(code, var.toInt());
        break;
    case FDT_Decimal:
        analyseDoubleData(code, var.toDouble());
        break;
    case FDT_Boolean:
        analyseBoolData(code, var.toBool());
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  slotClockTimer()
 功能描述：  治疗时间定时器槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void CureMain::slotClockTimer()
{
    quint32 displayTime = 0;    //显示时间

    switch(mWorkMode)
    {
    case WMT_CureRun:
        if(mTime.cureRun.UpdateCureTimeAndIsOver())
        {   //治疗时间到
            emit SIGNALSendToInterface(FCT_WorkMode, FDT_Numeric, WMT_CureEnd);     //工作模式：治疗结束
        }
        displayTime = mTime.cureRun.GetRemainTime();
        break;
    default:
        break;
    }

    emit SIGNALSendToInterface(FCT_DisplayTime, FDT_Numeric, displayTime);  //显示时间
}

/***************************************************************************************************
 函数名称：  slotOneSecUpdateTimer()
 功能描述：  1s更新定时器槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void CureMain::slotOneSecUpdateTimer()
{
    updateBloodBackControl();       //检测回血控制
}

/***************************************************************************************************
 函数名称：  slotHalfSecUpdateTimer()
 功能描述：  500ms更新定时器槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void CureMain::slotHalfSecUpdateTimer()
{
    updateBloodPumpAccVolume();
    ///xxl_todo: slotHalfSecUpdateTimer
}

/***************************************************************************************************
 函数名称：  analyseIntData()
 功能描述：  解析int
 输入参数：  code：功能码 | num：数据
 返回的值：  无
 ***************************************************************************************************/
void CureMain::analyseIntData(FunctionCodeType code, qint32 num)
{
    switch(code)
    {
    case FCT_WorkMode:      //工作模式
        mWorkMode = (WorkModeType)num;
        switch(num)
        {
        case WMT_SelfCheck:     //自检
            emit SIGNALSendToInterface(FCT_BloodPumpFlow, FDT_Numeric, 100);    //血泵流量默认100ml/min
            emit SIGNALSendToInterface(FCT_PrimingVolume, FDT_Numeric, 2000);   //预充总量默认为2000ml
            mTime.cureRun.Clear();
            selfCheck();
            break;
        case WMT_CureRun:   //治疗结束
            mTime.cureRun.Reset();  //重置治疗时间
            break;
        case WMT_BloodBack:
            emit SIGNALSendToInterface(FCT_PrimingVolume, FDT_Numeric, 2000);   //预充总量默认未2000ml
            break;
        default:
            break;
        }
        break;
    case FCT_CureRunTime:   //治疗时间
        if(mWorkMode == WMT_PatientConnect || mWorkMode == WMT_CureRun || mWorkMode == WMT_CureEnd)
        {   //引血、治疗运行、治疗结束
            if(mTime.cureRun.SetSetTimeAndIsOver(num))
            {
                emit SIGNALSendToInterface(FCT_DisplayTime, FDT_Numeric, mTime.cureRun.GetRemainTime());        //显示时间
                emit SIGNALSendToInterface(FCT_WorkMode, FDT_Numeric, WMT_CureEnd);                             //工作模式：治疗结束
            }
        }
        break;
    case FCT_PrimingStep:   //预充步骤
        mPrimingStep = (PrimingStepType)num;
        break;
    case FCT_BloodBackStep:     //回血步骤
        mBloodBackStep = (BloodBackStepType)num;
        if(mBloodBackStep == BBST_Backed)
        {   //重置回血计时
            mBloodBackTimeCount = BLOOD_BACK_DEFAULT_TIME;
        }
        break;
    case FCT_BloodPumpFlow:     //血泵流量
        mBloodPumpFlow = num;
        break;
    case FCT_PrimingVolume:     //预充总量
        mPrimingVolume = num;
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  analyseDoubleData()
 功能描述：  解析double
 输入参数：  code：功能码 | num：数据
 返回的值：  无
 ***************************************************************************************************/
void CureMain::analyseDoubleData(FunctionCodeType code, double num)
{
    switch(code)
    {
    case FCT_BloodPumpAccVolume:
        mBloodPumpAccVolume = num;
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  analyseBoolData()
 功能描述：  解析bool
 输入参数：  code：功能码 | var：数据
 返回的值：  无
 ***************************************************************************************************/
void CureMain::analyseBoolData(FunctionCodeType code, bool var)
{
    switch(code)
    {
    case FCT_BloodPumpSwitch:
        if(var)
        {   //开血泵
            gDPD.mb.OpenPump(BloodPump, mBloodPumpFlow);
        }
        else
        {   //关血泵
            gDPD.mb.ClosePump(BloodPump);
        }
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  selfCheck()
 功能描述：  自检
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void CureMain::selfCheck()
{
    QTimer::singleShot(5000, this, [this](){
        emit this->SIGNALSendToInterface(FCT_SelfCheckStep, FDT_Numeric, SCST_Checked);     //5s后自检完成
    });
}

/***************************************************************************************************
 函数名称：  bloodBack()
 功能描述：  回血
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void CureMain::bloodBack()
{
    QTimer::singleShot(5000, this, [this](){
        emit this->SIGNALSendToInterface(FCT_BloodBackStep, FDT_Numeric, BBST_Backed);  //5s后回血完成
    });
}

/***************************************************************************************************
 函数名称：  updateBloodPumpAccVolume()
 功能描述：  更新血泵累积量
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void CureMain::updateBloodPumpAccVolume()
{
    switch(mWorkMode)
    {
    case WMT_SelfCheck:     //自检
        mBloodPumpAccVolume = 0;
        break;
    case WMT_Priming:       //预充
        if((mPrimingStep == PST_Filling) || (mPrimingStep == PST_Refilling))
        {
            mBloodPumpAccVolume += mBloodPumpFlow/120.0;    //这里除以120是因为500ms更新，相当于每500ms的血泵累计量
            if(mBloodPumpAccVolume >= mPrimingVolume)
            {   //达到预充总量
                emit SIGNALSendToInterface(FCT_PrimingStep, FDT_Numeric, PST_Filled);
            }
        }
        break;
    default:
        break;
    }

    emit SIGNALSendToInterface(FCT_BloodPumpAccVolume, FDT_Decimal, mBloodPumpAccVolume);   //更新界面血泵累积量
}

/***************************************************************************************************
 函数名称：  updateBloodBackControl()
 功能描述：  检测回血控制
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void CureMain::updateBloodBackControl()
{
    /******************************************************************************************
     * 1. 回血达到设置的回血量，或回血时间达到5min时，自动关闭血泵；
     * 2. 回血未完成过程中，如果血泵被关闭，则血泵再次开启时，继续之前的回血量累计和时间累计；
     * 3. 回血完成后，如果开启血泵，则重置回血量和回血时间，并重新之前的判断。
     ******************************************************************************************/
    if((mWorkMode == WMT_BloodBack) && (mBloodBackStep == BBST_Backing))
    {
        if(mBloodBackTimeCount == 0)
        {   //回血时间到
            emit SIGNALSendToInterface(FCT_BloodBackStep, FDT_Numeric, BBST_Backed);
        }
        else
        {   //回血时间未到
            mBloodBackTimeCount--;
        }
    }
}

/***************************************************************************************************
 函数名称：  SetSetTimeAndIsOver()
 功能描述：  设置<设置时间>，并判断是否达到<治疗时间>
 输入参数：  setTime：<设置时间>
 返回的值：  bool：是否达到<治疗时间>
 ***************************************************************************************************/
bool CureTimeCell::SetSetTimeAndIsOver(qint32 set)
{
    if(set <= runTime)
    {   //预设置时间 <= 运行时间
        setTime = set;
        remainTime = 0;
        return true;
    }
    else
    {   //预设置时间 > 运行时间
        setTime = set;
        remainTime = setTime - runTime;
        return false;
    }
}

/***************************************************************************************************
 函数名称：  UpdateCureTimeAndIsOver()
 功能描述：  更新<治疗时间>，并判断是否达到<治疗时间>
 输入参数：  无
 返回的值：  bool：是否达到<治疗时间>
 ***************************************************************************************************/
bool CureTimeCell::UpdateCureTimeAndIsOver()
{
    if(!firstSec)
    {   //非第一秒，正常更新
        if(remainTime == 0)
        {   //剩余时间 == 0
            return true;
        }
        else
        {   //剩余时间 > 0
            remainTime--;
            runTime++;
            return false;
        }
    }
    else
    {   //第一秒不更新，保证界面显示时间是从设置的时间开始计时
        firstSec = false;
        return false;
    }
}

/***************************************************************************************************
 函数名称：  SetCureTimeOnlyForRecovery()
 功能描述：  设置<治疗时间>，仅在恢复治疗数据时可调用！！！！！！
 输入参数：  set：恢复的设置时间, run：恢复的运行时间, remain：恢复的剩余时间
 返回的值：  无
 ***************************************************************************************************/
void CureTimeCell::SetCureTimeOnlyForRecovery(qint32 set, qint32 run, qint32 remain)
{
    /**************************************
     * 请务必仅用于恢复治疗！！！！！！
     **************************************/
    setTime = set;
    runTime = run;
    remainTime = remain;
}
