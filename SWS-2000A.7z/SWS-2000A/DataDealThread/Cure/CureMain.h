#ifndef CUREMAIN_H
#define CUREMAIN_H

#include <QTimer>

#include "DataDealThread/AbstractMainProcess.h"
#include "DataDealThread/PublicData/DataDealConfig.h"

#define BLOOD_BACK_DEFAULT_TIME     5     //回血默认时间，5min

///治疗时间单元类
class CureTimeCell
{
public:
    explicit CureTimeCell(){}   //构造函数，初始化<治疗时间>为零
    inline qint32 GetSetTime(){ return setTime; };          //获取<设置时间>
    inline qint32 GetRunTime(){ return runTime; }           //获取<运行时间>
    inline qint32 GetRemainTime(){ return remainTime; }     //获取<剩余时间>
    inline void Clear(){ firstSec = true; setTime = 0; runTime = 0; remainTime = 0; }   //清零整个治疗时间
    inline void Reset(){ firstSec = true; runTime = 0; remainTime = setTime; }          //重置走过的时间，保留设置时间
    bool SetSetTimeAndIsOver(qint32 set);       //设置<设置时间>，并判断是否达到<治疗时间>
    bool UpdateCureTimeAndIsOver();             //更新<治疗时间>，并判断是否达到<治疗时间>
    void SetCureTimeOnlyForRecovery(qint32 set, qint32 run, qint32 remain);     ///设置<治疗时间>，仅在恢复治疗数据时可调用！！！！！！

private:
    bool    firstSec = true;    //是否是第一秒，第一秒不更新时间
    qint32  setTime = 0;        //设置时间，s
    qint32  runTime = 0;        //运行时间，s
    qint32  remainTime = 0;     //剩余时间，s
};

///治疗时间
struct CureTimeData
{
    CureTimeCell    cureRun;        //治疗运行
};

class CureMain : public AbstractMainProcess
{
    Q_OBJECT
public:
    explicit CureMain(QObject *parent = nullptr);

public slots:
    void SLOTDataFromInterface(FunctionCodeType code, FunctionDataType type, QVariant var);     //来自界面层的数据

private slots:
    void slotClockTimer();          //治疗时间定时器槽函数
    void slotOneSecUpdateTimer();   //1s更新定时器槽函数
    void slotHalfSecUpdateTimer();  //500ms更新定时器槽函数

private:
    void analyseIntData(FunctionCodeType code, qint32 num);     //解析int
    void analyseDoubleData(FunctionCodeType code, double num);  //解析double
    void analyseBoolData(FunctionCodeType code, bool var);      //解析bool
    void selfCheck();   //自检
    void bloodBack();   //回血
    void updateBloodPumpAccVolume();    //更新血泵累积量
    void updateBloodBackControl();  //检测回血控制

private:
    QTimer          *mClockTimer;               //治疗时间定时器
    QTimer          *mOneSecUpdateTimer;        //1s更新定时器
    QTimer          *mHalfSecUpdateTime;        //500ms更新定时器
    CureTimeData    mTime;                      //治疗时间
    WorkModeType    mWorkMode = WMT_Default;    //工作模式
    PrimingStepType     mPrimingStep = PST_NotFill;     //预充步骤
    BloodBackStepType       mBloodBackStep = BBST_NotBack;      //回血步骤
    qint32          mBloodBackTimeCount = BLOOD_BACK_DEFAULT_TIME;      //回血计时
    double          mBloodPumpAccVolume = 0.0;  //血泵累积量
    qint32          mPrimingVolume = 0;         //预充总量
    qint32          mBloodPumpFlow = 0;         //血泵流量
    bool            mBloodPumpSwitch = false;   //血泵开关
};

#endif // CUREMAIN_H
