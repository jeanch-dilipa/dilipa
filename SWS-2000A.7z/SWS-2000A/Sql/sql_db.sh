#!/bin/bash
#特别提醒 ====> db|sql文件名中不能含有空格
#如果不能执行需要chmod +x sql_db.sh
#RUN之间必须顶格写
function menu ()
{
  cat << RUN
*******************
* sql db 互转脚本 *
*******************
1) sql -> db
2) db  -> sql
3) exit
RUN
read -p "请选择菜单：" num
case $num in
  1)
    sql2db
    clear
    echo "sql转db成功!"
    ;;
  2)
    db2sql
    clear
    echo "db转sql成功!"
    ;;
  3)
    exit 0
    ;;
  *)
    clear
esac
  menu
}

function sql2db()
{
#查找当前目录后缀为*.sql的文件名
for sqlfullname in `find . -maxdepth 1 -name "*.sql"`
do
  sqlname=${sqlfullname##*/}
  name=${sqlname%.*}
  dbname=${name}".db"
  
  if [ -f ${dbname} ]
  then
    rm -f ${dbname}
  fi
  sqlite3 "${dbname}" << RUN
.read "${sqlname}"
.exit
RUN
done  
}

function db2sql()
{
#查找当前目录后缀为*.db的文件名
for dbfullname in `find . -maxdepth 1 -name "*.db"`
do
  dbname=${dbfullname##*/}
  name=${dbname%.*}
  sqlname=${name}".sql"
  
  if [ -f ${sqlname} ]
  then
    rm -f ${sqlname}
  fi
  sqlite3 "${dbname}" << RUN
.output "${sqlname}"
.dump
.exit
RUN
done  
}
menu
