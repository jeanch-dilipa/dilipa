PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "InputInfo" (
	`code`	INTEGER,
	`regexp`	TEXT,
	`lowerLimit`	TEXT,
	`upperLimit`	TEXT,
	`codeType`	TEXT,
	`notes`	TEXT
);
INSERT INTO InputInfo VALUES(107,'[3-9][0-9]|[1-5][0-9]{2}|6[0-4][0-9]|650','30','650','int','血泵流量');
INSERT INTO InputInfo VALUES(109,'3[3-9]((\.[0-9])?|\.)|40\.0|40\.|40','33.0','40.0','double','保温器温度');
INSERT INTO InputInfo VALUES(110,'([0-9]|1[0-9]|2[1-4])(\.|(\.[0-9])?)|25|25\.|25\.0','0.0','25.0','double','肝素泵流量');
INSERT INTO InputInfo VALUES(22,'((0|00):[1-5][0-9])|((0?[1-9]|1[0-9]|2[0-3]):(0?[0-9]|[0-5][0-9]))','00:10','23:59','hh:mm','治疗时间');
INSERT INTO InputInfo VALUES(23,'[0-9]|[1-9][0-9]|[1-9][0-9][0-9]|[1-4][0-9]{3}|5000','0','5000','int','预充时间');
CREATE TABLE `BoardConfig` (
	`address`	INTEGER,
	`command`	INTEGER,
	`uartMode`	INTEGER,
	`dataType`	INTEGER,
	`length`	INTEGER,
	`notes`	TEXT
);
INSERT INTO BoardConfig VALUES(16,32,1,2,0,'通信初始化INI');
INSERT INTO BoardConfig VALUES(16,33,1,2,0,'握手ASK');
INSERT INTO BoardConfig VALUES(16,34,1,2,0,'错误响应CRC_ERR');
INSERT INTO BoardConfig VALUES(16,35,1,1,14,'版本信息VER');
INSERT INTO BoardConfig VALUES(16,48,1,1,3,'自检命令WR0');
INSERT INTO BoardConfig VALUES(16,49,1,1,8,'血泵、备用泵控制命令WR1');
INSERT INTO BoardConfig VALUES(16,50,1,1,5,'阻断夹、空气、液面调节控制命令WR2');
INSERT INTO BoardConfig VALUES(16,51,1,1,4,'肝素泵控制命令WR3');
INSERT INTO BoardConfig VALUES(16,52,1,1,4,'按键灯、报警灯控制命令WR4');
INSERT INTO BoardConfig VALUES(16,53,1,1,8,'加热控制命令WR5');
INSERT INTO BoardConfig VALUES(16,54,1,1,4,'静脉压、灌流器前压压力校正WR6');
INSERT INTO BoardConfig VALUES(16,56,1,1,0,'复位重启命令WR8');
INSERT INTO BoardConfig VALUES(16,57,1,9,1026,'升级命令WR9');
INSERT INTO BoardConfig VALUES(16,64,1,2,4,'自检信息RD0');
INSERT INTO BoardConfig VALUES(16,65,1,2,14,'血泵运行参数RD1');
INSERT INTO BoardConfig VALUES(16,66,1,2,14,'备用泵运行参数RD2');
INSERT INTO BoardConfig VALUES(16,67,1,2,6,'空气、阻断夹、按键状态RD3');
INSERT INTO BoardConfig VALUES(16,68,1,2,9,'肝素泵运行参数RD4');
INSERT INTO BoardConfig VALUES(16,69,1,2,5,'温度传感器信息RD5');
INSERT INTO BoardConfig VALUES(16,70,1,2,17,'灌流器前压、静脉压传感器信息RD6');
INSERT INTO BoardConfig VALUES(16,71,1,2,14,'软硬件版本信息RD7');
INSERT INTO BoardConfig VALUES(16,72,1,2,2,'升级状态信息RD8');
INSERT INTO BoardConfig VALUES(17,32,1,2,0,'通信初始化INI');
INSERT INTO BoardConfig VALUES(17,33,1,2,0,'握手ASK');
INSERT INTO BoardConfig VALUES(17,34,1,2,0,'错误响应CRC_ERR');
INSERT INTO BoardConfig VALUES(17,35,1,1,14,'版本信息命令VER');
INSERT INTO BoardConfig VALUES(17,48,1,1,9,'温度补偿WR0');
INSERT INTO BoardConfig VALUES(17,64,1,2,4,'温度信息RD0');
INSERT INTO BoardConfig VALUES(17,65,1,2,7,'各种监控状态RD1');
INSERT INTO BoardConfig VALUES(17,71,1,2,14,'软硬件版本信息RD7');
INSERT INTO BoardConfig VALUES(17,72,1,9,1026,'升级状态信息RD8');
COMMIT;
