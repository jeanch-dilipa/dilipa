#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTimer>

#include "InterfaceThread/PublicData/InterfaceConfig.h"         //公共配置定义
#include "Commom/PublicDefine/PublicEnumDefine.h"               //公共枚举定义
#include "InterfaceThread/Tools/RightButton/BloodPumpControlWidget.h"       //血泵控件窗口
#include "InterfaceThread/Tools/RightButton/HeatControlWidget.h"            //保温器温度控件窗口
#include "InterfaceThread/Tools/RightButton/HeparinPumpControlWidget.h"     //肝素泵控件窗口

enum RightButtonNumType
{
    RBNT_BloodPump = 0,     //血泵
    RBNT_Heat = 1,          //保温器
    RBNT_HeparinPump = 2    //肝素泵
};

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

public slots:
    void SLOTShowMainWidget(bool show);     //显示主界面槽函数
    void SLOTAnalyseData(FunctionCodeType code, FunctionDataType type, QVariant var);   //解析数据

private slots:
    void on_pushButton_Pre_clicked();       //Pre按钮槽函数
    void on_pushButton_Next_clicked();      //Next按钮槽函数
    void on_pushButton_BloodPump_clicked(bool checked);     //血泵控件点击槽函数
    void on_pushButton_Heat_clicked(bool checked);          //保温器温度控件点击槽函数
    void on_pushButton_HeparinPump_pressed();               //肝素泵控件按下槽函数
    void on_pushButton_HeparinPump_released();              //肝素泵控件释放槽函数
    void on_pushButton_HeparinPump_clicked(bool checked);   //肝素泵控件点击槽函数
    void slotOneSecTimer();     //1秒更新定时器槽函数
    void slotHeparinButtonLongPress();                      //肝素泵控件长按槽函数

private:
    void analyseBoolData(FunctionCodeType code, bool var);  //解析bool
    void analyseIntData(FunctionCodeType code, qint32 num); //解析int
    void analyseDoubleData(FunctionCodeType code, double num);      //解析double
    void setRightButtonChecked(RightButtonNumType button, bool checked);    //设置右侧按钮check状态

private:
    Ui::Widget *ui;
    BloodPumpControlWidget  *mBloodPumpControlWidget;   //血泵控件窗口
    HeatControlWidget       *mHeatControlWidget;        //保温器温度控件窗口
    HeparinPumpControlWidget    *mHeparinPumpControlWidget;     //肝素泵控件窗口
    QTimer      *mOneSecTimer;      //1s更新定时器
    QTimer      *mHeparinButtonLongPressTimer;          //肝素泵控件长按定时器
    bool        mHeparinQuickMode = false;              //肝素泵快速推注
};
#endif // WIDGET_H
