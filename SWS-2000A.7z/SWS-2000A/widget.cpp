#include "widget.h"
#include "ui_widget.h"

#include <QPoint>
#include <QDateTime>

/***************************************************************************************************
 函数名称：  Widget()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    //this->setWindowFlags(Qt::FramelessWindowHint);      //无边框
    gIPD.mMainWidget = this;

    //设置控件功能码
    ui->pushButton_Pre->mCode = FCT_Pre;
    ui->pushButton_Run->mCode = FCT_Run;
    ui->pushButton_Next->mCode = FCT_Next;

    //初始化界面控件
    ui->pushButton_Menu->setText(tr("☰"));

    //初始化右侧按钮
    ui->pushButton_BloodPump->SetNameAndUnit(tr("血泵流量"), "ml/min");
    ui->pushButton_BloodPump->SetValue("100");
    gIPD.mBloodPumpFlow = 100;
    ui->pushButton_Heat->SetNameAndUnit(tr("保温器温度"), "℃");
    ui->pushButton_Heat->SetValue("37.0");
    gIPD.mHeatTemp = 37.0;
    ui->pushButton_HeparinPump->SetNameAndUnit(tr("肝素流量"), "ml/h");
    ui->pushButton_HeparinPump->SetValue("1.0");
    gIPD.mHeparinPumpFlow = 1.0;

    //右侧按钮组件相关窗口
    mBloodPumpControlWidget = new BloodPumpControlWidget(this);
    mHeatControlWidget = new HeatControlWidget(this);
    mHeparinPumpControlWidget = new HeparinPumpControlWidget(this);
    mBloodPumpControlWidget->hide();
    mHeatControlWidget->hide();
    mHeparinPumpControlWidget->hide();

    //1s更新定时器
    mOneSecTimer = new QTimer(this);
    connect(mOneSecTimer, &QTimer::timeout, this, &Widget::slotOneSecTimer, Qt::UniqueConnection);
    mOneSecTimer->start(1000);

    //肝素泵控件长按定时器
    mHeparinButtonLongPressTimer = new QTimer(this);
    connect(mHeparinButtonLongPressTimer, &QTimer::timeout, this, &Widget::slotHeparinButtonLongPress, Qt::UniqueConnection);
    mHeparinButtonLongPressTimer->setInterval(1000);     //1s算长按

    //链接信号槽
    connect(&gIPD, &InterfacePublicData::SIGNALSendToDataDeal, this, &Widget::SLOTAnalyseData, Qt::UniqueConnection);
    connect(&gIPD, &InterfacePublicData::SIGNALDataFromDataDeal, this, &Widget::SLOTAnalyseData, Qt::UniqueConnection);

    //初始化小键盘输入信息
    emit gIPD.SIGNALSendQuery(SOT_SELECT_INPUT_INFO, QVariant());
    //读取模块板配置
    emit gIPD.SIGNALSendQuery(SOT_SELECT_BOARD_CONFIG, QVariant());
}

/***************************************************************************************************
 函数名称：  ~Widget()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
Widget::~Widget()
{
    delete ui;
}

/***************************************************************************************************
 函数名称：  SLOTShowMainWidget()
 功能描述：  跳转到主界面槽函数
 输入参数：  show---是否显示
 返回的值：  无
 ***************************************************************************************************/
void Widget::SLOTShowMainWidget(bool show)
{
    if(show)
    {   //显示主界面代表进入治疗
        this->setHidden(!show);
        gIPD.SetDataAndSendToDataDeal(FCT_WorkMode, FDT_Numeric, QVariant(WMT_SelfCheck));      //工作模式：自检
    }
}

/***************************************************************************************************
 函数名称：  SLOTAnalyseData()
 功能描述：  来自界面层的数据
 输入参数：  code：功能码 | type：数据类型 | var：数据
 返回的值：  无
 ***************************************************************************************************/
void Widget::SLOTAnalyseData(FunctionCodeType code, FunctionDataType type, QVariant var)
{
    switch(type)
    {
    case FDT_Boolean:
        analyseBoolData(code, var.toBool());
        break;
    case FDT_Numeric:
        analyseIntData(code, var.toInt());
        break;
    case FDT_Decimal:
        analyseDoubleData(code, var.toDouble());
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  on_pushButton_Pre_clicked()
 功能描述：  Pre按钮槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void Widget::on_pushButton_Pre_clicked()
{
    switch(gIPD.mWorkMode)
    {
    case WMT_Priming:
        if(gIPD.mPrimingStep == PST_Filling)
        {   //正在预充
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_Pause);     //预充步骤：预充暂停
        }
        else if(gIPD.mPrimingStep == PST_Refilling)
        {
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_Pause);     //预充步骤：预充暂停
        }
        else if(gIPD.mPrimingStep == PST_Pause)
        {   //预充暂停
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_Filling);   //预充步骤：正在预充
        }
        else if(gIPD.mPrimingStep == PST_Filled)
        {   //预充完成
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_Refilling);    //预充步骤：重新预充
        }
        break;
    case WMT_PatientConnect:    //引血
        if(gIPD.mPatientConnectStep)
        {   //引血完成
            gIPD.SetDataAndSendToDataDeal(FCT_PatientConnectStep, FDT_Boolean, false);  //引血步骤
        }
        break;
    case WMT_CureEnd:   //治疗结束
        gIPD.SetDataAndSendToDataDeal(FCT_WorkMode, FDT_Numeric, WMT_CureRun);  //治疗运行
        break;
    case WMT_BloodBack:     //回血
        if(gIPD.mBloodBackStep == BBST_Backed)
        {   //回血完成
            gIPD.SetDataAndSendToDataDeal(FCT_BloodBackStep, FDT_Numeric, BBST_Backing);    //回血步骤：回血中
        }
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  on_pushButton_Next_clicked()
 功能描述：  Next按钮槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void Widget::on_pushButton_Next_clicked()
{
    switch(gIPD.mWorkMode)
    {
    case WMT_SelfCheck:     //自检
        if(gIPD.mSelfCheckStep == SCST_Checked)
        {   //自检完成
            gIPD.SetDataAndSendToDataDeal(FCT_WorkMode, FDT_Numeric, WMT_Priming);          //工作模式：预充
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_Filling);  //预充步骤：正在预充
        }
        break;
    case WMT_Priming:       //预充
        if(gIPD.mPrimingStep == PST_NotFill)
        {   //未预充
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_Filling);  //预充步骤：正在预充
        }
        else if(gIPD.mPrimingStep == PST_Filling)
        {   //正在预充
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_Filled);    //预充步骤：预充完成
        }
        else if(gIPD.mPrimingStep == PST_Pause)
        {
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_Filled);    //预充步骤：预充完成
        }
        else if(gIPD.mPrimingStep == PST_Filled)
        {   //预充完成
            gIPD.SetDataAndSendToDataDeal(FCT_WorkMode, FDT_Numeric, WMT_PatientConnect);   //工作模式：引血
            gIPD.SetDataAndSendToDataDeal(FCT_CureRunTime, FDT_Numeric, 4*60*60);       //治疗时间：默认4h
        }
        else if(gIPD.mPrimingStep == PST_Refilling)
        {   //重新预充
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_Filled);   //预充步骤：完成
        }
        break;
    case WMT_PatientConnect:    //引血
        if(!gIPD.mPatientConnectStep)
        {   //未完成引血
            gIPD.SetDataAndSendToDataDeal(FCT_PatientConnectStep, FDT_Boolean, true);   //引血步骤：完成
        }
        else
        {   //完成引血
            gIPD.SetDataAndSendToDataDeal(FCT_WorkMode, FDT_Numeric, WMT_CureRun);      //工作模式：治疗运行
        }
        break;
    case WMT_CureRun:   //治疗运行
        gIPD.SetDataAndSendToDataDeal(FCT_WorkMode, FDT_Numeric, WMT_CureEnd);      //工作模式：治疗结束
        break;
    case WMT_CureEnd:   //治疗结束
        gIPD.SetDataAndSendToDataDeal(FCT_WorkMode, FDT_Numeric, WMT_BloodBack);        //工作模式：回血
        gIPD.SetDataAndSendToDataDeal(FCT_BloodBackStep, FDT_Numeric, BBST_Backing);    //回血步骤：回血中
        break;
    case WMT_BloodBack:     //回血
        if(gIPD.mBloodBackStep == BBST_Backed)
        {   //未回血
            gIPD.SetDataAndSendToDataDeal(FCT_WorkMode, FDT_Numeric, WMT_Priming);          //工作模式：预充
            gIPD.SetDataAndSendToDataDeal(FCT_PrimingStep, FDT_Numeric, PST_NotFill);       //预充步骤：未预充
            ui->pushButton_Pre->setEnabled(false);
            ui->pushButton_Pre->setText("");
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("预充"));
            ui->label_Info->setText(tr("请连接管路，准备预充"));
            ui->widget_TimePanel->setVisible(true);
            ui->widget_SelfCheck->setVisible(false);
            ui->widget_BloodBack->setVisible(false);
            gIPD.SetDataAndSendToDataDeal(FCT_BloodPumpAccVolume, FDT_Decimal, 0);          //清空血泵累积量
        }
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  on_pushButton_BloodPump_clicked()
 功能描述：  血泵控件点击槽函数
 输入参数：  checked---是否选中
 返回的值：  无
 ***************************************************************************************************/
void Widget::on_pushButton_BloodPump_clicked(bool checked)
{
    setRightButtonChecked(RBNT_BloodPump, checked);
}

/***************************************************************************************************
 函数名称：  on_pushButton_Heat_clicked()
 功能描述：  保温器温度控件点击槽函数
 输入参数：  checked---是否选中
 返回的值：  无
 ***************************************************************************************************/
void Widget::on_pushButton_Heat_clicked(bool checked)
{
    setRightButtonChecked(RBNT_Heat, checked);
}

/***************************************************************************************************
 函数名称：  on_pushButton_HeparinPump_pressed()
 功能描述：  肝素泵控件按下槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void Widget::on_pushButton_HeparinPump_pressed()
{
    mHeparinButtonLongPressTimer->stop();
    mHeparinButtonLongPressTimer->start();
    mHeparinQuickMode = false;  //必须在这里重置，不在release中设置的原因是，release在click之前执行，会导致这个变量没用
}

/***************************************************************************************************
 函数名称：  on_pushButton_HeparinPump_released()
 功能描述：  肝素泵控件释放槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void Widget::on_pushButton_HeparinPump_released()
{
    if(mHeparinButtonLongPressTimer->isActive())
    {   //未长按，即未快速推注
        mHeparinButtonLongPressTimer->stop();
    }
    else
    {   //长按了，即在进行快速推注
        ui->pushButton_HeparinPump->setChecked(false);      //将肝素泵控件弹起
        ui->pushButton_HeparinPump->SetNameAndUnit(tr("肝素流量"), "ml/h");
        ui->pushButton_HeparinPump->SetValue(QString::number(gIPD.mHeparinPumpFlow, 'f', 1));
        if(mHeparinPumpControlWidget->isVisible())
        {   //隐藏肝素泵控件窗口
            setRightButtonChecked(RBNT_HeparinPump, false);
        }
    }
}

/***************************************************************************************************
 函数名称：  on_pushButton_HeparinPump_clicked()
 功能描述：  肝素泵控件点击槽函数
 输入参数：  checked---是否选中
 返回的值：  无
 ***************************************************************************************************/
void Widget::on_pushButton_HeparinPump_clicked(bool checked)
{
    if(!mHeparinQuickMode)
    {   //未推注，则触发
        setRightButtonChecked(RBNT_HeparinPump, checked);
    }
}

/***************************************************************************************************
 函数名称：  slotOneSecTimer()
 功能描述：  1s更新定时器槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void Widget::slotOneSecTimer()
{
    //更新日期时间
    QLocale locale = QLocale::Chinese;
    QDateTime datetime = QDateTime::currentDateTime();
    ui->label_Date->setText(datetime.toString("yyyy-MM-dd"));
    ui->label_Time->setText(locale.toString(datetime, "hh:mm ddd"));
}

/***************************************************************************************************
 函数名称：  slotHeparinButtonLongPress()
 功能描述：  肝素泵控件长按槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void Widget::slotHeparinButtonLongPress()
{
    mHeparinButtonLongPressTimer->stop();
    ui->pushButton_HeparinPump->SetNameAndUnit(tr("快进中..."), "ml/h");
    ui->pushButton_HeparinPump->SetValue("18.0");
    mHeparinQuickMode = true;   //标识快速推注
}

/***************************************************************************************************
 函数名称：  analyseBoolData()
 功能描述：  解析bool
 输入参数：  code：功能码 | var：数据
 返回的值：  无
 ***************************************************************************************************/
void Widget::analyseBoolData(FunctionCodeType code, bool var)
{
    switch(code)
    {
    case FCT_PatientConnectStep:
        if(gIPD.mPatientConnectStep)
        {   //引血完成
            ui->pushButton_Pre->setEnabled(true);
            ui->pushButton_Pre->setText(tr("继续引血"));
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("开始治疗"));
            ui->label_Info->setText(tr("引血完成，请开始治疗"));
        }
        else
        {   //引血未完成
            ui->pushButton_Pre->setEnabled(false);
            ui->pushButton_Pre->setText("");
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("引血完成"));
            ui->label_Info->setText(tr("引血中..."));
        }
        break;
    case FCT_BloodPumpSwitch:   //血泵开关
        ui->pushButton_BloodPump->SetSwitch(gIPD.mBloodPumpSwitch);
        break;
    case FCT_HeatSwitch:        //保温器开关
        ui->pushButton_Heat->SetSwitch(gIPD.mHeatSwitch);
        break;
    case FCT_HeparinSwitch:     //肝素泵开关
        ui->pushButton_HeparinPump->SetSwitch(gIPD.mHeparinSwitch);
        break;
    default:
        break;
    }
    Q_UNUSED(var)
}

/***************************************************************************************************
 函数名称：  analyseIntData()
 功能描述：  解析int
 输入参数：  code：功能码 | num：数据
 返回的值：  无
 ***************************************************************************************************/
void Widget::analyseIntData(FunctionCodeType code, qint32 num)
{
    switch(code)
    {
    case FCT_WorkMode:  //工作模式
        switch(num)
        {
        case WMT_SelfCheck:     //自检
            ui->pushButton_Pre->setEnabled(true);
            ui->pushButton_Pre->setText(tr("重新自检"));
            ui->pushButton_Next->setEnabled(false);
            ui->pushButton_Next->setText("");
            ui->label_Info->setText(tr("自检中..."));
            ui->widget_TimePanel->setVisible(false);
            ui->widget_SelfCheck->setVisible(true);
            ui->widget_BloodBack->setVisible(false);
            break;
        case WMT_PatientConnect:    //引血
            ui->pushButton_Pre->setEnabled(false);
            ui->pushButton_Pre->setText("");
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("引血完成"));
            ui->label_Info->setText(tr("引血中..."));
            break;
        case WMT_CureRun:   //治疗运行
            ui->pushButton_Pre->setEnabled(false);
            ui->pushButton_Pre->setText("");
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("结束治疗"));
            ui->label_Info->setText(tr("治疗中..."));
            break;
        case WMT_CureEnd:   //治疗结束
            ui->pushButton_Pre->setEnabled(true);
            ui->pushButton_Pre->setText(tr("继续治疗"));
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("回血"));
            ui->label_Info->setText(tr("治疗结束，请回血"));
            break;
        case WMT_BloodBack:     //回血
            ui->pushButton_Pre->setEnabled(false);
            ui->pushButton_Pre->setText("");
            ui->pushButton_Next->setEnabled(false);
            ui->pushButton_Next->setText("");
            ui->label_Info->setText(tr("回血中..."));
            ui->widget_TimePanel->setVisible(false);
            ui->widget_SelfCheck->setVisible(false);
            ui->widget_BloodBack->setVisible(true);
            break;
        default:
            break;
        }
        break;
    case FCT_SelfCheckStep: //自检步骤
        if(gIPD.mSelfCheckStep == SCST_Checked)
        {   //自检完成
            ui->pushButton_Pre->setEnabled(false);
            ui->pushButton_Pre->setText("");
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("预充"));
            ui->label_Info->setText(tr("自检完成，请预充"));
            ui->widget_TimePanel->setVisible(true);
            ui->widget_SelfCheck->setVisible(false);
            ui->widget_BloodBack->setVisible(false);
        }
        break;
    case FCT_PrimingStep:   //预充步骤
        if(gIPD.mPrimingStep == PST_Filling)
        {   //正在预充
            ui->pushButton_Pre->setEnabled(true);
            ui->pushButton_Pre->setText(tr("暂停"));
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("结束预充"));
            ui->label_Info->setText(tr("预充中..."));
        }
        else if(gIPD.mPrimingStep == PST_Pause)
        {   //预充暂停
            ui->pushButton_Pre->setEnabled(true);
            ui->pushButton_Pre->setText(tr("继续"));
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("结束预充"));
            ui->label_Info->setText(tr("预充已暂停"));
        }
        else if(gIPD.mPrimingStep == PST_Filled)
        {   //预充完成
            ui->pushButton_Pre->setEnabled(true);
            ui->pushButton_Pre->setText(tr("继续预充"));
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("引血"));
            ui->label_Info->setText(tr("预充完成，请引血"));
        }
        else if(gIPD.mPrimingStep == PST_Refilling)
        {   //重新预充
            ui->pushButton_Pre->setEnabled(true);
            ui->pushButton_Pre->setText(tr("暂停"));
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("结束预充"));
            ui->label_Info->setText(tr("预充中..."));
        }
        break;
    case FCT_BloodBackStep:     //回血步骤
        if(gIPD.mBloodBackStep == BBST_Backing)
        {
            ui->pushButton_Pre->setEnabled(false);
            ui->pushButton_Pre->setText("");
            ui->pushButton_Next->setEnabled(false);
            ui->pushButton_Next->setText("");
            ui->label_Info->setText(tr("回血中..."));
        }
        else if(gIPD.mBloodBackStep == BBST_Backed)
        {   //回血完成
            ui->pushButton_Pre->setEnabled(true);
            ui->pushButton_Pre->setText(tr("继续回血"));
            ui->pushButton_Next->setEnabled(true);
            ui->pushButton_Next->setText(tr("准备预充"));
            ui->label_Info->setText(tr("回血完成，请预充或关机"));
        }
        break;
    case FCT_BloodPumpFlow:     //血泵流量
        ui->pushButton_BloodPump->SetValue(QString::number(gIPD.mBloodPumpFlow));
        break;
    case FCT_InputKeyboard: //小键盘
        if(num == FCT_BloodPumpFlow)
        {
            on_pushButton_BloodPump_clicked(false);     //关闭血泵流量按钮
        }
        else if(num == FCT_HeatTemp)
        {
            on_pushButton_Heat_clicked(false);  //关闭保温器温度按钮
        }
        else if(num == FCT_HeparinPumpFlow)
        {
            on_pushButton_HeparinPump_clicked(false);   //关闭肝素泵流量按钮
        }
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  analyseDoubleData()
 功能描述：  解析double
 输入参数：  code：功能码 | num：数据
 返回的值：  无
 ***************************************************************************************************/
void Widget::analyseDoubleData(FunctionCodeType code, double num)
{
    switch(code)
    {
    case FCT_HeatTemp:  //保温器温度
        ui->pushButton_Heat->SetValue(QString::number(num, 'f', 1));
        break;
    case FCT_HeparinPumpFlow:   //肝素泵流量
        ui->pushButton_HeparinPump->SetValue(QString::number(num, 'f', 1));
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  setRightButtonChecked()
 功能描述：  设置右侧按钮check状态
 输入参数：  button---按钮 | checked---是否选中
 返回的值：  无
 ***************************************************************************************************/
void Widget::setRightButtonChecked(RightButtonNumType button, bool checked)
{
    if(checked)
    {
        //血泵
        ui->pushButton_BloodPump->setChecked(false);
        mBloodPumpControlWidget->setVisible(false);
        //保温器
        ui->pushButton_Heat->setChecked(false);
        mHeatControlWidget->setVisible(false);
        //肝素泵
        ui->pushButton_HeparinPump->setChecked(false);
        mHeparinPumpControlWidget->setVisible(false);
    }

    QPoint pos0_0(this->mapToGlobal(QPoint(0, 0)));
    switch(button)
    {
    case RBNT_BloodPump:    //血泵
        ui->pushButton_BloodPump->setChecked(checked);
        mBloodPumpControlWidget->setVisible(checked);
        mBloodPumpControlWidget->move(ui->pushButton_BloodPump->mapToGlobal(QPoint(0, 0)).x()-pos0_0.x()-mBloodPumpControlWidget->width(),
                                      ui->pushButton_BloodPump->mapToGlobal(QPoint(0, 0)).y()-pos0_0.y());
        break;
    case RBNT_Heat:         //保温器
        ui->pushButton_Heat->setChecked(checked);
        mHeatControlWidget->setVisible(checked);
        mHeatControlWidget->move(ui->pushButton_Heat->mapToGlobal(QPoint(0, 0)).x()-pos0_0.x()-mHeatControlWidget->width(),
                                 ui->pushButton_Heat->mapToGlobal(QPoint(0, 0)).y()-pos0_0.y());
        break;
    case RBNT_HeparinPump:  //肝素泵
        ui->pushButton_HeparinPump->setChecked(checked);
        mHeparinPumpControlWidget->setVisible(checked);
        mHeparinPumpControlWidget->move(ui->pushButton_HeparinPump->mapToGlobal(QPoint(0, 0)).x()-pos0_0.x()-mHeparinPumpControlWidget->width(),
                                        ui->pushButton_HeparinPump->mapToGlobal(QPoint(0, 0)).y()-pos0_0.y()-mHeparinPumpControlWidget->height()+ui->pushButton_HeparinPump->height());
        break;
    default:
        break;
    }
}
