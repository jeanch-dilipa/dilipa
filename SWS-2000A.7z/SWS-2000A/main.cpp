#include "widget.h"

#include <QApplication>
#include <QThread>
#include <QStyleFactory>
#include <iostream>

#include "InterfaceThread/StartUp/StartUp.h"
#include "DataDealThread/DataDealThread.h"
#include "InterfaceThread/PublicData/InterfacePublicData.h"
#include "DataDealThread/PublicData/DataDealPublicData.h"
#include "SqlThread/SqlThread.h"
#include "UartThread/UartThread.h"

#define MAIN_SOFTWARE_VERSION   "2.01.A"        //主控软件版本

InterfacePublicData gIPD;   //界面公共数据
DataDealPublicData gDPD;    //数据层公共数据

int main(int argc, char *argv[])
{
    //获取版本信息
    if(argc == 2 && strcmp(argv[1], "--version") == 0)
    {
        ::std::cout << MAIN_SOFTWARE_VERSION;
        return 0;
    }

    QApplication a(argc, argv);

    a.setStyle(QStyleFactory::create("fusion"));

    //向Qt注册自定义的数据格式，用于信号和槽
    qRegisterMetaType<FunctionCodeType>("FunctionCodeType");
    qRegisterMetaType<FunctionDataType>("FunctionDataType");
    qRegisterMetaType<SqlOperateType>("SqlOperateType");
    qRegisterMetaType<DataAttributeType>("DataAttributeType");

    //开机启动界面
    StartUp *start = new StartUp(nullptr);
    start->show();

    //数据处理线程
    DataDealThread *dataDeal = new DataDealThread(nullptr);
    QThread *threadDataDeal = new QThread(nullptr);
    dataDeal->moveToThread(threadDataDeal);
    //链接界面层<=>数据处理层信号槽
    QObject::connect(&gIPD, &InterfacePublicData::SIGNALSendToDataDeal, dataDeal, &DataDealThread::SLOTDataFromInterface, Qt::UniqueConnection);
    QObject::connect(dataDeal, &DataDealThread::SIGNALSendToInterface, &gIPD, &InterfacePublicData::SLOTDataFromDataDeal, Qt::UniqueConnection);

    //数据库线程
    SqlThread *sql = new SqlThread(nullptr);
    QThread *threadSql = new QThread(nullptr);
    sql->moveToThread(threadSql);
    //链接界面层<=>数据库层信号槽
    QObject::connect(&gIPD, &InterfacePublicData::SIGNALSendQuery, sql, &SqlThread::SLOTReceiveQuery, Qt::UniqueConnection);
    QObject::connect(sql, &SqlThread::SIGNALSendQueryData, &gIPD, &InterfacePublicData::SIGNALReceiveQueryData, Qt::UniqueConnection);
    //链接数据处理层<=>数据库层信号槽
    QObject::connect(dataDeal, &DataDealThread::SIGNALSendQuery, sql, &SqlThread::SLOTReceiveQuery, Qt::UniqueConnection);
    QObject::connect(sql, &SqlThread::SIGNALSendQueryData, &gDPD, &DataDealPublicData::SLOTReceiveQueryData, Qt::UniqueConnection);

    //UART线程
    UartThread *uart = new UartThread(nullptr);
    QThread *threadUart = new QThread(nullptr);
    uart->moveToThread(threadUart);
    //链接UART层于<=>数据处理层的信号槽
    QObject::connect(&gDPD.mb, &ModuleBoard::SIGNALSendData, uart, &UartThread::SLOTDataWrite, Qt::UniqueConnection);
    QObject::connect(uart, &UartThread::SIGNALDataReadyRead, dataDeal, &DataDealThread::SLOTDataFromUart, Qt::UniqueConnection);

    //开启线程
    threadDataDeal->start();    //数据处理线程
    threadSql->start();         //数据库线程
    threadUart->start();        //UART线程

    //主界面
    Widget w;
    QObject::connect(start, &StartUp::SIGNALShowMainWidget, &w, &Widget::SLOTShowMainWidget, Qt::UniqueConnection);

    return a.exec();
}
