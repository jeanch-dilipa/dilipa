#include "StartUp.h"
#include "ui_StartUp.h"

#include <QDebug>

/***************************************************************************************************
 函数名称：  StartUp()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
StartUp::StartUp(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StartUp)
{
    ui->setupUi(this);

    this->setWindowFlags(Qt::FramelessWindowHint);      //无边框

    QString version("Software Version 2.01.A");
    ui->label_SoftwareVersion->setText(version);        //主控软件版本
    connect(m_goToMainWidgetTimer, &QTimer::timeout, this, &StartUp::slotGoToMainWidget, Qt::UniqueConnection);

    QTimer::singleShot(0, this, [&](){
        startAnimation();       //加载动画
    });
}

/***************************************************************************************************
 函数名称：  ~StartUp()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
StartUp::~StartUp()
{
    delete ui;
}

/***************************************************************************************************
 函数名称：  slotGoToMainWidget()
 功能描述：  跳转到主界面槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void StartUp::slotGoToMainWidget()
{
    if(m_goToMainWidgetTimer)
    {   //关闭跳转到主界面定时器
        m_goToMainWidgetTimer->stop();
    }

    emit SIGNALShowMainWidget(true);    //显示主界面
    this->hide();
    delete this;
}

/***************************************************************************************************
 函数名称：  startAnimation()
 功能描述：  加载动画
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void StartUp::startAnimation()
{
    //Logo动画，持续2.7s
    m_animation = new QPropertyAnimation(ui->label_Logo, "pos", this);
    m_animation->setDuration(2700);
    m_animation->setEasingCurve(QEasingCurve::Linear);
    m_animation->setStartValue(QPoint(240, 300));
    m_animation->setEndValue(QPoint(240, 100));
    m_animation->start();

    //启动界面持续6s
    m_goToMainWidgetTimer->start(6000);
}
