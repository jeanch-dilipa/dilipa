#ifndef STARTUP_H
#define STARTUP_H

#include <QPointer>
#include <QPropertyAnimation>
#include <QTimer>
#include <QWidget>
#include <widget.h>

namespace Ui {
class StartUp;
}

class StartUp : public QWidget
{
    Q_OBJECT

public:
    explicit StartUp(QWidget *parent = nullptr);
    ~StartUp();

signals:
    void SIGNALShowMainWidget(bool show);   //显示主界面信号

private slots:
    void slotGoToMainWidget();      //跳转到主界面槽函数

private:
    void startAnimation();      //加载动画

private:
    Ui::StartUp *ui;

private:
    QPointer<QPropertyAnimation>    m_animation;                    //开机动画
    QPointer<QTimer>    m_goToMainWidgetTimer = new QTimer(this);   //跳转到主界面定时器
};

#endif // STARTUP_H
