#ifndef INTERFACEPUBLICDATA_H
#define INTERFACEPUBLICDATA_H

#include <QObject>
#include <QVariant>

#include "Commom/PublicDefine/PublicEnumDefine.h"
#include "SqlThread/SqlDataDefine.h"

Q_DECLARE_METATYPE(FunctionCodeType);
Q_DECLARE_METATYPE(InputInfoData);

struct DisplayTimeData
{   //此结构总时间 < 24h
    enum DisplayTimeFormat
    {
        DTF_HHMM_MMSS,  //自动在hh:mm和mm:ss切换
        DTF_HHMMSS,     //hh:mm:ss
        DTF_HM_MS,      //自动在h:m和m:s切换
        DTF_HMS,        //h:m:s
        DTF_Min,        //最小单位min，eg. 2 hour 35 min | 7 min | < 1 min
        DTF_Sec         //最小单位sec，eg. 21 hour 2 min 35 sec | 25 sec
    };
    QString toString(DisplayTimeFormat format);
    qint32  hour = 0;
    qint32  min = 0;
    qint32  sec = 0;
    qint32  totalHour = 0;
    qint32  totalMin = 0;
    qint32  totalSec = 0;
};

class InterfacePublicData : public QObject
{
    Q_OBJECT
public:
    explicit InterfacePublicData(QObject *parent = nullptr);

signals:
    void SIGNALSendToDataDeal(FunctionCodeType code, FunctionDataType type, QVariant var);      ///发送界面层的数据，仅在此类里面发出信号
    void SIGNALDataFromDataDeal(FunctionCodeType code, FunctionDataType type, QVariant var);    ///来自数据层的数据，仅在此类里面发出信号
    void SIGNALSendQuery(SqlOperateType operate, QVariant var);                                 //执行sql
    void SIGNALReceiveQueryData(SqlOperateType operate, QVariant var);                          //接收sql结果信号

public slots:
    void SLOTDataFromDataDeal(FunctionCodeType code, FunctionDataType type, QVariant var);      //来自数据层的数据

private slots:
    void slotReceiveQueryData(SqlOperateType operate, QVariant var);        //接收sql结果槽函数

public:
    void SetDataAndSendToDataDeal(FunctionCodeType code, FunctionDataType type, QVariant var);  //设置并发送数据到数据层

private:
    void analyseData(FunctionCodeType code, FunctionDataType type, QVariant var);               //解析数据
    void analyseBoolData(FunctionCodeType code, bool var);                                      //解析bool
    void analyseIntData(FunctionCodeType code, qint32 num);                                     //解析int
    void analyseDoubleData(FunctionCodeType code, double num);                                  //解析double

public:
    QMap<FunctionCodeType, InputInfoData>   mInputInfoMap;  //小键盘输入信息
    WorkModeType        mWorkMode = WMT_Default;            //工作模式
    SelfCheckStepType   mSelfCheckStep = SCST_Uncheck;      //自检步骤
    PrimingStepType mPrimingStep = PST_NotFill;    //预充步骤
    bool                mPatientConnectStep = false;        //引血步骤
    BloodBackStepType   mBloodBackStep = BBST_NotBack;      //回血步骤
    DisplayTimeData     mDisplayTime;                       //显示时间
    qint32              mPrimingVolume = 0;                 //预充总量
    double              mBloodPumpAccVolume = 0;            //血泵累积量
    bool                mBloodPumpSwitch = false;           //血泵开关
    bool                mHeatSwitch = false;                //保温器开关
    bool                mHeparinSwitch = false;             //肝素泵开关
    qint32              mCureRunTime = 0;                   //治疗时间
    QWidget             *mMainWidget;                       //主界面指针
    qint32              mBloodPumpFlow = 0;                 //血泵流量
    double              mHeatTemp = 0.0;                    //保温器温度
    double              mHeparinPumpFlow = 0.0;             //肝素泵流量
};

#endif // INTERFACEPUBLICDATA_H
