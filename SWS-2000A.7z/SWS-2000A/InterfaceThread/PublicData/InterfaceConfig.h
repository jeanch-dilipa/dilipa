#ifndef INTERFACECONFIG_H
#define INTERFACECONFIG_H

#include "InterfacePublicData.h"    //界面公共类

extern InterfacePublicData gIPD;    //界面公共类

#endif // INTERFACECONFIG_H
