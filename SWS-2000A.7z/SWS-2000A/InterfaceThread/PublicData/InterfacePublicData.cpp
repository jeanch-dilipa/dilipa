#include "InterfacePublicData.h"

#include <QDebug>

/***************************************************************************************************
 函数名称：  InterfacePublicData()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
InterfacePublicData::InterfacePublicData(QObject *parent) : QObject(parent)
{
    //关联信号槽
    connect(this, &InterfacePublicData::SIGNALReceiveQueryData, this, &InterfacePublicData::slotReceiveQueryData, Qt::UniqueConnection);
}

/***************************************************************************************************
 函数名称：  SLOTDataFromDataDeal()
 功能描述：  来自数据层的数据
 输入参数：  无
 返回的值：  code：功能码 | type：数据类型 | var：数据
 ***************************************************************************************************/
void InterfacePublicData::SLOTDataFromDataDeal(FunctionCodeType code, FunctionDataType type, QVariant var)
{
    analyseData(code, type, var);
    emit SIGNALDataFromDataDeal(code, type, var);
}

/***************************************************************************************************
 函数名称：  slotReceiveQueryData()
 功能描述：  接收sql结果槽函数
 输入参数：  无
 返回的值：  operate---数据库操作，var---数据
 ***************************************************************************************************/
void InterfacePublicData::slotReceiveQueryData(SqlOperateType operate, QVariant var)
{
    switch(operate)
    {
    case SOT_SELECT_INPUT_INFO:     //查询输入信息
    {
        mInputInfoMap = var.value<QMap<FunctionCodeType, InputInfoData> >();
    }
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  SetDataAndSendToDataDeal()
 功能描述：  设置并发送数据到数据层
 输入参数：  无
 返回的值：  code：功能码 | type：数据类型 | var：数据
 ***************************************************************************************************/
void InterfacePublicData::SetDataAndSendToDataDeal(FunctionCodeType code, FunctionDataType type, QVariant var)
{
    analyseData(code, type, var);
    emit SIGNALSendToDataDeal(code, type, var);
}

/***************************************************************************************************
 函数名称：  analyseData()
 功能描述：  解析数据
 输入参数：  无
 返回的值：  code：功能码 | type：数据类型 | var：数据
 ***************************************************************************************************/
void InterfacePublicData::analyseData(FunctionCodeType code, FunctionDataType type, QVariant var)
{
    switch(type)
    {
    case FDT_Boolean:
        analyseBoolData(code, var.toBool());
        break;
    case FDT_Numeric:
        analyseIntData(code, var.toInt());
        break;
    case FDT_Decimal:
        analyseDoubleData(code, var.toDouble());
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  analyseBoolData()
 功能描述：  解析bool
 输入参数：  无
 返回的值：  code：功能码 | var：数据
 ***************************************************************************************************/
void InterfacePublicData::analyseBoolData(FunctionCodeType code, bool var)
{
    switch(code)
    {
    case FCT_PatientConnectStep:    //引血步骤
        mPatientConnectStep = var;
        break;
    case FCT_BloodPumpSwitch:   //血泵开关
        mBloodPumpSwitch = var;
        break;
    case FCT_HeatSwitch:    //保温器开关
        mHeatSwitch = var;
        break;
    case FCT_HeparinSwitch:     //肝素泵开关
        mHeparinSwitch = var;
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  analyseIntData()
 功能描述：  解析int
 输入参数：  无
 返回的值：  code：功能码 | num：数据
 ***************************************************************************************************/
void InterfacePublicData::analyseIntData(FunctionCodeType code, qint32 num)
{
    switch(code)
    {
    case FCT_WorkMode:      //工作模式
        mWorkMode = (WorkModeType)num;
        break;
    case FCT_SelfCheckStep: //自检步骤
        mSelfCheckStep = (SelfCheckStepType)num;
        break;
    case FCT_PrimingStep:   //预充步骤
        mPrimingStep = (PrimingStepType)num;
        break;
    case FCT_BloodBackStep:     //回血步骤
        mBloodBackStep = (BloodBackStepType)num;
        break;
    case FCT_DisplayTime:       //显示时间
        mDisplayTime.totalHour = num/3600;
        mDisplayTime.totalMin = num/60;
        mDisplayTime.totalSec = num;
        mDisplayTime.hour = mDisplayTime.totalHour;
        mDisplayTime.min = mDisplayTime.totalMin - mDisplayTime.totalHour*60;
        mDisplayTime.sec = mDisplayTime.totalSec - mDisplayTime.totalMin*60;
        break;
    case FCT_CureRunTime:   //治疗时间
        mCureRunTime = num;
        break;
    case FCT_BloodPumpFlow:     //血泵流量
        mBloodPumpFlow = num;
        break;
    case FCT_PrimingVolume:     //预充总量
        mPrimingVolume = num;
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  analyseDoubleData()
 功能描述：  解析double
 输入参数：  无
 返回的值：  code：功能码 | num：数据
 ***************************************************************************************************/
void InterfacePublicData::analyseDoubleData(FunctionCodeType code, double num)
{
    switch(code)
    {
    case FCT_HeatTemp:  //保温器温度
        mHeatTemp = num;
        break;
    case FCT_HeparinPumpFlow:       //肝素泵流量
        mHeparinPumpFlow = num;
        break;
    case FCT_BloodPumpAccVolume:    //血泵累积量
        mBloodPumpAccVolume = num;
        break;
    default:
        break;
    }
}

QString DisplayTimeData::toString(DisplayTimeData::DisplayTimeFormat format)
{
    QString str;
    switch(format)
    {
    case DTF_HHMM_MMSS:
        if(hour > 0)
        {
            str = QString("%1:%2").arg(hour, 2, 10, QLatin1Char('0')).arg(min, 2, 10, QLatin1Char('0'));
        }
        else
        {
            str = QString("%1:%2").arg(min, 2, 10, QLatin1Char('0')).arg(sec, 2, 10, QLatin1Char('0'));
        }
        break;
    case DTF_HHMMSS:
        str = QString("%1:%2:%3").arg(hour, 2, 10, QLatin1Char('0')).arg(min, 2, 10, QLatin1Char('0')).arg(sec, 2, 10, QLatin1Char('0'));
        break;
    case DTF_HM_MS:
        if(hour > 0)
        {
            str = QString("%1:%2").arg(hour).arg(min);
        }
        else
        {
            str = QString("%1:%2").arg(min).arg(sec);
        }
        break;
    case DTF_HMS:
        str = QString("%1:%2:%3").arg(hour).arg(min).arg(sec);
        break;
    case DTF_Min:
        if(hour > 0)
        {
            str = QString("%1 hour %2 min").arg(hour).arg(min);
        }
        else if(min > 0)
        {
            str = QString("%1 min").arg(min);
        }
        else
        {
            str = (sec == 0) ? "0 min" : "< 1 min";
        }
        break;
    case DTF_Sec:
        if(hour > 0)
        {
            str = QString("%1 hour %2 min %3 sec").arg(hour).arg(min).arg(sec);
        }
        else if(min > 0)
        {
            str = QString("%1 min %2 sec").arg(min).arg(sec);
        }
        else
        {
            str = QString("%1 sec").arg(sec);
        }
        break;
    default:
        str = QString("%1:%2:%3").arg(hour, 2, 10, QLatin1Char('0')).arg(min, 2, 10, QLatin1Char('0')).arg(sec, 2, 10, QLatin1Char('0'));
        break;
    }
    return str;
}
