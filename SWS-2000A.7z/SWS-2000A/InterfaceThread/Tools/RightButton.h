#ifndef RIGHTBUTTON_H
#define RIGHTBUTTON_H

#include <QLabel>
#include <QPushButton>

#include "RightButtonWidget.h"

class RightButton : public QPushButton
{
public:
    RightButton(QWidget *parent = nullptr);

public:
    void SetNameAndUnit(QString name, QString unit);    //设置控件名称、单位
    void SetValue(QString value);                       //设置控件值
    void SetSwitch(bool checked);                       //设置开关

private:
    void slotPressed();                 //按钮按下槽函数
    void slotReleased();                //按钮释放槽函数
    void slotToggled(bool checked);     //按钮状态槽函数

private:
    RightButtonWidget   *mWidget;
};

#endif // RIGHTBUTTON_H
