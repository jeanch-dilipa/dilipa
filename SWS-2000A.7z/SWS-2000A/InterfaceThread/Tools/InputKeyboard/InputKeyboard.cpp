#include "InputKeyboard.h"
#include "ui_InputKeyboard.h"

/***************************************************************************************************
 函数名称：  InputKeyboard()
 功能描述：  构造函数
 输入参数：  title---标题，code---功能码
 返回的值：  无
 ***************************************************************************************************/
InputKeyboard::InputKeyboard(QWidget *parent, QString title, FunctionCodeType code, QString unit) :
    QDialog(parent),
    ui(new Ui::InputKeyboard)
{
    ui->setupUi(this);

    this->setWindowFlags(Qt::FramelessWindowHint | Qt::Popup);
    ui->label_Title->setText(title);
    mCode = code;

    //移动到屏幕中间
    QPoint pos0_0(gIPD.mMainWidget->mapToGlobal(QPoint(0, 0)));
    qint32 x = (parent->width()-this->width())/2;
    qint32 y = (parent->height()-this->height())/2;
    this->move(x+pos0_0.x(), y+pos0_0.y());

    //初始化抖动窗口动画
    initShakeAnime();

    //校验边框
    setInputStyleSheet(true);   //未输入时显示正常

    //隐藏时间相关的控件
    switch(mCode)
    {
    case FCT_CureRunTime:
        break;
    default:
        ui->label_Colon->setVisible(false);
        ui->lineEdit_ValueB->setVisible(false);
        break;
    }

    //安装事件过滤器
    ui->lineEdit_Value->installEventFilter(this);
    ui->lineEdit_ValueB->installEventFilter(this);

    //获取上下限值
    if(gIPD.mInputInfoMap.contains(mCode))
    {
        mInputInfo = gIPD.mInputInfoMap.value(mCode);
        //显示上下限和单位
        ui->label_LimitAndUnit->setText(QString("%1~%2").arg(mInputInfo.lowerLimit).arg(mInputInfo.upperLimit));
        if(!unit.isEmpty())
        {
            ui->label_LimitAndUnit->setText(ui->label_LimitAndUnit->text() + " " + unit);
        }

        //正则
        mRegExp.setPattern(mInputInfo.regexp);
        mRegExpV.setRegExp(mRegExp);

        //判断是否可以使用正负号
        qint32 pos = 0;
        QString strSign = "-";
        QValidator::State state = mRegExpV.validate(strSign, pos);
        ui->pushButton_Sign->setEnabled(state == QValidator::Acceptable);

        //数据类型
        if(mInputInfo.dataType == "int")
        {   //int
            mType = FDT_Numeric;
        }
        else if(mInputInfo.dataType == "double")
        {   //double
            mType = FDT_Decimal;
            ui->pushButton_Point->setEnabled(true);     //启用小数点
        }
        else if(mInputInfo.dataType == "hh:mm")
        {
            mType = FDT_Numeric;
            ui->pushButton_Point->setText(":");
            ui->pushButton_Point->setEnabled(true);     //启用冒号
        }
    }
}

/***************************************************************************************************
 函数名称：  ~InputKeyboard()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
InputKeyboard::~InputKeyboard()
{
    gIPD.SetDataAndSendToDataDeal(FCT_InputKeyboard, FDT_Numeric, mCode);
    delete ui;
}

/***************************************************************************************************
 函数名称：  GetInputStr()
 功能描述：  获取输入字符串
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
QString InputKeyboard::GetInputStr()
{
    switch(mCode)
    {
    case FCT_BloodPumpFlow:
        return (ui->lineEdit_Value->text() + ":" + ui->lineEdit_ValueB->text());
        break;
    default:
        return ui->lineEdit_Value->text();
        break;
    }
}

/***************************************************************************************************
 函数名称：  on_pushButton_0_clicked()
 功能描述：  数字0槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_0_clicked()
{
    addInputText("0");
}

/***************************************************************************************************
 函数名称：  on_pushButton_1_clicked()
 功能描述：  数字1槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_1_clicked()
{
    addInputText("1");
}

/***************************************************************************************************
 函数名称：  on_pushButton_2_clicked()
 功能描述：  数字2槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_2_clicked()
{
    addInputText("2");
}

/***************************************************************************************************
 函数名称：  on_pushButton_3_clicked()
 功能描述：  数字3槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_3_clicked()
{
    addInputText("3");
}

/***************************************************************************************************
 函数名称：  on_pushButton_4_clicked()
 功能描述：  数字4槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_4_clicked()
{
    addInputText("4");
}

/***************************************************************************************************
 函数名称：  on_pushButton_5_clicked()
 功能描述：  数字5槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_5_clicked()
{
    addInputText("5");
}

/***************************************************************************************************
 函数名称：  on_pushButton_6_clicked()
 功能描述：  数字6槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_6_clicked()
{
    addInputText("6");
}

/***************************************************************************************************
 函数名称：  on_pushButton_7_clicked()
 功能描述：  数字7槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_7_clicked()
{
    addInputText("7");
}

/***************************************************************************************************
 函数名称：  on_pushButton_8_clicked()
 功能描述：  数字8槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_8_clicked()
{
    addInputText("8");
}

/***************************************************************************************************
 函数名称：  on_pushButton_9_clicked()
 功能描述：  数字9槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_9_clicked()
{
    addInputText("9");
}

/***************************************************************************************************
 函数名称：  on_pushButton_Point_clicked()
 功能描述：  小数点槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_Point_clicked()
{
    if(mCode == FCT_CureRunTime)
    {
        if(mInputFocus == IFT_VALUE_A)
        {
            setInputFocus(IFT_VALUE_B);
            if(ui->lineEdit_Value->text().isEmpty())
            {   //如果第一个框没输入，则自动添加0
                ui->lineEdit_Value->setText("0");
            }
        }
        else
        {
            setInputFocus(IFT_VALUE_A);
        }
        setInputStyleSheet(mAcceptStatus);
    }
    else
    {
        addInputText(".");
    }
}

/***************************************************************************************************
 函数名称：  on_pushButton_BackSpace_clicked()
 功能描述：  退格槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_BackSpace_clicked()
{
    delInputText();
}

/***************************************************************************************************
 函数名称：  on_pushButton_Clear_clicked()
 功能描述：  清空槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_Clear_clicked()
{
    ui->lineEdit_Value->setText("");
    ui->lineEdit_ValueB->setText("");
    ui->pushButton_Enter->setEnabled(false);
    setInputFocus(IFT_VALUE_A);
    mAcceptStatus = false;
    setInputStyleSheet(mAcceptStatus);
}

/***************************************************************************************************
 函数名称：  on_pushButton_ESC_clicked()
 功能描述：  退出槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_ESC_clicked()
{
    this->reject();
}

/***************************************************************************************************
 函数名称：  on_pushButton_Enter_clicked()
 功能描述：  确认槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_Enter_clicked()
{
    QVariant sendVar;
    if(mCode == FCT_CureRunTime)
    {   //治疗时间
        qint32 secs = ui->lineEdit_Value->text().toInt()*60*60 +
                ui->lineEdit_ValueB->text().toInt()*60;
        sendVar.setValue(secs);
    }
    else
    {
        switch(mType)
        {
        case FDT_Numeric:
            sendVar.setValue(ui->lineEdit_Value->text().toInt());
            break;
        case FDT_Decimal:
            sendVar.setValue(ui->lineEdit_Value->text().toDouble());
            break;
        default:
            break;
        }
    }

    gIPD.SetDataAndSendToDataDeal(mCode, mType, sendVar);
    this->accept();
}

/***************************************************************************************************
 函数名称：  on_pushButton_Sign_clicked()
 功能描述：  正负号槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::on_pushButton_Sign_clicked()
{
    if(ui->lineEdit_Value->text().mid(0, 1) != "-")
    {
        if(checkInputText("-" + ui->lineEdit_Value->text()))
        {
            ui->lineEdit_Value->setText("-" + ui->lineEdit_Value->text());
        }
    }
    else
    {
        if(checkInputText(ui->lineEdit_Value->text().mid(1, ui->lineEdit_Value->text().length()-1)))
        {
            ui->lineEdit_Value->setText(ui->lineEdit_Value->text().mid(1, ui->lineEdit_Value->text().length()-1));
        }
    }
}

/***************************************************************************************************
 函数名称：  checkInputText()
 功能描述：  检验输入是否合法
 输入参数：  str---校验文本
 返回的值：  无
 ***************************************************************************************************/
bool InputKeyboard::checkInputText(QString str)
{
    qint32 pos = 0;
    QValidator::State state = mRegExpV.validate(str, pos);
    if(state == QValidator::Intermediate)
    {   //部分匹配
        ui->pushButton_Enter->setEnabled(false);
        mAcceptStatus = false;
        setInputStyleSheet(mAcceptStatus);
        return true;
    }
    else if(state == QValidator::Acceptable)
    {   //完全匹配
        ui->pushButton_Enter->setEnabled(true);
        mAcceptStatus = true;
        setInputStyleSheet(mAcceptStatus);
        return true;
    }
    else
    {   //完全不匹配
        mShakeAnime->start();
        return false;
    }
}

/***************************************************************************************************
 函数名称：  addInputText()
 功能描述：  添加输入字符
 输入参数：  str---输入文本
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::addInputText(QString str)
{
    QString strCheck;
    QString strA = ui->lineEdit_Value->text();
    QString strB = ui->lineEdit_ValueB->text();

    switch(mCode)
    {
    case FCT_CureRunTime:
        if(mInputFocus == IFT_VALUE_A)
        {
            strCheck = strA + str + ":" + strB;
            if(checkInputText(strCheck))
            {
                ui->lineEdit_Value->setText(strA + str);
                //判断是否可以直接跳到第2个输入框
                if((ui->lineEdit_Value->text().toInt() >= 3) || ui->lineEdit_Value->text().length() >= 2)
                {
                    setInputFocus(IFT_VALUE_B);
                    setInputStyleSheet(mAcceptStatus);
                }
            }
        }
        else
        {
            strCheck = strA + ":" + strB + str;
            if(checkInputText(strCheck))
            {
                ui->lineEdit_ValueB->setText(strB + str);
            }
        }
        break;
    default:
        if(checkInputText(strA + str))
        {
            ui->lineEdit_Value->setText(strA + str);
        }
        break;
    }
}

/***************************************************************************************************
 函数名称：  delInputText()
 功能描述：  删除最后个字符
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::delInputText()
{
    QString strCheck;
    QString strA = ui->lineEdit_Value->text();
    QString strB = ui->lineEdit_ValueB->text();
    qint32 lenA = strA.length();
    qint32 lenB = strB.length();

    switch(mCode)
    {
    case FCT_CureRunTime:
        if(mInputFocus == IFT_VALUE_A)
        {
            strCheck = strA.mid(0, lenA-1) + ":" + strB;
            ui->lineEdit_Value->setText(strA.mid(0, lenA-1));
        }
        else
        {
            if(ui->lineEdit_ValueB->text().isEmpty())
            {
                strCheck = strA.mid(0, lenA-1) + ":" + strB;
                ui->lineEdit_Value->setText(strA.mid(0, lenA-1));
                setInputFocus(IFT_VALUE_A);
                setInputStyleSheet(mAcceptStatus);
            }
            else
            {
                strCheck = strA + ":" + strB.mid(0, lenB-1);
                ui->lineEdit_ValueB->setText(strB.mid(0, lenB-1));
            }
        }
        break;
    default:
        strCheck = strA.mid(0, lenA-1);
        ui->lineEdit_Value->setText(strCheck);
        break;
    }
    if(!checkInputText(strCheck))
    {
        ui->pushButton_Enter->setEnabled(false);
        mAcceptStatus = false;
        setInputStyleSheet(mAcceptStatus);
    }
}

void InputKeyboard::setInputStyleSheet(bool accept)
{
    QColor borderColor = accept ? mAcceptBorderColor : mNotAcceptBorderColor;
    QColor bgColor = accept ? mAcceptBgColor : mNotAcceptBgColor;
    bool doubleInput = false;    //双输入框

    if(mCode == FCT_CureRunTime)
    {
        doubleInput = true;
    }

    if(mInputFocus == IFT_VALUE_A)
    {
        ui->lineEdit_Value->setStyleSheet((doubleInput?"border-bottom: 4px solid #51C3D8;":"") + QString("background-color: %1;").arg(bgColor.name()));
        ui->lineEdit_ValueB->setStyleSheet((doubleInput?"border-bottom: 4px solid #00C4C4C4;":"") + QString("background-color: %1;").arg(bgColor.name()));
    }
    else
    {
        ui->lineEdit_Value->setStyleSheet((doubleInput?"border-bottom: 4px solid #00C4C4C4;":"") + QString("background-color: %1;").arg(bgColor.name()));
        ui->lineEdit_ValueB->setStyleSheet((doubleInput?"border-bottom: 4px solid #51C3D8;":"") + QString("background-color: %1;").arg(bgColor.name()));
    }
    ui->widget->setStyleSheet(QString("#widget{border: %1px solid %2; border-radius: 3px; background-color: %3;}").arg(accept?1:2).arg(borderColor.name()).arg(bgColor.name()));
}

/***************************************************************************************************
 函数名称：  setInputFocus()
 功能描述：  设置焦点，这里要设置焦点才能触发FocusIn
 输入参数：  ift---焦点
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::setInputFocus(InputKeyboard::InputFocusType ift)
{
    if(ift == IFT_VALUE_A)
    {
        ui->lineEdit_Value->setFocus();
    }
    else
    {
        ui->lineEdit_ValueB->setFocus();
    }
    mInputFocus = ift;
}

/***************************************************************************************************
 函数名称：  initShakeAnime()
 功能描述：  初始化抖动窗口
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void InputKeyboard::initShakeAnime()
{
    qint32 x = this->x();
    qint32 y = this->y();
    qint32 range = 7;
    mShakeAnime = new QPropertyAnimation(this, "geometry");
    mShakeAnime->setEasingCurve(QEasingCurve::InOutSine);
    mShakeAnime->setDuration(300);
    mShakeAnime->setStartValue(QRect(QPoint(x, y), this->size()));

    qint32 shakeCount = 10;   //抖动次数
    double nStep = 1.0/shakeCount;
    for(qint32 i = 1; i < shakeCount; i++)
    {
        range = i&1 ? -range : range;
        mShakeAnime->setKeyValueAt(nStep*i, QRect(QPoint(x + range, y), this->size()));
    }
    mShakeAnime->setEndValue(QRect(QPoint(x, y), this->size()));
}

/***************************************************************************************************
 函数名称：  eventFilter()
 功能描述：  事件过滤
 输入参数：  obj---控件，event---事件
 返回的值：  无
 ***************************************************************************************************/
bool InputKeyboard::eventFilter(QObject *obj, QEvent *event)
{
    if(obj == ui->lineEdit_Value)
    {
        if(event->type() == QEvent::FocusIn)
        {
            setInputFocus(IFT_VALUE_A);
            setInputStyleSheet(mAcceptStatus);
            return true;
        }
    }
    else if(obj == ui->lineEdit_ValueB)
    {
        if(event->type() == QEvent::FocusIn)
        {
            setInputFocus(IFT_VALUE_B);
            setInputStyleSheet(mAcceptStatus);
            if(ui->lineEdit_Value->text().isEmpty())
            {   //如果第一个框没输入，则自动添加0
                ui->lineEdit_Value->setText("0");
            }
            return true;
        }
    }
    return false;
}
