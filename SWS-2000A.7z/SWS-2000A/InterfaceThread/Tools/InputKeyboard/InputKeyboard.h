#ifndef INPUTKEYBOARD_H
#define INPUTKEYBOARD_H

#include <QDialog>
#include <QPropertyAnimation>
#include <QRegExp>
#include <QRegExpValidator>

#include "InterfaceThread/PublicData/InterfaceConfig.h"

namespace Ui {
class InputKeyboard;
}

class InputKeyboard : public QDialog
{
    Q_OBJECT

    enum InputFocusType
    {
        IFT_VALUE_A,    //输入框A
        IFT_VALUE_B     //输入框B
    };

public:
    explicit InputKeyboard(QWidget *parent = nullptr, QString title = "", FunctionCodeType code = FCT_Default, QString unit = "");
    ~InputKeyboard();

public:
    QString GetInputStr();              //获取输入字符串

private slots:
    void on_pushButton_0_clicked();     //数字0槽函数
    void on_pushButton_1_clicked();     //数字1槽函数
    void on_pushButton_2_clicked();     //数字2槽函数
    void on_pushButton_3_clicked();     //数字3槽函数
    void on_pushButton_4_clicked();     //数字4槽函数
    void on_pushButton_5_clicked();     //数字5槽函数
    void on_pushButton_6_clicked();     //数字6槽函数
    void on_pushButton_7_clicked();     //数字7槽函数
    void on_pushButton_8_clicked();     //数字8槽函数
    void on_pushButton_9_clicked();     //数字9槽函数
    void on_pushButton_Point_clicked();         //小数点槽函数
    void on_pushButton_BackSpace_clicked();     //退格槽函数
    void on_pushButton_Clear_clicked();         //清空槽函数
    void on_pushButton_ESC_clicked();           //退出槽函数
    void on_pushButton_Enter_clicked();         //确认槽函数
    void on_pushButton_Sign_clicked();          //正负号槽函数

private:
    bool checkInputText(QString str);   //检验输入是否合法
    void addInputText(QString str);     //添加输入字符
    void delInputText();                //删除最后个字符
    void setInputStyleSheet(bool accept);       //设置输入框样式
    void setInputFocus(InputFocusType ift);     //设置焦点，这里要设置焦点才能触发FocusIn
    void initShakeAnime();      //初始化抖动窗口

private:
    bool eventFilter(QObject *obj,  QEvent *event);     //事件过滤

private:
    Ui::InputKeyboard *ui;

private:
    FunctionCodeType    mCode;      //功能码
    FunctionDataType    mType;      //数据类型
    InputInfoData       mInputInfo; //输入信息
    QRegExp             mRegExp;    //正则
    QRegExpValidator    mRegExpV;   //正则校验
    InputFocusType      mInputFocus = IFT_VALUE_A;      //当前输入框
    QColor              mFocusColor = QColor("#E2F0D9");            //输入底色
    QColor              mNotFocusColor = QColor("#CDCDCD");         //未输入底色
    QColor              mAcceptBorderColor = QColor("#A0A0A0");     //校验成功边框
    //QColor              mAcceptBorderColor = QColor("#41CD52");     //校验成功边框
    QColor              mNotAcceptBorderColor = QColor("#DB976E");  //校验失败边框
    QColor              mAcceptBgColor = QColor("#FFFFFF");         //校验成功背景
    //QColor              mAcceptBgColor = QColor("#E2FFDD");         //校验成功背景
    QColor              mNotAcceptBgColor = QColor("#FFF7F0");      //校验失败背景
    bool                mAcceptStatus = false;      //当前是否已接受输入
    QPropertyAnimation  *mShakeAnime;               //窗口抖动动画
};

#endif // INPUTKEYBOARD_H
