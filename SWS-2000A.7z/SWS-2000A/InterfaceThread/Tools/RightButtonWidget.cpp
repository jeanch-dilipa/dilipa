#include "RightButtonWidget.h"
#include "ui_RightButtonWidget.h"

#include <QPainter>

/***************************************************************************************************
 函数名称：  RightButtonWidget()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
RightButtonWidget::RightButtonWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RightButtonWidget)
{
    ui->setupUi(this);
}

/***************************************************************************************************
 函数名称：  ~RightButtonWidget()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
RightButtonWidget::~RightButtonWidget()
{
    delete ui;
}

/***************************************************************************************************
 函数名称：  SetName()
 功能描述：  设置控件名称
 输入参数：  name---控件名称
 返回的值：  无
 ***************************************************************************************************/
void RightButtonWidget::SetName(QString name)
{
    ui->label_Name->setText(name);
}

/***************************************************************************************************
 函数名称：  SetUnit()
 功能描述：  设置控件单位
 输入参数：  unit---控件单位
 返回的值：  无
 ***************************************************************************************************/
void RightButtonWidget::SetUnit(QString unit)
{
    ui->label_Unit->setText(unit);
}

/***************************************************************************************************
 函数名称：  SetValue()
 功能描述：  设置控件值
 输入参数：  value---控件值
 返回的值：  无
 ***************************************************************************************************/
void RightButtonWidget::SetValue(QString value)
{
    ui->label_Value->setText(value);
}

/***************************************************************************************************
 函数名称：  SetSwitch()
 功能描述：  设置开关
 输入参数：  checked---是否开启
 返回的值：  无
 ***************************************************************************************************/
void RightButtonWidget::SetSwitch(bool checked)
{
    mSwitch = checked;
    update();
}

/***************************************************************************************************
 函数名称：  paintEvent()
 功能描述：  重绘事件
 输入参数：  event---事件
 返回的值：  无
 ***************************************************************************************************/
void RightButtonWidget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event)

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);    //反锯齿

    QRectF rect(10, this->height()-20, 10, 10);
    painter.setPen(QPen(Qt::black));     //边框
    painter.setBrush(mSwitch?Qt::green:Qt::gray);
    painter.drawEllipse(rect);
}
