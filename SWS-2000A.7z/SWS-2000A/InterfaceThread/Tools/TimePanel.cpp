#include "TimePanel.h"
#include "ui_TimePanel.h"

#include <QPainter>
#include <QtMath>
#include <QMouseEvent>

#include "InputKeyboard/InputKeyboard.h"

/***************************************************************************************************
 函数名称：  TimePanel()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
TimePanel::TimePanel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::TimePanel)
{
    ui->setupUi(this);

    connect(&gIPD, &InterfacePublicData::SIGNALDataFromDataDeal, this, &TimePanel::slotUpdate, Qt::UniqueConnection);
}

/***************************************************************************************************
 函数名称：  ~TimePanel()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
TimePanel::~TimePanel()
{
    delete ui;
}

/***************************************************************************************************
 函数名称：  SetProgress()
 功能描述：  设置进度
 输入参数：  value---进度
 返回的值：  无
 ***************************************************************************************************/
void TimePanel::SetProgress(qreal value)
{
    if(value < 0.001)
    {
        value = 0.0;
    }
    else if(value > 1.0)
    {
        value = 1.0;
    }
    mCurrAngle = -360*value + 90;
}

/***************************************************************************************************
 函数名称：  slotUpdate()
 功能描述：  更新槽函数
 输入参数：  code---功能码，type---数据类型，var---数据
 返回的值：  无
 ***************************************************************************************************/
void TimePanel::slotUpdate(FunctionCodeType code, FunctionDataType type, QVariant var)
{
    Q_UNUSED(var)
    Q_UNUSED(type)

    bool updatePrimingVolume = false;
    bool updateCureTime = false;

    switch(code)
    {
    case FCT_WorkMode:
    case FCT_BloodPumpAccVolume:
    case FCT_PrimingVolume:
        updatePrimingVolume = true;
        break;
    default:
        break;
    }

    switch(code)
    {
    case FCT_WorkMode:
    case FCT_DisplayTime:
        updateCureTime = true;
    default:
        break;
    }

    if(updatePrimingVolume)
    {   //更新预充量
        if((gIPD.mWorkMode == WMT_SelfCheck) || (gIPD.mWorkMode == WMT_Priming))
        {   //自检，预充
            if(gIPD.mPrimingVolume == 0)
            {   //设置预充总量为0时
                SetProgress(1.0);
            }
            else
            {   //预充总量 >0 时
                SetProgress(gIPD.mBloodPumpAccVolume/gIPD.mPrimingVolume);
            }
            ui->label_RemainTitle->setText(tr("剩余量"));
            double remainPrimingVol = gIPD.mPrimingVolume-gIPD.mBloodPumpAccVolume;
            if(remainPrimingVol < 0.001)
            {   //如果为负数，则显示为0
                remainPrimingVol = 0.0;
            }
            ui->label_RemainValue->setText(QString::number(remainPrimingVol, 'f', 0) + " ml");
            ui->label_TotalValue->setText(QString("预充总量：%1 ml").arg(gIPD.mPrimingVolume));
            update();
        }
    }

    if(updateCureTime)
    {   //更新治疗时间
        if(gIPD.mWorkMode == WMT_PatientConnect)
        {
            SetProgress(0.00);
            ui->label_RemainTitle->setText(tr("剩余时间"));
            ui->label_RemainValue->setText(gIPD.mDisplayTime.toString(DisplayTimeData::DTF_Min));
            ui->label_TotalValue->setText(QString("治疗时间(hh:mm)：%1:%2").arg(gIPD.mCureRunTime/3600, 2, 10, QLatin1Char('0')).arg(gIPD.mCureRunTime%3600/60, 2, 10, QLatin1Char('0')));
            update();
        }
        if(gIPD.mWorkMode == WMT_CureRun)
        {
            SetProgress(1.0-gIPD.mDisplayTime.totalSec*1.0/gIPD.mCureRunTime);
            ui->label_RemainTitle->setText(tr("剩余时间"));
            ui->label_RemainValue->setText(gIPD.mDisplayTime.toString(DisplayTimeData::DTF_Min));
            ui->label_TotalValue->setText(QString("治疗时间(hh:mm)：%1:%2").arg(gIPD.mCureRunTime/3600, 2, 10, QLatin1Char('0')).arg(gIPD.mCureRunTime%3600/60, 2, 10, QLatin1Char('0')));
            update();
        }
        else if(gIPD.mWorkMode == WMT_CureEnd)
        {
            SetProgress(1.0);
            ui->label_RemainTitle->setText(tr("剩余时间"));
            ui->label_RemainValue->setText(gIPD.mDisplayTime.toString(DisplayTimeData::DTF_Min));
            ui->label_TotalValue->setText(QString("治疗时间(hh:mm)：%1:%2").arg(gIPD.mCureRunTime/3600, 2, 10, QLatin1Char('0')).arg(gIPD.mCureRunTime%3600/60, 2, 10, QLatin1Char('0')));
            update();
        }
    }
}

/***************************************************************************************************
 函数名称：  drawBaseCircle()
 功能描述：  画底圆
 输入参数：  painter---画家
 返回的值：  无
 ***************************************************************************************************/
void TimePanel::drawBaseCircle(QPainter &painter)
{
    QRectF rect(-mBaseCircleR-1, -mBaseCircleR-1, mBaseCircleR*2+2, mBaseCircleR*2+2);
    painter.setPen(QPen(mBorderColor));     //边框
    painter.setBrush(mBaseColor);
    painter.drawEllipse(rect);
}

/***************************************************************************************************
 函数名称：  drawRingStartCircle()
 功能描述：  画环起点圆
 输入参数：  painter---画家
 返回的值：  无
 ***************************************************************************************************/
void TimePanel::drawRingStartCircle(QPainter &painter)
{
    QPointF point(0, -(mBaseCircleR-mRingWidth/2));
    QRadialGradient gradient(0, 0, mRingWidth*2);
    painter.setPen(QPen(mBorderColor));     //边框
    painter.setBrush(mStartColor);
    painter.drawEllipse(point, mRingWidth/2.0, mRingWidth/2.0);
}

/***************************************************************************************************
 函数名称：  drawRingCircle()
 功能描述：  画环
 输入参数：  painter---画家
 返回的值：  无
 ***************************************************************************************************/
void TimePanel::drawRingCircle(QPainter &painter)
{
    QRectF rect(-mBaseCircleR, -mBaseCircleR, mBaseCircleR*2, mBaseCircleR*2);

    //渐变，当前角度->结束角度
    QConicalGradient gradient(0, 0, 90);    //开始角度90°
    gradient.setColorAt((360-(mStartAngle-mCurrAngle))/360.0, mCurrColor);      //当前角度
    gradient.setColorAt(1.0, mStartColor);                                      //结束角度

    painter.setPen(Qt::NoPen);
    painter.setBrush(gradient);
    QPainterPath path;
    path.arcTo(rect, mStartAngle, mCurrAngle-mStartAngle);      //开始角度->当前角度，顺时针
    painter.drawPath(path);
}

/***************************************************************************************************
 函数名称：  drawMaskCircle()
 功能描述：  画遮挡圆
 输入参数：  painter---画家
 返回的值：  无
 ***************************************************************************************************/
void TimePanel::drawMaskCircle(QPainter &painter)
{
    QRectF rect(-mBaseCircleR+mRingWidth, -mBaseCircleR+mRingWidth, (mBaseCircleR-mRingWidth)*2, (mBaseCircleR-mRingWidth)*2);
    //QPalette pal = this->palette();
    //QColor bgColor = pal.background().color();
    painter.setPen(QPen(QColor("#FFFFFF"), 3));
    painter.setBrush(QColor("#E4EAEF"));
    painter.drawEllipse(rect);
}

/***************************************************************************************************
 函数名称：  drawIconCircle()
 功能描述：  画图标圆
 输入参数：  painter---画家
 返回的值：  无
 ***************************************************************************************************/
void TimePanel::drawIconCircle(QPainter &painter)
{
    QPointF point(0, 0);
    point.setX(point.x() + qCos((mCurrAngle-mStartAngle+90)*M_PI/180) * (mBaseCircleR-mRingWidth/2.0));
    point.setY(point.y() - qSin((mCurrAngle-mStartAngle+90)*M_PI/180) * (mBaseCircleR-mRingWidth/2.0));

    painter.setPen(QPen(mBorderColor));
    painter.setBrush(Qt::white);
    painter.drawEllipse(point, mIconCircleR, mIconCircleR);

    painter.setPen(Qt::NoPen);
    painter.setBrush(mCurrColor);
    painter.drawEllipse(point, mIconCircleR*0.6, mIconCircleR*0.6);
}

/***************************************************************************************************
 函数名称：  paintEvent()
 功能描述：  重绘函数
 输入参数：  event---事件
 返回的值：  无
 ***************************************************************************************************/
void TimePanel::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event)

    qint32 w = qMin(width(), height())-2;   //这里减少2像素是为了保证边缘能完全显示
    mBaseCircleR = w * 1/2.128;
    mRingWidth = w * 0.16/2.128;
    mIconCircleR = w * 0.16*0.9/2.128;

    QPainter painter(this);
    painter.translate(width()/2.0, height()/2.0);
    painter.setRenderHint(QPainter::Antialiasing, true);    //反锯齿

    drawBaseCircle(painter);            //画底圆
    drawRingStartCircle(painter);       //画环起点圆
    drawRingCircle(painter);            //画环
    drawMaskCircle(painter);            //画遮挡圆
    drawIconCircle(painter);            //画图标圆
}

/***************************************************************************************************
 函数名称：  mouseReleaseEvent()
 功能描述：  鼠标释放事件
 输入参数：  event---事件
 返回的值：  无
 ***************************************************************************************************/
void TimePanel::mouseReleaseEvent(QMouseEvent *event)
{
    if(pow(event->pos().x()-this->width()/2.0, 2)+pow(event->pos().y()-this->height()/2.0, 2) > pow(mBaseCircleR-mRingWidth, 2))
    {   //如果不在遮挡圆区域内点击，无效
        return;
    }

    switch(gIPD.mWorkMode)
    {
    case WMT_SelfCheck:
    case WMT_Priming:
    {
        InputKeyboard kb(gIPD.mMainWidget, tr("预充总量"), FCT_PrimingVolume, "ml");
        kb.exec();
    }
        break;
    case WMT_PatientConnect:
    case WMT_CureRun:
    case WMT_CureEnd:
    {
        InputKeyboard kb(gIPD.mMainWidget, tr("治疗时间"), FCT_CureRunTime, "hh:mm");
        kb.exec();
    }
        break;
    default:
        break;
    }
}
