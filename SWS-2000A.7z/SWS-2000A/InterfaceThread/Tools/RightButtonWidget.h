#ifndef RIGHTBUTTONWIDGET_H
#define RIGHTBUTTONWIDGET_H

#include <QWidget>

namespace Ui {
class RightButtonWidget;
}

class RightButtonWidget : public QWidget
{
    Q_OBJECT

public:
    explicit RightButtonWidget(QWidget *parent = nullptr);
    ~RightButtonWidget();

private:
    Ui::RightButtonWidget *ui;

public:
    void SetName(QString name);     //设置控件名称
    void SetUnit(QString unit);     //设置控件单位
    void SetValue(QString value);   //设置控件值
    void SetSwitch(bool checked);   //设置开关

protected:
    void paintEvent(QPaintEvent *event);    //重绘事件

private:
    bool mSwitch = false;   //开关状态
};

#endif // RIGHTBUTTONWIDGET_H
