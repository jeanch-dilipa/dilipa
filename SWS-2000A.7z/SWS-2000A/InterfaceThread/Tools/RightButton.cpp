#include "RightButton.h"

#include <QVBoxLayout>

/***************************************************************************************************
 函数名称：  RightButton()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
RightButton::RightButton(QWidget *parent) : QPushButton(parent)
{
    QVBoxLayout *vl = new QVBoxLayout;
    vl->setMargin(0);
    mWidget = new RightButtonWidget(this);
    vl->addWidget(mWidget);
    setLayout(vl);

    connect(this, &QPushButton::pressed, this, &RightButton::slotPressed, Qt::UniqueConnection);
    connect(this, &QPushButton::released, this, &RightButton::slotReleased, Qt::UniqueConnection);
    connect(this, &QPushButton::toggled, this, &RightButton::slotToggled, Qt::UniqueConnection);
}

/***************************************************************************************************
 函数名称：  SetNameAndUnit()
 功能描述：  设置控件名称、单位
 输入参数：  name---控件名称，unit---控件单位
 返回的值：  无
 ***************************************************************************************************/
void RightButton::SetNameAndUnit(QString name, QString unit)
{
    mWidget->SetName(name);
    mWidget->SetUnit(unit);
}

/***************************************************************************************************
 函数名称：  SetValue()
 功能描述：  设置控件值
 输入参数：  value---控件值
 返回的值：  无
 ***************************************************************************************************/
void RightButton::SetValue(QString value)
{
    mWidget->SetValue(value);
}

/***************************************************************************************************
 函数名称：  SetValue()
 功能描述：  设置开关
 输入参数：  check---是否开启
 返回的值：  无
 ***************************************************************************************************/
void RightButton::SetSwitch(bool checked)
{
    mWidget->SetSwitch(checked);
}

/***************************************************************************************************
 函数名称：  slotPressed()
 功能描述：  按钮按下槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void RightButton::slotPressed()
{
    mWidget->setStyleSheet("color: #FFFFFF;");
}

/***************************************************************************************************
 函数名称：  slotReleased()
 功能描述：  按钮释放槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void RightButton::slotReleased()
{
    if(this->isChecked())
    {
        mWidget->setStyleSheet("color: #FFFFFF;");
    }
    else
    {
        mWidget->setStyleSheet("color: #1B72BB;");
    }
}

/***************************************************************************************************
 函数名称：  slotToggled()
 功能描述：  按钮状态槽函数
 输入参数：  check---是否选中
 返回的值：  无
 ***************************************************************************************************/
void RightButton::slotToggled(bool checked)
{
    if(checked)
    {
        mWidget->setStyleSheet("color: #FFFFFF;");
    }
    else
    {
        mWidget->setStyleSheet("color: #1B72BB;");
    }
}
