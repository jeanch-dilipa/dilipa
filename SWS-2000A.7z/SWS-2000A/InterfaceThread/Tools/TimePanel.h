#ifndef TIMEPANEL_H
#define TIMEPANEL_H

#include <QWidget>

#include "InterfaceThread/PublicData/InterfaceConfig.h"

namespace Ui {
class TimePanel;
}

class TimePanel : public QWidget
{
    Q_OBJECT

public:
    explicit TimePanel(QWidget *parent = nullptr);
    ~TimePanel();

private:
    Ui::TimePanel *ui;

public:
    void SetProgress(qreal value);      //设置进度
    inline void SetBorderColor(QColor borderColor){ mBorderColor = borderColor; }   //设置边框颜色
    inline void SetBaseColor(QColor baseColor){ mBaseColor = baseColor; }           //设置底圆颜色
    inline void SetStartColor(QColor startColor){ mStartColor = startColor; }       //设置开始颜色
    inline void SetCurrColor(QColor currColor){ mCurrColor = currColor; }           //设置当前颜色

private:
    void slotUpdate(FunctionCodeType code, FunctionDataType type, QVariant var);    //更新槽函数
    void drawBaseCircle(QPainter &painter);         //画底圆
    void drawRingStartCircle(QPainter &painter);    //画环起点圆
    void drawRingCircle(QPainter &painter);         //画环
    void drawMaskCircle(QPainter &painter);         //画遮挡圆
    void drawIconCircle(QPainter &painter);         //画图标圆

protected:
    void paintEvent(QPaintEvent *event);    //重绘事件
    void mouseReleaseEvent(QMouseEvent *event);     //鼠标释放事件

private:
    float   mStartAngle = 90;       //起始角度
    float   mCurrAngle = -180;      //当前角度
    float   mRingWidth = 0;         //环宽度
    float   mBaseCircleR = 0;       //底圆半径
    float   mIconCircleR = 0;       //图标圆半径
    QColor  mBorderColor = QColor("#B8B8B8");   //边框颜色
    QColor  mBaseColor = QColor("#EAF3F7");     //底圆颜色
    QColor  mStartColor = QColor("#0D74BE");    //起始颜色
    QColor  mCurrColor = QColor("#0F99E4");     //当前颜色
};

#endif // TIMEPANEL_H
