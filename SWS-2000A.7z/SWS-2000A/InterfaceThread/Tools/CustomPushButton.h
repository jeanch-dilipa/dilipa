#ifndef CUSTOMPUSHBUTTON_H
#define CUSTOMPUSHBUTTON_H

#include <QPushButton>

#include "Commom/PublicDefine/PublicEnumDefine.h"

class CustomPushButton : public QPushButton
{
    Q_OBJECT
public:
    explicit CustomPushButton(QWidget *parent = nullptr);

public:
    FunctionCodeType mCode;     //按钮功能码
};

#endif // CUSTOMPUSHBUTTON_H
