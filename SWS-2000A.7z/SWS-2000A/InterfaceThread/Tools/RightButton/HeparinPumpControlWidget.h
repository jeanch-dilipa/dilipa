#ifndef HEPARINPUMPCONTROLWIDGET_H
#define HEPARINPUMPCONTROLWIDGET_H

#include <QWidget>

namespace Ui {
class HeparinPumpControlWidget;
}

class HeparinPumpControlWidget : public QWidget
{
    Q_OBJECT

public:
    explicit HeparinPumpControlWidget(QWidget *parent = nullptr);
    ~HeparinPumpControlWidget();

private slots:
    void on_pushButton_Switch_clicked(bool checked);    //开关按钮点击槽函数
    void on_pushButton_Switch_toggled(bool checked);    //开关按钮状态变化槽函数
    void on_pushButton_Flow_clicked();                  //肝素泵流量按钮槽函数

private:
    Ui::HeparinPumpControlWidget *ui;
};

#endif // HEPARINPUMPCONTROLWIDGET_H
