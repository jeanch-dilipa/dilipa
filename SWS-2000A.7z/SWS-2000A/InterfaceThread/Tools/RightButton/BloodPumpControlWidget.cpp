#include "BloodPumpControlWidget.h"
#include "ui_BloodPumpControlWidget.h"

/***************************************************************************************************
 函数名称：  BloodPumpControlWidget()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
BloodPumpControlWidget::BloodPumpControlWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::BloodPumpControlWidget)
{
    ui->setupUi(this);
}

/***************************************************************************************************
 函数名称：  ~BloodPumpControlWidget()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
BloodPumpControlWidget::~BloodPumpControlWidget()
{
    delete ui;
}

/***************************************************************************************************
 函数名称：  on_pushButton_Switch_clicked()
 功能描述：  开关按钮点击槽函数
 输入参数：  checked---是否开启
 返回的值：  无
 ***************************************************************************************************/
void BloodPumpControlWidget::on_pushButton_Switch_clicked(bool checked)
{
    gIPD.SetDataAndSendToDataDeal(FCT_BloodPumpSwitch, FDT_Boolean, checked);
}

/***************************************************************************************************
 函数名称：  on_pushButton_Switch_toggled()
 功能描述：  开关按钮状态变化槽函数
 输入参数：  checked---是否开启
 返回的值：  无
 ***************************************************************************************************/
void BloodPumpControlWidget::on_pushButton_Switch_toggled(bool checked)
{
    if(checked)
    {
        ui->pushButton_Switch->setText(tr("开"));
    }
    else
    {
        ui->pushButton_Switch->setText(tr("关"));
    }
}

/***************************************************************************************************
 函数名称：  on_pushButton_Flow_clicked()
 功能描述：  血泵流量槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void BloodPumpControlWidget::on_pushButton_Flow_clicked()
{
    InputKeyboard kb(gIPD.mMainWidget, tr("血泵流量"), FCT_BloodPumpFlow, "ml/min");
    kb.exec();
}

/***************************************************************************************************
 函数名称：  on_pushButton_Plus_clicked()
 功能描述：  血泵流量+槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void BloodPumpControlWidget::on_pushButton_Plus_clicked()
{
    //获取血泵流量上限
    qint32 max = gIPD.mInputInfoMap.value(FCT_BloodPumpFlow).upperLimit.toInt();
    qint32 set = gIPD.mBloodPumpFlow + 10;
    if(set > max)
    {
        set = max;
    }
    gIPD.SetDataAndSendToDataDeal(FCT_BloodPumpFlow, FDT_Numeric, set);
}

/***************************************************************************************************
 函数名称：  on_pushButton_Minus_clicked()
 功能描述：  血泵流量-槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void BloodPumpControlWidget::on_pushButton_Minus_clicked()
{
    //获取血泵流量下限
    qint32 min = gIPD.mInputInfoMap.value(FCT_BloodPumpFlow).lowerLimit.toInt();
    qint32 set = gIPD.mBloodPumpFlow - 10;
    if(set < min)
    {
        set = min;
    }
    gIPD.SetDataAndSendToDataDeal(FCT_BloodPumpFlow, FDT_Numeric, set);
}
