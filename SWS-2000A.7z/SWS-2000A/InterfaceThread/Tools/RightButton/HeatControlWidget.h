#ifndef HEATCONTROLWIDGET_H
#define HEATCONTROLWIDGET_H

#include <QWidget>

namespace Ui {
class HeatControlWidget;
}

class HeatControlWidget : public QWidget
{
    Q_OBJECT

public:
    explicit HeatControlWidget(QWidget *parent = nullptr);
    ~HeatControlWidget();

private slots:
    void on_pushButton_Switch_clicked(bool checked);    //开关按钮点击槽函数
    void on_pushButton_Switch_toggled(bool checked);    //开关按钮状态变化槽函数
    void on_pushButton_Temp_clicked();                  //保温器温度按钮槽函数

private:
    Ui::HeatControlWidget *ui;
};

#endif // HEATCONTROLWIDGET_H
