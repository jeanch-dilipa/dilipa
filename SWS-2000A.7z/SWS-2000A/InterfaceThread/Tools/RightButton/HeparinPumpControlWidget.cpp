#include "HeparinPumpControlWidget.h"
#include "ui_HeparinPumpControlWidget.h"

#include "InterfaceThread/Tools/InputKeyboard/InputKeyboard.h"

/***************************************************************************************************
 函数名称：  HeparinPumpControlWidget()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
HeparinPumpControlWidget::HeparinPumpControlWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::HeparinPumpControlWidget)
{
    ui->setupUi(this);
}

/***************************************************************************************************
 函数名称：  ~HeparinPumpControlWidget()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
HeparinPumpControlWidget::~HeparinPumpControlWidget()
{
    delete ui;
}

/***************************************************************************************************
 函数名称：  on_pushButton_Switch_clicked()
 功能描述：  开关按钮点击槽函数
 输入参数：  checked---是否开启
 返回的值：  无
 ***************************************************************************************************/
void HeparinPumpControlWidget::on_pushButton_Switch_clicked(bool checked)
{
    gIPD.SetDataAndSendToDataDeal(FCT_HeparinSwitch, FDT_Boolean, checked);
}

/***************************************************************************************************
 函数名称：  on_pushButton_Switch_toggled()
 功能描述：  开关按钮状态变化槽函数
 输入参数：  checked---是否开启
 返回的值：  无
 ***************************************************************************************************/
void HeparinPumpControlWidget::on_pushButton_Switch_toggled(bool checked)
{
    if(checked)
    {
        ui->pushButton_Switch->setText(tr("开"));
    }
    else
    {
        ui->pushButton_Switch->setText(tr("关"));
    }
}

/***************************************************************************************************
 函数名称：  on_pushButton_Flow_clicked()
 功能描述：  肝素泵流量按钮槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void HeparinPumpControlWidget::on_pushButton_Flow_clicked()
{
    InputKeyboard kb(gIPD.mMainWidget, tr("肝素泵流量"), FCT_HeparinPumpFlow, "ml/h");
    kb.exec();
}
