#ifndef BLOODPUMPCONTROLWIDGET_H
#define BLOODPUMPCONTROLWIDGET_H

#include <QWidget>

#include "InterfaceThread/Tools/InputKeyboard/InputKeyboard.h"

namespace Ui {
class BloodPumpControlWidget;
}

class BloodPumpControlWidget : public QWidget
{
    Q_OBJECT

public:
    explicit BloodPumpControlWidget(QWidget *parent = nullptr);
    ~BloodPumpControlWidget();

private slots:
    void on_pushButton_Switch_clicked(bool checked);    //开关按钮点击槽函数
    void on_pushButton_Switch_toggled(bool checked);    //开关按钮状态变化槽函数
    void on_pushButton_Flow_clicked();                  //血泵流量槽函数
    void on_pushButton_Plus_clicked();                  //血泵流量+槽函数
    void on_pushButton_Minus_clicked();                 //血泵流量-槽函数

private:
    Ui::BloodPumpControlWidget *ui;
};

#endif // BLOODPUMPCONTROLWIDGET_H
