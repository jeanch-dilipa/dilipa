#include "HeatControlWidget.h"
#include "ui_HeatControlWidget.h"

#include "InterfaceThread/Tools/InputKeyboard/InputKeyboard.h"

/***************************************************************************************************
 函数名称：  HeatControlWidget()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
HeatControlWidget::HeatControlWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::HeatControlWidget)
{
    ui->setupUi(this);
}

/***************************************************************************************************
 函数名称：  ~HeatControlWidget()
 功能描述：  析构函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
HeatControlWidget::~HeatControlWidget()
{
    delete ui;
}

/***************************************************************************************************
 函数名称：  on_pushButton_Switch_clicked()
 功能描述：  开关按钮点击槽函数
 输入参数：  checked---是否开启
 返回的值：  无
 ***************************************************************************************************/
void HeatControlWidget::on_pushButton_Switch_clicked(bool checked)
{
    gIPD.SetDataAndSendToDataDeal(FCT_HeatSwitch, FDT_Boolean, checked);
}

/***************************************************************************************************
 函数名称：  on_pushButton_Switch_toggled()
 功能描述：  开关按钮状态变化槽函数
 输入参数：  checked---是否开启
 返回的值：  无
 ***************************************************************************************************/
void HeatControlWidget::on_pushButton_Switch_toggled(bool checked)
{
    if(checked)
    {
        ui->pushButton_Switch->setText(tr("开"));
    }
    else
    {
        ui->pushButton_Switch->setText(tr("关"));
    }
}

/***************************************************************************************************
 函数名称：  on_pushButton_Temp_clicked()
 功能描述：  保温器温度按钮槽函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void HeatControlWidget::on_pushButton_Temp_clicked()
{
    InputKeyboard kb(gIPD.mMainWidget, tr("保温器温度"), FCT_HeatTemp, "℃");
    kb.exec();
}
