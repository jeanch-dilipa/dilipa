#ifndef SQLTHREAD_H
#define SQLTHREAD_H

#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>

#include "SqlDataDefine.h"
#include "Commom/PublicDefine/PublicEnumDefine.h"
#include "DataDealThread/RS485ProtocolDefine/RS485ProtocolType.h"

class SqlThread : public QObject
{
    Q_OBJECT
public:
    explicit SqlThread(QObject *parent = nullptr);

signals:
    void SIGNALSendQueryData(SqlOperateType operate, QVariant var);     //发送查询结果

public slots:
    void SLOTReceiveQuery(SqlOperateType operate, QVariant var);        //解析数据语句

private:
    void initSqlite();      //初始化数据库

private:
    QSqlDatabase    mDB;    //数据库
    QSqlQuery       mQuery; //数据库查询
};

#endif // SQLTHREAD_H
