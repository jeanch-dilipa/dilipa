#include "SqlThread.h"

#include <QFile>

#define DEFAULT_DB          "2000A.db"      //数据库名
#define INPUT_INFO_TABLE    "InputInfo"     //输入信息表
#define BOARD_CONFIG_TABLE  "BoardConfig"   //模块板配置表

Q_DECLARE_METATYPE(FunctionCodeType);
Q_DECLARE_METATYPE(InputInfoData);
Q_DECLARE_METATYPE(DataAttributeType);

/***************************************************************************************************
 函数名称：  SqlThread()
 功能描述：  构造函数
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
SqlThread::SqlThread(QObject *parent) : QObject(parent)
{
    initSqlite();   //初始化数据库
}

/***************************************************************************************************
 函数名称：  SLOTReceiveQuery()
 功能描述：  解析数据语句
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void SqlThread::SLOTReceiveQuery(SqlOperateType operate, QVariant var)
{
    Q_UNUSED(var)

    QString cmd;
    switch(operate)
    {
    case SOT_SELECT_INPUT_INFO:     //查询输入信息
    {
        QMap<FunctionCodeType, InputInfoData> data;
        InputInfoData inputInfo;
        cmd = QString("SELECT code, regexp, lowerLimit, upperLimit, codeType FROM `%1`").arg(INPUT_INFO_TABLE);
        if(mQuery.exec(cmd))
        {
            while(mQuery.next())
            {   //遍历
                inputInfo.regexp = mQuery.value(1).toString();
                inputInfo.lowerLimit = mQuery.value(2).toString();
                inputInfo.upperLimit = mQuery.value(3).toString();
                inputInfo.dataType = mQuery.value(4).toString();
                data.insert((FunctionCodeType)mQuery.value(0).toInt(), inputInfo);
            }
        }
        QVariant sendVar;
        sendVar.setValue(data);
        emit SIGNALSendQueryData(operate, sendVar);
    }
        break;
    case SOT_SELECT_BOARD_CONFIG:   //查询模块板配置
    {
        DataAttributeType attr = DataAttributeType();
        QList<DataAttributeType> attrList;
        QString cmd = QString("SELECT address, command, uartMode, dataType, length FROM `%1`").arg(BOARD_CONFIG_TABLE);
        if(mQuery.exec(cmd))
        {
            while(mQuery.next())
            {   //遍历
                attr.moduleAddrAndCmd.addr = (ModuleBoardAddrType)mQuery.value(0).toInt();
                attr.moduleAddrAndCmd.cmd = (SysBusCmdType)mQuery.value(1).toInt();
                attr.uartMode = (UartModeType)mQuery.value(2).toInt();
                attr.dataType = (DataTypeType)mQuery.value(3).toInt();
                attr.dataLength = mQuery.value(4).toInt();
                attrList.append(attr);
            }
        }
        QVariant sendVar;
        sendVar.setValue(attrList);
        emit SIGNALSendQueryData(operate, sendVar);
    }
        break;
    default:
        break;
    }
}

/***************************************************************************************************
 函数名称：  initSqlite()
 功能描述：  初始化数据库
 输入参数：  无
 返回的值：  无
 ***************************************************************************************************/
void SqlThread::initSqlite()
{
    if(mDB.contains(DEFAULT_DB))
    {
        mDB = QSqlDatabase::database(DEFAULT_DB);
    }
    else
    {
        mDB = QSqlDatabase::addDatabase("QSQLITE", DEFAULT_DB);
    }
    mDB.setDatabaseName(DEFAULT_DB);

    //判断数据库文件是否存在
    QFile dbFile(QString("./") + DEFAULT_DB);
    if(!dbFile.exists())
    {
        return;
    }

    //打开数据库
    if(!mDB.open())
    {   //数据库打开失败
        return;
    }
    mQuery = QSqlQuery(mDB);
}
