#ifndef SQLDATADEFINE_H
#define SQLDATADEFINE_H

#include <QString>

///数据操作
enum SqlOperateType
{
    SOT_SELECT_INPUT_INFO,      //查询输入信息
    SOT_SELECT_BOARD_CONFIG     //查询模块板配置
};

struct InputInfoData
{
    QString regexp;         //正则
    QString lowerLimit;     //下限
    QString upperLimit;     //上限
    QString dataType;       //数据类型
};

#endif // SQLDATADEFINE_H
