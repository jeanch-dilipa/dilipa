#ifndef MYTIMER_H
#define MYTIMER_H
#include <QTimer>

class MyTimer : public QTimer
{
public:
    explicit MyTimer(QObject *parent = nullptr);
    void setInterval(int msec);

    int speed() const;
    void setSpeed(int speed);

public Q_SLOTS:
    void start(int msec);
    void start();


private:
    int m_speed = 1; //提升的倍数
};

#endif // MYTIMER_H
