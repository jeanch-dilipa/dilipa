#include "mytimer.h"
#include "common/publicdata.h"


MyTimer::MyTimer(QObject *parent) : QTimer(parent)
{
    connect(&g_ss, &SystemSettingsType::speedChanged, this, &MyTimer::setSpeed);
}

void MyTimer::setInterval(int msec)
{
    QTimer::setInterval(msec/m_speed); //提高Timer的速率
}

void MyTimer::start(int msec)
{
    QTimer::start(msec/m_speed);
}

void MyTimer::start()
{
    QTimer::start();
}

int MyTimer::speed() const
{
    return m_speed;
}

void MyTimer::setSpeed(int sp)
{
    QTimer::setInterval(interval() * speed()); //恢复正常时间
    m_speed = sp; //更新加速倍数
    setInterval(interval());//更新实际时间
}
