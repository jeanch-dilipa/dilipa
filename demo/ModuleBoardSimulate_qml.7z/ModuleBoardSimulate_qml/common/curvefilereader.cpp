#include "curvefilereader.h"
#include <QFile>
#include <QVector>

CurveFileReader::CurveFileReader(QObject *parent) : QObject(parent)
{

}

void CurveFileReader::setSource(QUrl source)
{
//    if (m_source == source)
//        return;

    m_source = source;
    emit sourceChanged(m_source);

    QFile f(m_source.toLocalFile());
    if(f.open(QIODevice::ReadOnly))
    {
        QString content = f.readAll();
        f.close();
        QStringList datas = content.split(QRegExp("[\r\n]"),QString::SkipEmptyParts);
        if(!datas.isEmpty() && datas.first() == "相对血容量")
        {
            datas.removeFirst(); //移除表头
            m_data.clear();//清除原数据
            foreach(QString data, datas)
            {
                m_data.append(data.toDouble());
            }
            emit dataChanged(m_data);
        }
    }
}
