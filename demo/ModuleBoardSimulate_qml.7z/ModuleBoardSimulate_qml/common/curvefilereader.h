#ifndef CURVEFILEREADER_H
#define CURVEFILEREADER_H

#include <QObject>
#include <QUrl>
#include <QVector>

class CurveFileReader : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QUrl source READ source WRITE setSource NOTIFY sourceChanged)
    Q_PROPERTY(QVector<double> data READ data WRITE setData NOTIFY dataChanged)
    Q_PROPERTY(QString dataName READ dataName WRITE setDataName NOTIFY dataNameChanged)

    QUrl m_source;

    QVector<double> m_data;

    QString m_dataName;

public:
    explicit CurveFileReader(QObject *parent = nullptr);

    QUrl source() const
    {
        return m_source;
    }

    QVector<double> data() const
    {
        return m_data;
    }

    QString dataName() const
    {
        return m_dataName;
    }

public slots:
    void setSource(QUrl source);


    void setData(QVector<double> data)
    {
        if (m_data == data)
            return;

        m_data = data;
        emit dataChanged(m_data);
    }

    void setDataName(QString dataName)
    {
        if (m_dataName == dataName)
            return;

        m_dataName = dataName;
        emit dataNameChanged(m_dataName);
    }

signals:

    void sourceChanged(QUrl source);
    void dataChanged(QVector<double> data);
    void dataNameChanged(QString dataName);
};

#endif // CURVEFILEREADER_H
