#include "publicdata.h"

ModuleBoardData      g_mbd;
SystemSettingsType   g_ss;
ModuleSimDataSetSt   g_simDa;
