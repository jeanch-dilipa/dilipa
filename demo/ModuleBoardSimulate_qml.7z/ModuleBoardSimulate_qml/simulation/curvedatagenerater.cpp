#include "curvedatagenerater.h"
#include <QDebug>

CurveTargetSt::CurveTargetSt(float *target, quint16 period, const QVector<double> &curveData, QObject *parent):QObject(parent),
    m_pTargetVal(target),
    m_period(period),
    m_curveData(curveData)
{
    m_timer = new MyTimer(this);

    if(!m_curveData.isEmpty())
    {
        *m_pTargetVal = m_curveData.at(m_currentIndex);
    }

    connect(m_timer, &MyTimer::timeout, this, [=]
    {
        if(m_currentIndex >=0 && m_currentIndex<m_curveData.size())
        {
            *m_pTargetVal = m_curveData.at(m_currentIndex);

            if(m_reverse)
            {
                --m_currentIndex;
            }
            else
            {
                ++m_currentIndex;
            }
            if(m_repeat)
            {
                if(m_currentIndex < 0 )
                {
                    m_currentIndex = m_curveData.size() -1;
                }
                else if(m_currentIndex > (m_curveData.size() -1))
                {
                    m_currentIndex = 0;
                }
            }
        }


    });
}

void CurveTargetSt::setReverse(bool reverse)
{
    m_reverse = reverse;
}

void CurveTargetSt::setRepeat(bool repeat)
{
    m_repeat = repeat;
}

CurveDataGenerater::CurveDataGenerater(QObject *parent) : QObject(parent)
{
    //do nothing;
}

void CurveDataGenerater::addTarget(float * const target, int period, const QVector<double> &data)
{
    if(target == Q_NULLPTR)
    {
        return;
    }

    if(!m_targetList.contains(target))
    {
        CurveTargetSt *targetSt = new CurveTargetSt(target, period, data, this);
        m_targetList.insert(target, targetSt);
    }
    else
    {
        m_targetList[target]->setPeriod(period);
        m_targetList[target]->setCurveData(data);
    }
}

void CurveDataGenerater::addTarget( SimDataSt * const dataSt )
{
    if(dataSt == Q_NULLPTR)
    {
        return;
    }
    if(!m_targetList.contains(&dataSt->value))
    {
        CurveTargetSt *targetSt = new CurveTargetSt(&dataSt->value, dataSt->curve.period, dataSt->curve.data, this);
        targetSt->setRepeat(dataSt->curve.repeat);
        targetSt->setReverse(dataSt->curve.reverse);
        m_targetList.insert(&dataSt->value, targetSt);
    }
    else
    {
        m_targetList[&dataSt->value]->setPeriod(dataSt->curve.period);
        m_targetList[&dataSt->value]->setCurveData(dataSt->curve.data);
        m_targetList[&dataSt->value]->setRepeat(dataSt->curve.repeat);
        m_targetList[&dataSt->value]->setReverse(dataSt->curve.reverse);
    }

}

void CurveDataGenerater::removeTarget(float * const target)
{
    if(m_targetList.contains(target))
    {
        m_targetList[target]->stop();
        m_targetList[target]->deleteLater();
        m_targetList.remove(target);
    }
}

void CurveDataGenerater::clearTarget()
{
    foreach(CurveTargetSt *target, m_targetList) //会直接调用hash.valuse(),不用显式调用
    {
        target->deleteLater();
    }
    m_targetList.clear();
}

void CurveDataGenerater::startTarget(float * const target)
{
    if(m_targetList.contains(target))
    {
        m_targetList[target]->start();
    }
}

void CurveDataGenerater::startTarget(SimDataSt * const dataSt)
{
    if(m_targetList.contains(&dataSt->value))
    {
        m_targetList[&dataSt->value]->start(dataSt->curve.startIndex);
    }
}
