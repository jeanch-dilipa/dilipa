#ifndef CURVEDATAGENERATER_H
#define CURVEDATAGENERATER_H

#include <QObject>
#include "speedup/mytimer.h"
#include <QHash>
#include "simulationsetdata.h"


//跟随指定曲线变化的目标
class CurveTargetSt : public QObject
{
    Q_OBJECT

public:
    explicit CurveTargetSt(float *target, quint16 period, const QVector<double> &curveData, QObject *parent = Q_NULLPTR);

    inline void setPeriod(int period)
    {
        if(m_period != period)
        {
            m_period = period;
            if(m_timer->isActive())
            {
                m_timer->start(m_period);
            }
        }
    }

    inline void setCurveData(const QVector<double> &curveData)
    {
        if(m_curveData != curveData)
        {
            m_curveData = curveData;
            m_currentIndex = 0;
        }
    }

    inline void start(int startIndex = 0)
    {
        m_currentIndex = startIndex;
        if(!m_timer->isActive())
        {
            m_timer->start(m_period);
        }
    }

    inline void stop()
    {
        m_timer->stop();
    }

    inline float* targetVal()
    {
        return m_pTargetVal;
    }

    void setReverse(bool reverse);

    void setRepeat(bool repeat);

private:
    float           *m_pTargetVal = Q_NULLPTR;  //目标变量地址
    quint16         m_period = 1000;  //数据采样周期
    QVector<double> m_curveData;  //曲线数据
    int             m_currentIndex = 0;
    MyTimer          *m_timer;
    bool            m_reverse = false;
    bool            m_repeat = false;

};

//曲线数据发生器，管理设置为跟随曲线数据的数据的更新
class CurveDataGenerater : public QObject
{
    Q_OBJECT
public:
    explicit CurveDataGenerater(QObject *parent = nullptr);

    void addTarget(float *const target, int period , const QVector<double> &data);
    void addTarget( SimDataSt *const dataSt);
    void removeTarget(float *const target);
    void clearTarget();

    void startTarget(float *const target);
    void startTarget(SimDataSt *const dataSt);

private:
    QHash<float *const, CurveTargetSt *> m_targetList;
};

#endif // CURVEDATAGENERATER_H
