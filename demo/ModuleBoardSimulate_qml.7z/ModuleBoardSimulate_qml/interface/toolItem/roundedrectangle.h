#ifndef ROUNDEDRECTANGLE_H
#define ROUNDEDRECTANGLE_H

#include <QQuickPaintedItem>

class RoundedRectangle : public QQuickPaintedItem
{
    Q_OBJECT
    
    Q_PROPERTY(qreal topLeftRadius READ topLeftRadius WRITE setTopLeftRadius NOTIFY topLeftRadiusChanged)
    Q_PROPERTY(qreal topRightRadius READ topRightRadius WRITE setTopRightRadius NOTIFY topRightRadiusChanged)
    Q_PROPERTY(qreal bottomLeftRadius READ bottomLeftRadius WRITE setBottomLeftRadius NOTIFY bottomLeftRadiusChanged)
    Q_PROPERTY(qreal bottomRightRadius READ bottomRightRadius WRITE setBottomRightRadius NOTIFY bottomRightRadiusChanged)
    Q_PROPERTY(QColor color READ color WRITE setColor NOTIFY colorChanged)
//    Q_PROPERTY(QColor borderColor READ borderColor WRITE setBorderColor NOTIFY borderColorChanged)
    
public:
    explicit RoundedRectangle(QQuickItem *parent = Q_NULLPTR);
    
    void paint(QPainter *painter) override;
    
    qreal topLeftRadius() const;
    void setTopLeftRadius(const qreal &topLeftRadius);
    
    qreal topRightRadius() const;
    void setTopRightRadius(const qreal &topRightRadius);
    
    qreal bottomLeftRadius() const;
    void setBottomLeftRadius(const qreal &bottomLeftRadius);
    
    qreal bottomRightRadius() const;
    void setBottomRightRadius(const qreal &bottomRightRadius);
    
    QColor color() const;
    void setColor(const QColor &color);
    
signals:
    void topLeftRadiusChanged(qreal radius);
    void topRightRadiusChanged(qreal radius);
    void bottomLeftRadiusChanged(qreal radius);
    void bottomRightRadiusChanged(qreal radius);
    
    void colorChanged(QColor color);
    
private:
    qreal   m_topLeftRadius     = 0;
    qreal   m_topRightRadius    = 0;
    qreal   m_bottomLeftRadius  = 0;
    qreal   m_bottomRightRadius = 0;
    
    QColor  m_color = Qt::white;
};

#endif // ROUNDEDRECTANGLE_H
