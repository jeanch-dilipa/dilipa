#include "valuemodelselector.h"
#include "ui_valuemodelselector.h"

#include <QQmlContext>
#include <QQmlEngine>
#include <QQuickItem>
#include <QPropertyAnimation>

ValueModelSelector::ValueModelSelector(const DataSimModeSt &dsm, const AutoFollowCurve &curve, const QString &valueStr0, const QString &valueStr1, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ValueModelSelector)
{
    ui->setupUi(this);



    m_currentSetting = dsm;
    m_simMode           = dsm.mode;
    m_simValueType      = dsm.valueType;
    m_simFixValue       = dsm.fixValue;
    m_simRandomMinValue = dsm.randomMinValue;
    m_simRandomMaxValue = dsm.randomMaxValue;
    m_simAutoSubValue   = dsm.autoSubValue;
    m_simAutoAddValue   = dsm.autoAddValue;
    m_simDecimals       = dsm.decimals;
    m_simChanged        = dsm.changed;

    m_currentAutoFollowCurve    = curve;
    m_curvePeriod               = curve.period;
    m_curveData                 = curve.data;
    m_curveStart                = curve.start;
    m_curveStartIndex           = curve.startIndex;
    m_curveReverse              = curve.reverse;
    m_curveRepeat               = curve.repeat;

    m_valName1 = valueStr0;
    m_valName2 = valueStr1;



//    m_curvePeriod               = 1000;
    QVector<double> data;
    data<<1<<3<<5<<6<<7<<9<<0;
    m_currentAutoFollowCurve.data = data;
    m_curveData                 = data;

    this->setWindowFlags(windowFlags()|Qt::FramelessWindowHint);
    this->setStyleSheet("background-color:transparent;");
    this->setAttribute(Qt::WA_TranslucentBackground, true);
    const QUrl url(QStringLiteral("qrc:/DialogSample.qml"));

    ui->quickWidget->rootContext()->setContextProperty("settingDialog",this);
    ui->quickWidget->setSource(url);
    connect(ui->quickWidget->rootObject(), &QQuickItem::widthChanged,[=]{
   resize(ui->quickWidget->rootObject()->width(), height());
    });
    connect(ui->quickWidget->rootObject(), &QQuickItem::heightChanged,[=]{
   resize(width(), ui->quickWidget->rootObject()->height());
    });
    ui->quickWidget->setResizeMode(QQuickWidget::SizeViewToRootObject);

    ui->quickWidget->setClearColor(QColor(Qt::transparent));
    connect(ui->quickWidget->engine(), &QQmlEngine::quit, [=]{
        this->accept();
    });

}

ValueModelSelector::~ValueModelSelector()
{
    delete ui;
}

void ValueModelSelector::setCurrentSetting(const DataSimModeSt &dsm, const AutoFollowCurve &curve, const QString &valueStr0, const QString &valueStr1)
{
    m_currentSetting = dsm;
    setSimMode           ( dsm.mode          )   ;
    setSimValueType      ( dsm.valueType     )   ;
    setSimFixValue       ( dsm.fixValue      )   ;
    setSimRandomMinValue ( dsm.randomMinValue)   ;
    setSimRandomMax      ( dsm.randomMaxValue)   ;
    setSimAutoSubValue   ( dsm.autoSubValue  )   ;
    setSimAutoAddValue   ( dsm.autoAddValue  )   ;
    setSimDecimals       ( dsm.decimals      )   ;
    setSimChanged        ( dsm.changed       )   ;

    QVector<double> data;
    data<<1<<3<<5<<6<<7<<9<<0;

    m_currentAutoFollowCurve   = curve           ;
    setCurvePeriod               ( curve.period    );
    setCurveData                 ( curve.data      );
    setCurveStart                ( curve.start     );
    setCurveStartIndex           ( curve.startIndex);
    setCurveReverse              ( curve.reverse   );
    setCurveRepeat               ( curve.repeat    );

    setValName1(valueStr0);
    setValName2(valueStr1);
}


DataSimModeSt ValueModelSelector::currentSetting()
{
    m_currentSetting.mode            = ValueSimModeType(m_simMode) ;
    m_currentSetting.valueType       = ValueType(m_simValueType);
    m_currentSetting.fixValue        = m_simFixValue;
    m_currentSetting.randomMinValue  = m_simRandomMinValue;
    m_currentSetting.randomMaxValue  = m_simRandomMaxValue;
    m_currentSetting.autoSubValue    = m_simAutoSubValue;
    m_currentSetting.autoAddValue    = m_simAutoAddValue;
    m_currentSetting.decimals        = m_simDecimals;
    m_currentSetting.changed         = m_simChanged;
    return m_currentSetting;
}

AutoFollowCurve ValueModelSelector::currentCurve()
{
    m_currentAutoFollowCurve.period     = m_curvePeriod      ;
    m_currentAutoFollowCurve.data       = m_curveData        ;
    m_currentAutoFollowCurve.start      = m_curveStart       ;
    m_currentAutoFollowCurve.startIndex = m_curveStartIndex  ;
    m_currentAutoFollowCurve.reverse    = m_curveReverse     ;
    m_currentAutoFollowCurve.repeat     = m_curveRepeat      ;
    return m_currentAutoFollowCurve;
}

void ValueModelSelector::closeWindow()
{
    setMinimumSize(0,0);
    QPropertyAnimation* closeAnimation = new QPropertyAnimation(this,"geometry");
    closeAnimation->setStartValue(geometry());
    closeAnimation->setEndValue(QRect(geometry().x()+width()/8,geometry().y()+height()/8,width()/4*3,height()/4*3));
    closeAnimation->setDuration(200);
//        closeAnimationState = hasplayed;
    connect(closeAnimation,SIGNAL(finished()),this,SLOT(hide()));
    closeAnimation->start(QAbstractAnimation::DeleteWhenStopped);
}

//void ValueModelSelector::showEvent(QShowEvent *event)
//{
//    QDialog::showEvent(event);
//}

//void ValueModelSelector::closeEvent(QCloseEvent *event)
//{
//    QDialog::closeEvent(event);
//}
