#include "roundedrectangle.h"
#include <QPainter>
#include <QPainterPath>

RoundedRectangle::RoundedRectangle(QQuickItem *parent) : QQuickPaintedItem(parent)
{
    setWidth(100);
    setHeight(100);
}

void RoundedRectangle::paint(QPainter *painter)
{
    painter->save();

    painter->setBrush(color());
    painter->setPen(Qt::NoPen);
    painter->setRenderHint(QPainter::Antialiasing,true);

    QPainterPath path;
    path.moveTo(QPoint(0,0));
    path.setFillRule(Qt::WindingFill);

    path.addEllipse(QPointF(topLeftRadius(), topLeftRadius()),
                    topLeftRadius(), topLeftRadius());
    path.addEllipse(QPointF(width() - topRightRadius(), topRightRadius()),
                    topRightRadius(), topRightRadius());
    path.addEllipse(QPointF(width() - bottomRightRadius(), height() - bottomRightRadius()),
                    bottomRightRadius(), bottomRightRadius());
    path.addEllipse(QPointF(bottomLeftRadius(), height()-bottomLeftRadius()),
                    bottomLeftRadius(), bottomLeftRadius());

    QPolygonF polygon;
    polygon<<QPointF(0, topLeftRadius())<<
             QPointF(topLeftRadius(), 0)<<
             QPointF(width()-topRightRadius(), 0)<<
             QPointF(width(), topRightRadius())<<
             QPointF(width(), height() - bottomRightRadius())<<
             QPointF(width() - bottomRightRadius(), height())<<
             QPointF(bottomLeftRadius(), height())<<
             QPointF(0, height() - bottomLeftRadius());

    path.addPolygon(polygon);

    painter->drawPath(path);

    painter->restore();
}

qreal RoundedRectangle::topLeftRadius() const
{
    return m_topLeftRadius;
}

void RoundedRectangle::setTopLeftRadius(const qreal &topLeftRadius)
{
    if(m_topLeftRadius != topLeftRadius)
    {
        m_topLeftRadius = topLeftRadius;
        emit topLeftRadiusChanged(m_topLeftRadius);
        update();
    }
}

qreal RoundedRectangle::topRightRadius() const
{
    return m_topRightRadius;
}

void RoundedRectangle::setTopRightRadius(const qreal &topRightRadius)
{
    if(m_topRightRadius != topRightRadius)
    {
        m_topRightRadius = topRightRadius;
        emit topRightRadiusChanged(m_topRightRadius);
        update();
    }
}

qreal RoundedRectangle::bottomLeftRadius() const
{
    return m_bottomLeftRadius;
}

void RoundedRectangle::setBottomLeftRadius(const qreal &bottomLeftRadius)
{
    if(m_bottomLeftRadius != bottomLeftRadius)
    {
        m_bottomLeftRadius = bottomLeftRadius;
        emit bottomLeftRadiusChanged(m_bottomLeftRadius);
        update();
    }
}

qreal RoundedRectangle::bottomRightRadius() const
{
    return m_bottomRightRadius;
}

void RoundedRectangle::setBottomRightRadius(const qreal &bottomRightRadius)
{
    if(m_bottomRightRadius != bottomRightRadius)
    {
        m_bottomRightRadius = bottomRightRadius;
        emit bottomRightRadiusChanged(m_bottomRightRadius);
        update();
    }
}

QColor RoundedRectangle::color() const
{
    return m_color;
}

void RoundedRectangle::setColor(const QColor &color)
{
    if(m_color != color)
    {
        m_color = color;
        emit colorChanged(m_color);
        update();
    }
}
