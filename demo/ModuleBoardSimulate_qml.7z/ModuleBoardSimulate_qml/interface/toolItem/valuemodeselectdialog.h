#ifndef VALUEMODESELECTDIALOG_H
#define VALUEMODESELECTDIALOG_H

#include <QDialog>
#include "common/publicdata.h"
#include <QQuickView>
#include <QtQuickWidgets/QQuickWidget>

namespace Ui {
class ValueModeSelectDialog;
}

class ValueModeSelectDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ValueModeSelectDialog(QWidget *parent = 0);
    ~ValueModeSelectDialog();

    void setTitle(const QString &title);
    void setDecimals(int dec);
    void setCurrentSetting(const DataSimModeSt &dsm, const QString &valueStr0, const QString &valueStr1); //设置当前设置，以及二值时的文字
    void setCurrentSetting(const DataSimModeSt &dsm, const QStringList &enumStrList); //设置当前设置，枚举类型
    void setCurrentAutoFollowCurve(const AutoFollowCurve &curve);
    DataSimModeSt currentSetting();
    AutoFollowCurve currentCurve();

    Q_INVOKABLE void setCurvePeriod(int p)
    {
        m_currentAutoFollowCurve.period = p;
    }
    Q_INVOKABLE void setCurveData(QVector<double> data)
    {
        m_currentAutoFollowCurve.data = data;
    }

    Q_INVOKABLE void setCurveStartIndex(int index)
    {
        m_currentAutoFollowCurve.startIndex = index;
    }
    Q_INVOKABLE void setCurveStart(bool yn)
    {
        m_currentAutoFollowCurve.start = yn;
    }
    Q_INVOKABLE void setCurveRepeatable(bool yn)
    {
        m_currentAutoFollowCurve.repeat = yn;
    }
    Q_INVOKABLE void setCurveReverseble(bool yn)
    {
        m_currentAutoFollowCurve.reverse = yn;
    }

private slots:
    void on_randomMinSpinBox_valueChanged(double arg1);
    void on_randomMaxSpinBox_valueChanged(double arg1);

    void on_importArrayFileBtn_clicked();

    void on_curvePeriodSpinBox_valueChanged(int arg1);

    void on_startBtn_clicked();

private:
    void setValueType(ValueType type, const QString &valueStr0 = "", const QString &valueStr1 = ""); //设置数据类型，若为二值时，还设置文字
    void setEnumValueType(ValueType type, const QStringList &enumStrList); //设定为枚举类型

private:
    Ui::ValueModeSelectDialog *ui;
    DataSimModeSt m_currentSetting;
    AutoFollowCurve m_currentAutoFollowCurve;

    QQuickWidget *m_curveSetView  ;
};

#endif // VALUEMODESELECTDIALOG_H
