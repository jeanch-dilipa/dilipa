#include "valuemodeselectdialog.h"
#include "ui_valuemodeselectdialog.h"
#include <QFileDialog>
#include <QDebug> ///#include <QDebug>
#include <QQmlContext>
#include "valuemodelselector.h"


/**
 * @brief 弃用，改用valuemodelselector,采用qml设计
 * @param
 */

ValueModeSelectDialog::ValueModeSelectDialog(QWidget *parent) : QDialog(parent), ui(new Ui::ValueModeSelectDialog)
{
    ui->setupUi(this);
//    this->setWindowFlags(Qt::Popup | Qt::FramelessWindowHint);
    setAttribute(Qt::WA_TranslucentBackground, true);
    setFixedSize(QSize(600,600));

    connect(ui->closeBtn, &QPushButton::clicked, this, &QDialog::close);
    ui->closeBtn->hide(); //隐藏关闭按钮（貌似有点多余）

    const QUrl url(QStringLiteral("qrc:/ArraySetPanel.qml"));
    m_curveSetView = new QQuickWidget(this);

    m_curveSetView->rootContext()->setContextProperty("dataSet", this);
    m_curveSetView->setSource(url);
    m_curveSetView->setResizeMode(QQuickWidget::SizeViewToRootObject);
    m_curveSetView->hide();
}

ValueModeSelectDialog::~ValueModeSelectDialog()
{
    delete ui;
}

void ValueModeSelectDialog::setValueType(ValueType type, const QString &valueStr0, const QString &valueStr1)
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->firstRadioBtn->setText(tr("固定值"));
    ui->secondRadioBtn->setText(tr("随机值"));

    switch(type)
    {
    case BinaryValue:
        ui->fixValueWidget->hide();
        ui->randomRangeWidget->hide();
        ui->flucRangeWidget->hide();
        ui->thirdRadioBtn->hide();
        ui->line_two->hide();
        ui->firstRadioBtn->setText(valueStr0);
        ui->secondRadioBtn->setText(valueStr1);
        this->setFixedSize(190, 170+40);
        break;
    case BinaryValueWithAuto:
        ui->fixValueWidget->hide();
        ui->randomRangeWidget->hide();
        ui->flucRangeWidget->hide();
        ui->thirdRadioBtn->show();
        ui->line_two->show();
        ui->firstRadioBtn->setText(valueStr0);
        ui->secondRadioBtn->setText(valueStr1);
        this->setFixedSize(190, 170+40);
        break;
    case NumericValue:
        ui->fixValueWidget->show();
        ui->randomRangeWidget->show();
        ui->flucRangeWidget->hide();
        ui->thirdRadioBtn->hide();
        ui->line_two->hide();
//        this->setFixedSize(250, 220+40);
        break;
    case NumericValueWithAuto:
        ui->fixValueWidget->show();
        ui->randomRangeWidget->show();
        ui->flucRangeWidget->hide();
        ui->thirdRadioBtn->show();
        ui->line_two->show();
//        this->setFixedSize(250, 240+40);
        break;
    case NumericValueWithAutoRange:
        ui->fixValueWidget->show();
        ui->randomRangeWidget->show();
        ui->flucRangeWidget->show();
        ui->thirdRadioBtn->show();
        ui->line_two->show();
//        this->setFixedSize(300, 270+40);
        break;
    default:
        break;
    }
}

void ValueModeSelectDialog::setEnumValueType(ValueType type, const QStringList &enumStrList)
{
    ui->stackedWidget->setCurrentIndex(1);

    ui->fixComboBox_page2->clear();
    ui->fixComboBox_page2->addItems(enumStrList);

    ui->autoRadioBtn_page2->setVisible(type == EnumValueWithAuto);

    this->setFixedSize(190, 170);
}

void ValueModeSelectDialog::setTitle(const QString &title)
{
    ui->titleLabel->setText(title);
}

void ValueModeSelectDialog::setDecimals(int dec)
{
    ui->fixSpinBox->setDecimals(dec);
    ui->randomMinSpinBox->setDecimals(dec);
    ui->randomMaxSpinBox->setDecimals(dec);
    ui->autoSubSpinBox->setDecimals(dec);
    ui->autoAddSpinBox->setDecimals(dec);
}

void ValueModeSelectDialog::setCurrentSetting(const DataSimModeSt &dsm, const QString &valueStr0, const QString &valueStr1)
{
    m_currentSetting = dsm;
    setValueType(dsm.valueType, valueStr0, valueStr1);

    if(dsm.valueType <= BinaryValueWithAuto)
    {   //二值的数据类型（只有固定和自动两种模式）
        if(dsm.mode == FixSimMode)
        {   //固定模式
            if(dsm.fixValue == 0)
            {
                ui->firstRadioBtn->setChecked(true);
            }
            else
            {
                ui->secondRadioBtn->setChecked(true);
            }
        }
        else
        {   //自动模式
            ui->thirdRadioBtn->setChecked(true);
        }
    }
    else
    {   //数值型的数据类型
        setDecimals(dsm.decimals);
        switch(dsm.mode)
        {
        case FixSimMode:
            ui->firstRadioBtn->setChecked(true);
            break;
        case RandomSimMode:
            ui->secondRadioBtn->setChecked(true);
            break;
        case AutoSimMode:
            ui->thirdRadioBtn->setChecked(true);
            break;
        case FollowCurve:
            ui->forthRadioBtn->setChecked(true);
        default:
            break;
        }

        ui->fixSpinBox->setValue(dsm.fixValue);
        ui->randomMinSpinBox->setValue(dsm.randomMinValue);
        ui->randomMaxSpinBox->setValue(dsm.randomMaxValue);
        ui->autoSubSpinBox->setValue(dsm.autoSubValue);
        ui->autoAddSpinBox->setValue(dsm.autoAddValue);
        ui->curvePeriodSpinBox->setValue(m_currentAutoFollowCurve.period/1000);
    }
}

void ValueModeSelectDialog::setCurrentSetting(const DataSimModeSt &dsm, const QStringList &enumStrList)
{
    m_currentSetting = dsm;
    setEnumValueType(dsm.valueType, enumStrList);

    if(dsm.mode == FixSimMode)
    {
        ui->fixRadioBtn_page2->setChecked(true);
    }
    else if(dsm.mode == AutoSimMode)
    {
        ui->autoRadioBtn_page2->setChecked(true);
    }

    ui->fixComboBox_page2->setCurrentIndex((int)dsm.fixValue);
}


//设置当前的自动跟随曲线，因为曲线预览没有做，所以不需要更新界面的信息
void ValueModeSelectDialog::setCurrentAutoFollowCurve(const AutoFollowCurve &curve)
{
    m_currentAutoFollowCurve = curve;
//    m_curveSetView->rootContext()->setContextProperty("curve", &m_currentAutoFollowCurve);
}

DataSimModeSt ValueModeSelectDialog::currentSetting()
{
    if(m_currentSetting.valueType <= BinaryValueWithAuto)
    {   //二值的数据类型（只有固定和自动两种模式）
        if(ui->firstRadioBtn->isChecked())
        {
            m_currentSetting.mode = FixSimMode;
            m_currentSetting.fixValue = 0;
        }
        else if(ui->secondRadioBtn->isChecked())
        {
            m_currentSetting.mode = FixSimMode;
            m_currentSetting.fixValue = 1;
        }
        else if(ui->thirdRadioBtn->isChecked())
        {
            m_currentSetting.mode = AutoSimMode;
        }
    }
    else if(m_currentSetting.valueType >= NumericValue && m_currentSetting.valueType <= NumericValueWithAutoRange)
    {   //数值型的数据类型
        if(ui->firstRadioBtn->isChecked())
        {
            m_currentSetting.mode = FixSimMode;
        }
        else if(ui->secondRadioBtn->isChecked())
        {
            m_currentSetting.mode = RandomSimMode;
        }
        else if(ui->thirdRadioBtn->isChecked())
        {
            m_currentSetting.mode = AutoSimMode;
        }
        else if(ui->forthRadioBtn->isChecked())
        {
            m_currentSetting.mode = FollowCurve;
        }

        m_currentSetting.fixValue = ui->fixSpinBox->value();
        m_currentSetting.randomMinValue = ui->randomMinSpinBox->value();
        m_currentSetting.randomMaxValue = ui->randomMaxSpinBox->value();
        m_currentSetting.autoSubValue = ui->autoSubSpinBox->value();
        m_currentSetting.autoAddValue = ui->autoAddSpinBox->value();
    }
    else if(m_currentSetting.valueType >= EnumValue && m_currentSetting.valueType <= EnumValueWithAuto)
    {   //枚举类型
        if(ui->fixRadioBtn_page2->isChecked())
        {
            m_currentSetting.mode = FixSimMode;
        }
        else if(ui->autoRadioBtn_page2->isChecked())
        {
            m_currentSetting.mode = AutoSimMode;
        }


        m_currentSetting.fixValue = ui->fixComboBox_page2->currentIndex();
    }

    return m_currentSetting;
}

AutoFollowCurve ValueModeSelectDialog::currentCurve()
{
    return m_currentAutoFollowCurve;
}

void ValueModeSelectDialog::on_randomMinSpinBox_valueChanged(double arg1)
{
    ui->randomMaxSpinBox->setMinimum(arg1);
}

void ValueModeSelectDialog::on_randomMaxSpinBox_valueChanged(double arg1)
{
    ui->randomMinSpinBox->setMaximum(arg1);
}

void ValueModeSelectDialog::on_importArrayFileBtn_clicked()
{
//    QString arryFileName = QFileDialog::getOpenFileName();
//    if(arryFileName.isEmpty())
//    {
//        qDebug()<<"你倒是选一个文件呐！";
//    }
//    else
//    {
//        QFile f(arryFileName);
//        if(f.open(QIODevice::ReadOnly))
//        {
//            QString content = f.readAll();
//            f.close();
//            QStringList datas = content.split(QRegExp("[\r\n]"),QString::SkipEmptyParts);
//            if(!datas.isEmpty() && datas.first() == "相对血容量")
//            {
//                datas.removeFirst(); //移除表头
//                m_currentAutoFollowCurve.data.clear();//清除原数据
//                foreach(QString data, datas)
//                {
//                    m_currentAutoFollowCurve.data.append(data.toDouble());
//                }
//            }
//        }
//    }

    QVector<double> data;
    data<<1<<3<<5<<6<<7<<9<<0;
    m_currentAutoFollowCurve.data = data;
//    ValueModelSelector sel;
//    sel.exec();

}

void ValueModeSelectDialog::on_curvePeriodSpinBox_valueChanged(int arg1)
{
    if(arg1 > 0)
    {
        m_currentAutoFollowCurve.period = arg1 * 1000;
    }
}

void ValueModeSelectDialog::on_startBtn_clicked()
{
    m_currentAutoFollowCurve.start = true;
}
