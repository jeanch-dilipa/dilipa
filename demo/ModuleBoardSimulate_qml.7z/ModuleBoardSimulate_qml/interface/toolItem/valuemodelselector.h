#ifndef VALUEMODELSELECTOR_H
#define VALUEMODELSELECTOR_H

#include "common/publicdata.h"
#include <QDialog>
#include <QDebug>

namespace Ui {
class ValueModelSelector;
}


class ValueModelSelector : public QDialog
{
    Q_OBJECT

    Q_PROPERTY(int curvePeriod READ curvePeriod WRITE setCurvePeriod NOTIFY curvePeriodChanged)
    Q_PROPERTY(QVector<double> curveData READ curveData WRITE setCurveData NOTIFY curveDataChanged)
    Q_PROPERTY(bool curveStart READ curveStart WRITE setCurveStart NOTIFY curveStartChanged)
    Q_PROPERTY(int curveStartIndex READ curveStartIndex WRITE setCurveStartIndex NOTIFY curveStartIndexChanged)
    Q_PROPERTY(bool curveRepeat READ curveRepeat WRITE setCurveRepeat NOTIFY curveRepeatChanged)
    Q_PROPERTY(bool curveReverse READ curveReverse WRITE setCurveReverse NOTIFY curveReverseChanged)

    Q_PROPERTY(int simMode READ simMode WRITE setSimMode NOTIFY simModeChanged)
    Q_PROPERTY(int simValueType READ simValueType WRITE setSimValueType NOTIFY simValueTypeChanged)
    Q_PROPERTY(float simFixValue READ simFixValue WRITE setSimFixValue NOTIFY simFixValueChanged)
    Q_PROPERTY(float simRandomMinValue READ simRandomMinValue WRITE setSimRandomMinValue NOTIFY simRandomMinValueChanged)
    Q_PROPERTY(float simRandomMaxValue READ simRandomMax WRITE setSimRandomMax NOTIFY simRandomMaxChanged)
    Q_PROPERTY(float simAutoSubValue READ simAutoSubValue WRITE setSimAutoSubValue NOTIFY simAutoSubValueChanged)
    Q_PROPERTY(float simAutoAddValue READ simAutoAddValue WRITE setSimAutoAddValue NOTIFY simAutoAddValueChanged)
    Q_PROPERTY(quint8 simDecimals READ simDecimals WRITE setSimDecimals NOTIFY simDecimalsChanged)
    Q_PROPERTY(bool simChanged READ simChanged WRITE setSimChanged NOTIFY simChangedChanged)

    Q_PROPERTY(QString title READ title WRITE setTitle NOTIFY titleChanged)
    Q_PROPERTY(QString unit READ unit WRITE setUnit NOTIFY unitChanged)

    Q_PROPERTY(QString valName1 READ valName1 WRITE setValName1 NOTIFY valName1Changed)
    Q_PROPERTY(QString valName2 READ valName2 WRITE setValName2 NOTIFY valName2Changed)


public:
    explicit ValueModelSelector(const DataSimModeSt &dsm, const AutoFollowCurve &curve,  const QString &valueStr0, const QString &valueStr1, QWidget *parent = nullptr);
    explicit ValueModelSelector(const DataSimModeSt &dsm, const AutoFollowCurve &curve,  const QStringList &enumStrList, QWidget *parent = nullptr);
    ~ValueModelSelector();

    void setCurrentSetting(const DataSimModeSt &dsm,const AutoFollowCurve &curve, const QString &valueStr0, const QString &valueStr1); //设置当前设置，以及二值时的文字
//    void setCurrentSetting(const DataSimModeSt &dsm, const QStringList &enumStrList); //设置当前设置，枚举类型
//    void setCurrentAutoFollowCurve(const AutoFollowCurve &curve);

    DataSimModeSt currentSetting();
    AutoFollowCurve currentCurve();

    int curvePeriod() const
    {
        return m_curvePeriod;
    }

    QVector<double> curveData() const
    {
        return m_curveData;
    }

    bool curveStart() const
    {
        return m_curveStart;
    }

    int curveStartIndex() const
    {
        return m_curveStartIndex;
    }

    bool curveRepeat() const
    {
        return m_curveRepeat;
    }

    bool curveReverse() const
    {
        return m_curveReverse;
    }

    int simMode() const
    {
        return m_simMode;
    }

    int simValueType() const
    {
        return m_simValueType;
    }

    float simFixValue() const
    {
        return m_simFixValue;
    }

    float simRandomMinValue() const
    {
        return m_simRandomMinValue;
    }

    float simRandomMax() const
    {
        return m_simRandomMaxValue;
    }

    float simAutoSubValue() const
    {
        return m_simAutoSubValue;
    }

    float simAutoAddValue() const
    {
        return m_simAutoAddValue;
    }

    quint8 simDecimals() const
    {
        return m_simDecimals;
    }

    bool simChanged() const
    {
        return m_simChanged;
    }

    QString title() const
    {
        return m_title;
    }

    QString unit() const
    {
        return m_unit;
    }

    QString valName1() const
    {
        return m_valName1;
    }

    QString valName2() const
    {
        return m_valName2;
    }

public slots:
    void setCurvePeriod(int curvePeriod)
    {
        if (m_curvePeriod == curvePeriod)
            return;

        m_curvePeriod = curvePeriod;
        emit curvePeriodChanged(m_curvePeriod);
    }

    void setCurveData(QVector<double> curveData)
    {
        if (m_curveData == curveData)
            return;

        m_curveData = curveData;
        emit curveDataChanged(m_curveData);
    }

    void setCurveStart(bool curveStart)
    {
        if (m_curveStart == curveStart)
            return;

        m_curveStart = curveStart;
        emit curveStartChanged(m_curveStart);
    }

    void setCurveStartIndex(int curveStartIndex)
    {
        if (m_curveStartIndex == curveStartIndex)
            return;

        m_curveStartIndex = curveStartIndex;
        emit curveStartIndexChanged(m_curveStartIndex);
    }

    void setCurveRepeat(bool curveRepeat)
    {
        if (m_curveRepeat == curveRepeat)
            return;

        m_curveRepeat = curveRepeat;
        emit curveRepeatChanged(m_curveRepeat);
    }

    void setCurveReverse(bool curveReverse)
    {
        if (m_curveReverse == curveReverse)
            return;

        m_curveReverse = curveReverse;
        emit curveReverseChanged(m_curveReverse);
    }

    void setSimMode(int simMode)
    {
        if (m_simMode == simMode)
            return;

        m_simMode = simMode;
        emit simModeChanged(m_simMode);
    }

    void setSimValueType(int simValueType)
    {
        if (m_simValueType == simValueType)
            return;

        m_simValueType = simValueType;
        emit simValueTypeChanged(m_simValueType);
    }

    void setSimFixValue(float simFixValue)
    {
//        qWarning("Floating point comparison needs context sanity check");
        if (qFuzzyCompare(m_simFixValue, simFixValue))
            return;

        m_simFixValue = simFixValue;
        emit simFixValueChanged(m_simFixValue);
    }

    void setSimRandomMinValue(float simRandomMinValue)
    {
//        qWarning("Floating point comparison needs context sanity check");
        if (qFuzzyCompare(m_simRandomMinValue, simRandomMinValue))
            return;

        m_simRandomMinValue = simRandomMinValue;
        emit simRandomMinValueChanged(m_simRandomMinValue);
    }

    void setSimRandomMax(float simRandomMaxValue)
    {
//        qWarning("Floating point comparison needs context sanity check");
        if (qFuzzyCompare(m_simRandomMaxValue, simRandomMaxValue))
            return;

        m_simRandomMaxValue = simRandomMaxValue;
        emit simRandomMaxChanged(m_simRandomMaxValue);
    }

    void setSimAutoSubValue(float simAutoSubValue)
    {
//        qWarning("Floating point comparison needs context sanity check");
        if (qFuzzyCompare(m_simAutoSubValue, simAutoSubValue))
            return;

        m_simAutoSubValue = simAutoSubValue;
        emit simAutoSubValueChanged(m_simAutoSubValue);
    }

    void setSimAutoAddValue(float simAutoAddValue)
    {
//        qWarning("Floating point comparison needs context sanity check");
        if (qFuzzyCompare(m_simAutoAddValue, simAutoAddValue))
            return;

        m_simAutoAddValue = simAutoAddValue;
        emit simAutoAddValueChanged(m_simAutoAddValue);
    }

    void setSimDecimals(quint8 simDecimals)
    {
        if (m_simDecimals == simDecimals)
            return;

        m_simDecimals = simDecimals;
        emit simDecimalsChanged(m_simDecimals);
    }

    void setSimChanged(bool simChanged)
    {
        if (m_simChanged == simChanged)
            return;

        m_simChanged = simChanged;
        emit simChangedChanged(m_simChanged);
    }

    void setTitle(QString title)
    {
        if (m_title == title)
            return;

        m_title = title;
        emit titleChanged(m_title);
    }

    void setUnit(QString unit)
    {
        if (m_unit == unit)
            return;

        m_unit = unit;
        emit unitChanged(m_unit);
    }

    void setValName1(QString valName1)
    {
        if (m_valName1 == valName1)
            return;

        m_valName1 = valName1;
        emit valName1Changed(m_valName1);
    }

    void setValName2(QString valName2)
    {
        if (m_valName2 == valName2)
            return;

        m_valName2 = valName2;
        emit valName2Changed(m_valName2);
    }

    Q_INVOKABLE void closeWindow();

//protected:
//    void showEvent(QShowEvent *event) override;
//    void closeEvent(QCloseEvent *event) override;

signals:
    void curvePeriodChanged(int curvePeriod);

    void curveDataChanged(QVector<double> curveData);

    void curveStartChanged(bool curveStart);

    void curveStartIndexChanged(int curveStartIndex);

    void curveRepeatChanged(bool curveRepeat);

    void curveReverseChanged(bool curveReverse);

    void simModeChanged(int simMode);

    void simValueTypeChanged(int simValueType);

    void simFixValueChanged(float simFixValue);

    void simRandomMinValueChanged(float simRandomMinValue);

    void simRandomMaxChanged(float simRandomMaxValue);

    void simAutoSubValueChanged(float simAutoSubValue);

    void simAutoAddValueChanged(float simAutoAddValue);

    void simDecimalsChanged(quint8 simDecimals);

    void simChangedChanged(bool simChanged);

    void titleChanged(QString title);

    void unitChanged(QString unit);

    void valName1Changed(QString valName1);

    void valName2Changed(QString valName2);

private:
    Ui::ValueModelSelector *ui;
    DataSimModeSt m_currentSetting;
    AutoFollowCurve m_currentAutoFollowCurve;
    int m_curvePeriod;
    QVector<double> m_curveData;
    bool m_curveStart;
    int m_curveStartIndex;
    bool m_curveRepeat;
    bool m_curveReverse;
    int m_simMode;
    int m_simValueType;
    float m_simFixValue;
    float m_simRandomMinValue;
    float m_simRandomMaxValue;
    float m_simAutoSubValue;
    float m_simAutoAddValue;
    quint8 m_simDecimals;
    bool m_simChanged;
    QString m_title = "Name";
    QString m_unit = "";
    QString m_valName1;
    QString m_valName2;
};

#endif // VALUEMODELSELECTOR_H
